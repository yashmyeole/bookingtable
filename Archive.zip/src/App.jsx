import React, { useState, useEffect, useRef } from "react";
import LottieScrollAnimation from "./components/TempLottie";
import { Canvas } from "@react-three/fiber";
import { Html } from "@react-three/drei";
import MainBox from "./components/main/MainBox";
import Comp1 from "./components/temp/Comp1";
import Comp2 from "./components/temp/Comp2";
import { AnimatePresence, motion, useInView } from "framer-motion";
import CustomComp from "./components/temp/CustomComp";
import Line1 from "./components/lines/Line1";
// import Seekbar from "./components/main/Seekbar";
import { Player } from "@lottiefiles/react-lottie-player";
import Seekbar from "./components/main/SeekbarH";

function App() {
  const [isBeginClicked, setIsBeginClicked] = useState(false);
  const [showModiAnimation, setShowModiAnimation] = useState(false);
  const [newOffestValue, setNewOffsetValue] = useState(0);
  // useEffect(() => {
  //   if (isBeginClicked) {
  //     console.log("Use Effect Called: ", newOffestValue);
  //     scrollToComponent(newOffestValue);
  //   }
  //  }, [newOffestValue]);
 
  const handlejump = (value) => {
    // console.log("Running: ", value);
    console.log("Handle Jump Called: ", value);
    scrollToComponent(value);
    setNewOffsetValue(value);
    // scrollToComponent(value);
  };

  const handleScroll = (indexValue) => {
    console.log("Handle Scroll Called: ", indexValue);
    setNewOffsetValue(indexValue);
  };

  const scrollToComponent = (componentId) => {
    console.log("Scroll To Component Called: ", componentId);
    // const element = document.getElementBy(componentId);
    const element = document.getElementsByClassName(componentId)[0];
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "center",
      });
    }
  };

  return (
    <div
      className={`flex max-h-[100vh] select-none ${
        showModiAnimation ? "overflow-x-auto" : "overflow-x-hidden"
      } `}
    >
      {/* <div class="blob"></div> */}
      <MainBox
        isBeginClicked={isBeginClicked}
        setIsBeginClicked={setIsBeginClicked}
        showModiAnimation={showModiAnimation}
        setShowModiAnimation={setShowModiAnimation}
        handleScroll={handleScroll}
   
      />
      <Seekbar
        handlejump={handlejump}
        showModiAnimation={showModiAnimation}
        yearToMove={newOffestValue}
      />
    </div>
  );
}

export default App;
