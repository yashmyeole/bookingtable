import React from "react";
import { motion } from "framer-motion";
import RightIcon from "../../../assets/right-icon.svg";

const SingleImageContainer = ({ event = {}, eventIndex, isInView }) => {
  const ImageComponent = () => {
    return (
      <div className="flex w-full h-full bg-cover relative">
        <div className="absolute right-0 bottom-0">
          <img
            src={event.mainImage}
            className="md:w-[300px] md:h-[250px] rounded-tl-[8px] rounded-tr-[50px] rounded-bl-[50px] rounded-br-[8px]"
          />
          <motion.button
            onClick={() => window.open(event.href, "_blank")}
            className="flex justify-center z-100 items-center absolute -right-6 top-6 h-[46px] bg-[#5770C9] hover:bg-[#3a57c7] w-[46px] rounded-full p-2"
          >
            <img src={RightIcon} className="h-[24px] w-[24px]" />
          </motion.button>
        </div>
      </div>
    );
  };

  const CircleComponent = () => {
    return (
      <div className="flex absolute left-0 z-10 md:w-[200px] md:h-[200px] rounded-full bg-[#E7EBFF]" />
    );
  };

  const HeadlineComponent = () => {
    return (
      <div className="flex h-fit w-[300px] py-3 rounded-lg relative flex-col bg-[#6980BC]">
        <p className="px-[16px] text-[#F0F0F0] leading-[19.6px] font-bold">
          {event.title}
        </p>
        <p className="px-[16px] text-white/60 pt-2  text-[10px] font-bold">
          {event.date}
        </p>
      </div>
    );
  };

  const HashComponentOne = () => {
    return (
      <div className="bg-gradient-to-r from-[#F369E1] to-[#C1C4FF] via-[#7DD8FF] p-[1px] rounded-[100px]">
        <div className="flex justify-center items-center rounded-[100px] w-fit h-[30px] px-[16px] py-[6px] bg-gradient-to-r from-[#D6FCFE] via-[#E7E1FF] to-[#C1C4FF]">
          <p className="text-[#0F2E7B] text-[12px]">{event.hashTags[1]}</p>
        </div>
      </div>
    );
  };
  const HashComponentTwo = () => {
    return (
      <div className="bg-gradient-to-r from-[#F369E1] to-[#C1C4FF] via-[#7DD8FF] p-[1px] rounded-[100px]">
        <div className="flex justify-center items-center rounded-[100px] w-fit h-[30px] px-[16px] py-[6px] bg-gradient-to-r from-[#D6FCFE] via-[#E7E1FF] to-[#C1C4FF]">
          <p className="text-[#0F2E7B] text-[12px]">{event.hashTags[0]}</p>
        </div>
      </div>
    );
  };

  return (
    <motion.div
      className="flex relative w-[360px] h-[300px] -left-10"
      initial={{ opacity: 0 }}
      animate={{
        opacity: 1,
      }}
      transition={{
        delay: 0,
        duration: 0.2,
        ease: "easeInOut",
        // type: "spring", // Adds a spring effect for smooth scaling
        // stiffness: 200, // Controls the spring stiffness
        damping: 5, // Controls how the animation slows down
      }}
      whileHover={{
        scale: 1.05, // Scale up to 1.2 on hover
        // rotate: [0, 2, -2, 1, -1, 0],
      }}
    >
      <motion.div
        animate={{
          opacity: 1,
          y: [0, -8, 0], // Floating effect on the y-axis
          x: [0, 8, 0],
        }}
        transition={{
          delay: 0,
          duration: 3,
          ease: "easeInOut",
          repeat: Infinity, // Repeat the floating animation infinitely
          repeatType: "mirror", // Mirror the animation back and forth
        }}
        className="flex relative items-center justify-center w-full h-full "
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7 }}
          className="flex absolute left-0 top-0 w-full h-full"
        >
          <CircleComponent />
        </motion.div>
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7 }}
          className="flex absolute right-0 w-full h-full z-10"
        >
          <ImageComponent />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.2 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.2, duration: 0.7 }}
          className="flex absolute justify-end items-end -right-12 -bottom-8 w-full h-full  z-20"
        >
          <HeadlineComponent />
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 3, duration: 0.7 }}
          className="flex absolute justify-end items-end -right-12 bottom-[104px] w-full h-full  z-20"
        >
          <HashComponentTwo />
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 2, duration: 0.7 }}
          className="flex absolute justify-end items-end -right-12 bottom-16 w-full h-full  z-20"
        >
          <HashComponentOne />
        </motion.div>
      </motion.div>
    </motion.div>
  );
};

export default SingleImageContainer;
