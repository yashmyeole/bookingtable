import React, { useState } from "react";
import { motion } from "framer-motion";

import Hashtag from "../../../assets/hashtag.svg";
import One from "../../../assets/modiImage.png";
import RightIcon from "../../../assets/right-icon.svg";
import QuoteLeft from "../../../assets/quote-left.svg";
import QuoteRight from "../../../assets/quote-right.svg";

const VideoContainer = ({ event = 0, eventIndex, isInView }) => {
  const VideoComponent = () => {
    return (
      <div className="flex w-full h-full bg-cover relative">
        <PlayButton />
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1, duration: 0.9 }}
        >
          <Cloud />
        </motion.div>
      </div>
    );
  };

  const HeadlineAndHashTagComponent = () => {
    return (
      <div className="flex flex-col items-end gap-y-3">
        <div className="flex h-fit w-[310px] -right-12 py-3 rounded-lg relative flex-col bg-[#6980BC]">
          <p className="px-[16px] text-[#F0F0F0] leading-[19.6px] font-bold">
            {event.title}
          </p>
          <p className="px-[16px] text-white/60 pt-2  text-[10px] font-bold">
            {event.date}
          </p>
        </div>
      </div>
    );
  };

  const PlayButton = () => {
    return (
      <div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 1, duration: 0.9 }}
        className="relative z-10 -left-11"
      >
        <svg
          width="51"
          height="57"
          viewBox="0 0 51 57"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M46.3106 36.6373C52.5543 33.0298 52.5543 24.0148 46.3106 20.4036L14.4168 1.96481C8.16934 -1.64644 0.350586 2.86481 0.350586 10.0836V46.9611C0.350586 54.1798 8.16934 58.6911 14.4168 55.0761L46.3106 36.6373Z"
            fill="url(#paint0_linear_615_2364)"
          />
          <defs>
            <linearGradient
              id="paint0_linear_615_2364"
              x1="25.672"
              y1="56.3496"
              x2="25.672"
              y2="0.693359"
              gradientUnits="userSpaceOnUse"
            >
              <stop stopColor="#6779B8" />
              <stop offset="1" stopColor="#B6A7FF" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    );
  };

  const Cloud = () => {
    return (
      <div className="relative -left-[115px]">
        <svg
          className="rotate-6"
          width="469"
          height="320"
          viewBox="0 0 469 320"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M27.7944 143.822C-48.5806 35.4496 49.8299 -18.843 122 5.94545C194.17 30.7339 227.111 84.6292 287.958 40.196C364.018 -15.3456 382.103 46.4345 418.894 82.0599C456.12 118.106 405.952 169.921 451.529 200.6C497.106 231.279 443.504 287.707 348 314.5C271.597 335.934 223.642 281.04 209.495 247.118C180.751 257.842 104.169 252.195 27.7944 143.822Z"
            fill="#E7EBFF"
          />
        </svg>
      </div>
    );
  };

  const [isLoading, setIsLoading] = useState(true);
  const handleVideoLoad = () => {
    setIsLoading(false);
  };

  return (
    <motion.div
      className="flex relative w-[450px] h-[300px]  mx-4 -top-32 left-14"
      initial={{ opacity: 0 }}
      animate={{
        opacity: 1,
      }}
      transition={{
        delay: 0,
        duration: 0.2,
        ease: "easeInOut",
        // type: "spring", // Adds a spring effect for smooth scaling
        // stiffness: 200, // Controls the spring stiffness
        damping: 5, // Controls how the animation slows down
      }}
      whileHover={{
        scale: 1.05, // Scale up to 1.2 on hover
        // rotate: [0, 2, -2, 1, -1, 0],
      }}
    >
      {isInView && (
        <motion.div
          animate={{
            opacity: 1,
            y: [0, -8, 0], // Floating effect on the y-axis
            x: [0, 8, 0],
          }}
          transition={{
            delay: 0,
            duration: 3,
            ease: "easeInOut",
            repeat: Infinity, // Repeat the floating animation infinitely
            repeatType: "mirror", // Mirror the animation back and forth
          }}
          className="flex relative items-center justify-center w-full h-full "
        >
          <div className="flex absolute right-0 bottom-10 w-full h-full z-10">
            <div className="flex w-full h-full bg-cover relative">
              {/* <div className="flex absolute left-2 z-10 md:w-[200px] md:h-[200px] rounded-full bg-[#E7EBFF]" /> */}

              <PlayButton />
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1, duration: 0.9 }}
              >
                <Cloud />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1, duration: 0.9 }}
                className="absolute left-0 top-14 bottom-0 z-10"
              >
                <div className="relative w-full h-[250px]">
                  {isLoading && (
                    <div
                      role="status"
                      className="flex items-center justify-center md:w-[460px] md:h-[260px] bg-gray-300 rounded-lg dark:bg-gray-700"
                    >
                      <svg
                        className="w-full h-12 text-gray-200 dark:text-gray-600"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor"
                        viewBox="0 0 16 20"
                      >
                        <path d="M5 5V.13a2.96 2.96 0 0 0-1.293.749L.879 3.707A2.98 2.98 0 0 0 .13 5H5Z" />
                        <path d="M14.066 0H7v5a2 2 0 0 1-2 2H0v11a1.97 1.97 0 0 0 1.934 2h12.132A1.97 1.97 0 0 0 16 18V2a1.97 1.97 0 0 0-1.934-2ZM9 13a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-2a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2Zm4 .382a1 1 0 0 1-1.447.894L10 13v-2l1.553-1.276a1 1 0 0 1 1.447.894v2.764Z" />
                      </svg>
                      <span className="sr-only">Loading...</span>
                    </div>
                  )}
                  <iframe
                    className={`md:w-[460px] md:h-[260px] rounded-lg ${
                      isLoading ? "invisible" : "visible"
                    }`} // Hide the iframe while loading
                    src={event.videoUrl}
                    title="YouTube video player"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerPolicy="strict-origin-when-cross-origin"
                    allowFullScreen
                    onLoad={handleVideoLoad} // Set loading to false when the video loads
                    frameborder="0"
                    allowfullscreen
                  ></iframe>
                </div>
                <button
                  onClick={() => window.open(event.href, "_blank")}
                  className="flex justify-center items-center absolute -right-6 bottom-16 z-50 h-[46px] bg-[#5770C9] hover:bg-[#3a57c7] w-[46px] rounded-full p-2"
                >
                  <img src={RightIcon} className="h-[24px] w-[24px]" />
                </button>
              </motion.div>
            </div>
          </div>
          <motion.div
            initial={{ opacity: 0, x: 80 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1.6, duration: 0.7 }}
            className="flex absolute -bottom-2 -right-0 w-fit h-fit z-20"
          >
            <HeadlineAndHashTagComponent />
          </motion.div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default VideoContainer;
