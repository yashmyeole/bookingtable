import React from "react";
import { motion } from "framer-motion";
import RightIcon from "../../../assets/right-icon.svg";

const SquareImageContainer = ({ event = {}, eventIndex, isInView }) => {

  const HeadlineComponent = () => {
    return (
      <div className="flex h-fit w-[230px] rounded-lg py-3 relative flex-col bg-[#6980BC]">
        <p className="px-[16px] text-[#F0F0F0] leading-[19.6px] font-bold">
          { event.title }
        </p>
        <p className="px-[16px] text-white/60 pt-2  text-[10px] font-bold">
          { event.date }
        </p>
      </div>
    );
  };

  const SmallCircle = () => {
    return (
      <div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2, duration: 0.8 }}
        className="flex absolute -left-6 top-4 z-10 md:w-[75px] md:h-[75px] rounded-full bg-[#E7EBFF]"
      />
    );
  };

  const BigCircle = () => {
    return (
      <div className="flex absolute right-4 z-10 md:w-[230px] md:h-[230px] rounded-full bg-[#E7EBFF]" />
    );
  };

  const SmallImage = () => {
    return (
      <div className="absolute h-full -right-8 top-28 z-10">
        <img src={event.subImage} className="md:w-[140px] md:h-[120px] rounded-lg" />
      </div>
    );
  };

  const BigImage = () => {
    return (
      <div className="absolute h-full left-6 top-12 z-10">
        <img src={event.mainImage} className="md:w-[300px] md:h-[230px] rounded-lg" />
        <button
          onClick={() => window.open(event.href, "_blank")}
          className="flex justify-center z-50 items-center absolute -right-3 -top-5 h-[46px] bg-[#5770C9] hover:bg-[#3a57c7] w-[46px] rounded-full p-2">
          <img src={RightIcon} className="h-[24px] w-[24px]" />
        </button>
      </div>
    );
  };

  const Headline = () => {
    return <div></div>;
  };

  return (
    <motion.div
      className="flex relative w-[450px] h-[300px] mx-4 -top-20"
      initial={{ opacity: 0 }}
      animate={{
        opacity: 1,
      }}
      transition={{
        delay: 0,
        duration: 0.2,
        ease: "easeInOut",
        // type: "spring", // Adds a spring effect for smooth scaling
        // stiffness: 200, // Controls the spring stiffness
        damping: 5, // Controls how the animation slows down
      }}
      whileHover={{
        scale: 1.05, // Scale up to 1.2 on hover
        // rotate: [0, 2, -2, 1, -1, 0],
      }}
    >
      {isInView && (
        <motion.div
          animate={{
            opacity: 1,
            y: [0, -8, 0], // Floating effect on the y-axis
            x: [0, 8, 0],
          }}
          transition={{
            delay: 0,
            duration: 3,
            ease: "easeInOut",
            repeat: Infinity, // Repeat the floating animation infinitely
            repeatType: "mirror", // Mirror the animation back and forth
          }}
          className="flex relative items-center justify-center w-full h-full "
        >
          <motion.div className="flex absolute -right-2 bottom-0 w-full h-full z-20">
            <SmallCircle />
          </motion.div>
          <motion.div className="flex absolute right-0 bottom-0 w-full h-full z-20">
            <BigCircle />
          </motion.div>
          <motion.div className="flex h-fit w-fit z-20">
            <BigImage />
          </motion.div>
          <motion.div className="flex w-fit h-fit z-20">
            <SmallImage />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 1.2, duration: 0.9 }}
            className="flex absolute -left-8 bottom-0 w-fit h-fit z-20"
          >
            <HeadlineComponent />
          </motion.div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default SquareImageContainer;
