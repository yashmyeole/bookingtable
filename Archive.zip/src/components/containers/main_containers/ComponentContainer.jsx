import React from "react";
import { motion } from "framer-motion";
import ContainerTypeOne from "./CircleQuoteContainer";
import ContainerTypeTwo from "./HashtagContainer";
import ContainerTypeThree from "./SquareQuoteContainer";
import ContainerTypeFour from "./SingleImageContainer";
import ContainerTypeFive from "./SquareImageContainer";
import ContainerTypeSix from "./VideoContainer";
import CircleQuoteContainer from "./CircleQuoteContainer";
import SquareImageContainer from "./SquareImageContainer";
import SquareQuoteContainer from "./SquareQuoteContainer";
import SingleImageContainer from "./SingleImageContainer";
import HashtagContainer from "./HashtagContainer";
import VideoContainer from "./VideoContainer";
const ComponentContainer = ({ event = 0, eventIndex, isInView }) => {
  const containerType = event.containerType;
  // console.log("ContainerType: ", containerType);
  return (
    <motion.div
      className={`flex relative h-full `}
      initial={{ opacity: 0 }}
      animate={{
        opacity: 1,
      }}
      transition={{
        delay: 0,
        duration: 0.2,
        ease: "easeInOut",
        // type: "spring", // Adds a spring effect for smooth scaling
        // stiffness: 200, // Controls the spring stiffness
        damping: 5, // Controls how the animation slows down
      }}
      whileHover={{
        scale: 1.05, // Scale up to 1.2 on hover
        // rotate: [0, 2, -2, 1, -1, 0],
      }}
    >
      {isInView &&
        ((containerType === "1" && (
          <CircleQuoteContainer
            event={event}
            eventIndex={eventIndex}
            isInView={isInView}
          />
        )) ||
          (containerType === "2" && (
            <SquareImageContainer
              event={event}
              eventIndex={eventIndex}
              isInView={isInView}
            />
          )) ||
          (containerType === "3" && (
            <HashtagContainer
              event={event}
              eventIndex={eventIndex}
              isInView={isInView}
            />
          )) ||
          (containerType === "4" && (
            <VideoContainer
              event={event}
              eventIndex={eventIndex}
              isInView={isInView}
            />
          )) ||
          (containerType === "5" && (
            <SingleImageContainer
              event={event}
              eventIndex={eventIndex}
              isInView={isInView}
            />
          )) ||
          (containerType === "6" && (
            <SquareQuoteContainer
              event={event}
              eventIndex={eventIndex}
              isInView={isInView}
            />
          )))}
    </motion.div>
  );
};

export default ComponentContainer;
