import React, { useEffect, useRef } from "react";
import Line from "../../lines/Line";

import lineOne from "../../../assets/Line1.json";
import lineTwo from "../../../assets/Line2.json";
import lineThree from "../../../assets/Line3.json";
import lineFour from "../../../assets/Line4.json";
import lineFive from "../../../assets/Line5.json";
import lineSix from "../../../assets/Line6.json";

const LineContainer = ({ event, eventIndex, isInView, totalEvents }) => {
  const lineTypes = useRef([]);

  const lineWidth = ["w-[200px]", "w-[200px]", "w-[200px]", "w-[200px]"];

  useEffect(() => {
    lineTypes.current = [lineOne, lineTwo, lineThree, lineFour, lineFive, lineSix];
  }, []);

  // console.log("LineContainer -> isInView:  ", isInView);

  return (
    <div className={`flex w-[300px] h-full relative -z-[1000]`}>
      <Line
        delay={0}
        duration={1}
        isInView={isInView}
        lineSvg={lineTypes.current[event.lineType - 1]}
        eventIndex={eventIndex}
        totalEvents={totalEvents}
      />
    </div>
  );
};

export default LineContainer;
