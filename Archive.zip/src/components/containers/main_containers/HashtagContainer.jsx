import React from "react";
import { motion } from "framer-motion";

import Hashtag from "../../../assets/hashtag.svg";
import RightIcon from "../../../assets/right-icon.svg";

const HashtagContainer = ({ event = 0, eventIndex, isInView }) => {
  const ImageComponent = () => {
    return (
      <div className="flex w-full h-full relative">
        <motion.div className="flex flex-col absolute -left-40 bottom-7 justify-center z-10 py-3 rounded-md bg-[#6980BC] md:w-[240px] md:h-fit">
          <p className="px-[16px] text-[#F0F0F0] leading-[19.6px] font-bold">
            {event.title}
          </p>
          <p className="px-[16px] text-white/60 pt-2  text-[10px] font-bold">
            {event.date}
          </p>
        </motion.div>
        <motion.button
          onClick={() => window.open(event.href, "_blank")}
          className="flex justify-center z-50 items-center absolute -right-3 -bottom-3  h-[46px] bg-[#5770C9] hover:bg-[#3a57c7] w-[46px] rounded-full p-2"
        >
          <img src={RightIcon} className="h-[24px] w-[24px]" />
        </motion.button>
        <motion.div className="absolute right-0 bottom-0 md:w-[250px] md:h-[250px]">
          <img
            src={event.mainImage}
            className="md:w-[250px] md:h-[250px] rounded-[24px] "
          />
        </motion.div>
      </div>
    );
  };

  const BackgroungComponent = () => {
    return (
      <motion.div className="flex h-[230px] w-[230px] -z-10 relative flex-col">
        <motion.div className="w-full h-full bg-[#e7ebff] rounded-[32px]" />
        <motion.p className="w-full absolute top-3 left-[60px] text-[20px] font-light tracking-wider">
          {event.tag}
        </motion.p>
        <motion.div className="w-full absolute -left-5 -top-4">
          <img src={Hashtag} />
        </motion.div>
      </motion.div>
    );
  };

  return (
    <motion.div
      transition={{
        delay: 0,
        duration: 0.2,
        ease: "easeInOut",
        // type: "spring", // Adds a spring effect for smooth scaling
        // stiffness: 200, // Controls the spring stiffness
        damping: 5, // Controls how the animation slows down
      }}
      whileHover={{
        scale: 1.05, // Scale up to 1.2 on hover
        // rotate: [0, 2, -2, 1, -1, 0],
      }}
      className="flex relative w-[250px] h-[300px] bg-cover top-36 left-14"
    >
      {isInView && (
        <motion.div
          animate={{
            opacity: 1,
            y: [0, -8, 0], // Floating effect on the y-axis
            x: [0, 8, 0],
          }}
          transition={{
            delay: 0,
            duration: 3,
            ease: "easeInOut",
            repeat: Infinity, // Repeat the floating animation infinitely
            repeatType: "mirror", // Mirror the animation back and forth
          }}
          className="flex relative w-full h-full   "
        >
          <motion.div
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1.5, duration: 1 }}
            className="flex absolute w-full h-full z-30"
          >
            <ImageComponent />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 2 }}
            className="flex absolute right-12 top-0 z-10 h-fit "
          >
            <BackgroungComponent />
          </motion.div>
          <div className="flex absolute left-12 bottom-0 w-fit h-fit ">
            {/* <CommentComponent2 /> */}
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default HashtagContainer;
