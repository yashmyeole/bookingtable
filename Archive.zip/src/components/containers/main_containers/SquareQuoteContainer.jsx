import React from "react";
import { motion } from "framer-motion";
import RightIcon from "../../../assets/right-icon.svg";
import QuoteLeft from "../../../assets/quote-left.svg";
import QuoteRight from "../../../assets/quote-right.svg";

const SquareQuoteContainer = ({ event = {}, eventIndex, isInView }) => {
  const ImageComponent = () => {
    return (
      <div className="flex w-full h-full bg-cover relative">
        <div className="absolute right-0 top-0 ">
          <img
            src={event.mainImage}
            className="md:w-[280px] md:h-[260px] rounded-[24px]"
          />
        </div>
      </div>
    );
  };
  const ImageComponent2 = () => {
    return (
      <div className="flex w-full h-full bg-cover relative">
        <motion.div className="absolute left-[52px] top-8 md:w-fit md:h-fit">
          <img
            src={event.subImage}
            className="md:w-[130px] md:h-[110px] rounded-[15px] shadow-2xl"
          />
          <motion.button
            onClick={() => window.open(event.href, "_blank")}
            className="flex justify-center z-50 items-center absolute -top-4 -right-4 h-[42px] bg-[#5770C9] hover:bg-[#3a57c7] w-[42px] rounded-full p-2"
          >
            <img src={RightIcon} className="h-[21px] w-[21px]" />
          </motion.button>
        </motion.div>
      </div>
    );
  };

  const QuoteComponent = () => {
    return (
      <motion.div className="flex h-fit w-[350px] relative flex-col justify-center bg-[#E7EBFF] rounded-[15px]">
        <img
          src={QuoteLeft}
          className="h-[50px] w-[65px] absolute -top-8 -left-4"
        />
        <motion.p className="flex items-center w-[50%] tracking-tight leading-[22.4px] px-6  py-6 text-[16px] ">
          {event.Qoute}
        </motion.p>
        <img
          src={QuoteRight}
          className="h-[50px] w-[65px] absolute -bottom-4 right-[35%]"
        />
      </motion.div>
    );
  };
  const HeadlineComponent = () => {
    return (
      <div className="flex py-2 h-fit w-[250px] rounded-lg relative flex-col bg-[#6980BC]">
        <p className="px-[16px] text-[#F0F0F0] leading-[19.6px] font-bold">
          {event.title}
        </p>
        <p className="px-[16px] text-white/60 pt-2  text-[10px] font-bold">
          {event.date}
        </p>
      </div>
    );
  };

  return (
    <motion.div
      className="flex relative w-[490px] h-[320px] -left-16 -top-20"
      animate={{
        opacity: 1,
        y: [0, -5, 0], // Floating effect on the y-axis
        x: [0, 5, 0],
      }}
      transition={{
        delay: 0,
        duration: 2,
        ease: "easeInOut",
        // type: "spring", // Adds a spring effect for smooth scaling
        // stiffness: 200, // Controls the spring stiffness
        damping: 5, // Controls how the animation slows down
        repeat: Infinity, // Repeat the floating animation infinitely
        repeatType: "mirror", // Mirror the animation back and forth
      }}
      whileHover={{
        scale: 1.05, // Scale up to 1.2 on hover
        // rotate: [0, 2, -2, 1, -1, 0],
      }}
      key={eventIndex}
      id={eventIndex}
    >
      {isInView && (
        <motion.div
          animate={{
            opacity: 1,
          }}
          transition={{
            delay: 0,
            duration: 3,
            ease: "easeInOut",
          }}
          className="flex relative items-center w-full h-full "
        >
          <motion.div
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1, duration: 1.5 }}
            className="flex absolute left-1 w-full h-full z-10"
          >
            <ImageComponent />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: -100 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.9, duration: 1 }}
            className="flex absolute left-1 top-0 w-full h-full z-10"
          >
            <ImageComponent2 />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1.5, duration: 0.9 }}
            className="flex absolute left-3 bottom-0  h-fit "
          >
            <QuoteComponent />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.9, duration: 1 }}
            className="flex absolute -right-8 bottom-5 w-fit h-fit z-20"
          >
            <HeadlineComponent />
          </motion.div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default SquareQuoteContainer;
