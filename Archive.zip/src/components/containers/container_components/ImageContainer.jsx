import React from "react";

const ImageContainer = () => {
  return <div>ImageContainer</div>;
};

export default ImageContainer;
