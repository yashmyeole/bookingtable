import React from "react";

const TextContainer = () => {
  return <div>TextContainer</div>;
};

export default TextContainer;
