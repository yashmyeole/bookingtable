import React, { useState, useRef, useEffect } from 'react';
import './Seekbar.css';

const timelineData = [
  { year: 2000 }, { year: 2001 }, { year: 2002 }, { year: 2003 }, { year: 2004 }, 
  { year: 2005 }, { year: 2006 }, { year: 2007 }, { year: 2008 }, { year: 2009 },
  { year: 2010 }, { year: 2011 }, { year: 2012 }, { year: 2013 }, { year: 2014 },
  { year: 2015 }, { year: 2016 }, { year: 2017 }, { year: 2018 }, { year: 2019 },
  { year: 2020 }, { year: 2021 }, { year: 2022 }, { year: 2023 }, { year: 2024 },
  { year: 2025 }, { year: 2026 }, { year: 2027 }, { year: 2028 }, { year: 2029 },
  { year: 2030 }, { year: 2031 }, { year: 2032 }, { year: 2033 }, { year: 2034 },
  { year: 2035 }, { year: 2036 }, { year: 2037 }, { year: 2038 }, { year: 2039 },
  { year: 2040 }, { year: 2041 }, { year: 2042 }, { year: 2043 }, { year: 2044 },
  { year: 2045 }, { year: 2046 }, { year: 2047 }
];

const Seekbar = ({ handlejump }) => {
  const [value, setValue] = useState(0);
  const [currentYear, setCurrentYear] = useState(timelineData[0].year);
  const seekbarRef = useRef(null);
  const thumbRef = useRef(null);
  const isDragging = useRef(false);

  const calculateYear = (value) => {
    const index = Math.round((value / 100) * (timelineData.length - 1));
    return timelineData[index].year;
  };

  const handleDrag = (clientY) => {
    const seekbar = seekbarRef.current;
    const seekbarRect = seekbar.getBoundingClientRect();
    const offsetY = clientY - seekbarRect.top;
    const newValue = (offsetY / seekbarRect.height) * 100;
    const boundedValue = Math.min(Math.max(newValue, 0), 100);
    setValue(boundedValue);
    handlejump(Math.floor(boundedValue));
    setCurrentYear(calculateYear(boundedValue));
  };

  const handleMouseDown = (e) => {
    e.preventDefault();
    isDragging.current = true;
    handleDrag(e.clientY);
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const handleMouseMove = (e) => {
    if (isDragging.current) {
      handleDrag(e.clientY);
    }
  };

  const handleMouseUp = () => {
    isDragging.current = false;
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
  };

  const handleTouchStart = (e) => {
    e.preventDefault();
    isDragging.current = true;
    handleDrag(e.touches[0].clientY);
    document.addEventListener('touchmove', handleTouchMove);
    document.addEventListener('touchend', handleTouchEnd);
  };

  const handleTouchMove = (e) => {
    if (isDragging.current) {
      handleDrag(e.touches[0].clientY);
    }
  };

  const handleTouchEnd = () => {
    isDragging.current = false;
    document.removeEventListener('touchmove', handleTouchMove);
    document.removeEventListener('touchend', handleTouchEnd);
  };

  const handleSeekbarClick = (e) => {
    handleDrag(e.clientY);
  };

  useEffect(() => {
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleTouchEnd);
    };
  }, []);

  return (
    <div className="seekbar-container" onClick={handleSeekbarClick} ref={seekbarRef}>
      <div className="seekbar-track">
        {timelineData.map((item, index) => (
          <div key={item.year} className="seekbar-year">
            <div className="seekbar-dot" />
          </div>
        ))}
        <div className="seekbar-progress" style={{ height: `${value}%` }}></div>
        <div
          className="seekbar-thumb"
          ref={thumbRef}
          style={{ top: `${value}%` }}
          onMouseDown={handleMouseDown}
          onTouchStart={handleTouchStart}
        >
          <div className="year-overlay">{currentYear}</div>
        </div>
      </div>
    </div>
  );
};

export default Seekbar;
