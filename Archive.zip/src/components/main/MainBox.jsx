import React, { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import ComponentContainer from "../containers/main_containers/ComponentContainer";
import LineContainer from "../containers/main_containers/LineContainer";
// import timelineJson from "../../utils/config/Config.json";
import timelineJson from "../../utils/config/ConfigTemp.json";
import { Player } from "@lottiefiles/react-lottie-player";
import LandingLottie from "../../assets/NamoWO.json";
import LandingLottie2 from "../../assets/NaMoName.json";
import Seekbar from "./SeekbarH";
import Background from "../../assets/Background2.png";
import SwipeAnim from "../../assets/arrowAnim.json";

function debounce(func, delay) {
  let timeoutId;
  return function (...args) {
    if (timeoutId) clearTimeout(timeoutId);
    timeoutId = setTimeout(() => {
      func.apply(this, args);
    }, delay);
  };
}

const MainBox = ({
  isBeginClicked,
  setIsBeginClicked,
  showModiAnimation,
  setShowModiAnimation,
  handleScroll,
}) => {
  const [previousIndex, setPreviousIndex] = useState(null); // Track the previous index
  const currentYear = useRef(2024); // Track the current year
  const isScrolled = useRef(false); // Track if the user has scrolled
  const timeout = useRef(null); // Track the timeout
  
  

  const resetIsScrolling = () => { 
    isScrolled.current = false;
    console.log("Scrolled R: ", isScrolled);
  }

  const debouncedIsScrolling = useCallback(debounce(resetIsScrolling, 1000), [
    resetIsScrolling,
  ]);

  const isScrolling = () => {
    isScrolled.current = true;
    console.log("Scrolled F: ", isScrolled);
    debouncedIsScrolling();
  }

  const onScrollFinished = () => { 
    console.log("Scrolled N: ", isScrolled);
     isScrolled.current = false;
  }

  useEffect(() => {
    const element = document.querySelector("div#mymMainElement");
    element.addEventListener("wheel", isScrolling);
    element.addEventListener("scroll", isScrolling);
    element.addEventListener("scrollend", onScrollFinished);

    return () => {
      element.removeEventListener("wheel", isScrolling);
      element.removeEventListener("scroll", isScrolling);
      element.removeEventListener("scrollend", onScrollFinished);
    }
   }, []);
  
  useEffect(() => {
    isBeginClicked &&
      setTimeout(() => {
        setShowModiAnimation(true);
      }, 3000);
  }, [isBeginClicked === true]);

  const debouncedHandleScroll = useCallback(debounce(handleScroll, 1000), [
    handleScroll,
  ]);


  useEffect(() => {
    console.log("Current Year: ", currentYear.current)
    debouncedHandleScroll(currentYear.current);
  }, [currentYear.current]);
  
   

  const getAllEvents = (timeline) => {
    return timeline.flatMap((yearData) => {
      const year = Object.keys(yearData)[0];
      const monthsArray = Object.values(yearData)[0];
      return monthsArray.flatMap((monthData) => {
        return Object.entries(monthData).flatMap(([month, events]) => {
          return events.map((event) => ({
            ...event,
            year,
            month,
          }));
        });
      });
    });
  };

  const totalEvents = getAllEvents(timelineJson.timeline);

  const [componentVisibility, setComponentVisibility] = useState(
    new Array(totalEvents.length).fill(false).map((_, index) => index < 0)
  );
  const [lineVisibility, setLineVisibility] = useState(
    new Array(totalEvents.length).fill(false).map((_, index) => index < 0)
  );

  const handleVisibility = (
    ref,
    setVisibility,
    eventIndex,
    threshold = 0.8
  ) => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        // console.log(entry);
        if (entry.intersectionRatio >= threshold) {
          setVisibility((prev) => {
            const newVisibility = [...prev];
            newVisibility[eventIndex] = true;
            // console.log("Current Year From Visibility: ", totalEvents[eventIndex].year);

            // console.log("Target Id: ", entry.target.id);
            // debouncedHandleScroll(eventIndex);

            let lastUpdate = false; 

            if (currentYear.current !== totalEvents[eventIndex].year && !lastUpdate && isScrolled.current) {
              currentYear.current = totalEvents[eventIndex].year;
              lastUpdate = true;
              const timeout  = setTimeout(() => {
                lastUpdate = false;
                clearTimeout(timeout);
              }, 500);
            }
            return newVisibility;
          });
        }
      },
      {
        root: null, // Use the viewport as the root
        rootMargin: `0px -${(1 - threshold) * threshold * 100}% 0px 0px`, // 20% margin on the right
        threshold: [0, 1], // Trigger when elements cross 80%
      }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
    };
  };

  const modiRef = useRef(null);

  //   const screen = document.querySelector('.mouse-cursor-gradient-tracking');

  // screen.addEventListener('mousemove', e => {
  //   const rect = e.target.getBoundingClientRect();
  //   const x = e.clientX - rect.left;
  //   const y = e.clientY - rect.top;

  //   screen.style.setProperty('--x', x + 'px');
  //   screen.style.setProperty('--y', y + 'px');
  // });

  useEffect(() => {
    const timer = setTimeout(() => {
      if (modiRef.current) {
        modiRef.current.play(); // Start the animation after 3 seconds
      }
    }, 7000); // 3-second delay

    return () => clearTimeout(timer); // Cleanup the timer on component unmount
  }, []);

  return (
    <div className={`flex flex-row justify-center items-center`} id="mymMainElement">
      <div
        className={`flex flex-col relative md:flex-row scroll-container md:overflow-y-hidden justify-center items-center h-[100vh] ${
          showModiAnimation ? "overflow-x-auto" : "overflow-hidden max-w-screen"
        }`}
      >
        <img
          src={Background}
          className="absolute w-[100%] h-screen -z-[1100]"
        />
        <div
          className={`flex flex-col md:flex-row items-center md:h-[100vh] text-white `}
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="flex relative w-screen h-screen justify-start items-center flex-col"
          >
            {/* Text */}
            <motion.div
              initial={{ y: 0, opacity: 1 }}
              animate={{
                y: isBeginClicked ? -150 : 0,
                opacity: isBeginClicked ? 0 : 1,
              }}
              transition={{ duration: 2, delay: 0.5 }}
              className="flex absolute flex-col text-center justify-center items-center h-full "
            >
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
                className="text-[24px] text-black/70 lato-light"
              >
                Discover the extraordinary journey of
              </motion.p>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
                className="text-[96px] text-black lato-bold"
              >
                <div>
                  <h1>Narendra Modi</h1>
                </div>
              </motion.p>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1.5 }}
                className="text-[20px] text-black font-thin mt-3"
              >
                From humble beginnings to historic achievements shaping the
                nation’s future.
              </motion.p>

              {/* Begin Button */}
              <button
                className="learn-more"
                style={{ cursor: "pointer", marginTop: "100px", zIndex: 10000 }}
                onClick={() => {
                  setIsBeginClicked(true);
                }}
              >
                <span className="circle" aria-hidden="true">
                  <span className="icon arrow"></span>
                </span>
                <span className="button-text">Begin</span>
              </button>
            </motion.div>

            {/* Modi Lottie Animation */}
            {isBeginClicked && showModiAnimation && (
              <motion.div
                initial={{ opacity: 0, y: -110 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 2 }}
                className="flex absolute items-center justify-center h-[85%] w-[100%]"
              >
                <Player
                  autoplay
                  loop={false}
                  src={LandingLottie2}
                  keepLastFrame
                  className="h-full"
                />
              </motion.div>
            )}

            {/* Scroll to continue */}
            {isBeginClicked && showModiAnimation && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 4, duration: 1 }}
                className="flex flex-col absolute items-center justify-center bottom-[8vh] left-[45%] w-fit h-[100px]"
              >
                <Player
                  autoplay
                  loop={true}
                  src={SwipeAnim}
                  className="-rotate-90 w-16 h-16"
                />
                <p className="text-black/50 -mt-2">Scroll to continue</p>
              </motion.div>
            )}
          </motion.div>
        </div>
        {totalEvents.map((event, eventIndex) => {
          const componentRef = useRef(null);
          const lineRef = useRef(null);

          useEffect(() => {
            const cleanupComponentObserver = handleVisibility(
              componentRef,
              setComponentVisibility,
              eventIndex,
              0.22 // 80% of the width, leaving 20% margin on the right
            );

            const cleanupLineObserver = handleVisibility(
              lineRef,
              setLineVisibility,
              eventIndex,
              0.1
            );

            return () => {
              cleanupComponentObserver();
              cleanupLineObserver();
            };
          }, [eventIndex]);


          return (
            <React.Fragment key={eventIndex}>
              <motion.div
                ref={componentRef}
                // id={totalEvents[eventIndex].year}
                className={`flex md:h-[650px] md:w-fit ${
                  eventIndex % 2 === 0 ? "items-start" : "items-end"
                } ${totalEvents[eventIndex].year}`}
                initial={{ opacity: 0 }}
                animate={{ opacity: componentVisibility[eventIndex] ? 1 : 0 }}
                transition={{
                  delay: 1,
                  duration: 1,
                  ease: "easeInOut",
                }}
              >
                <div className="relative">
                  <ComponentContainer
                    event={event}
                    eventIndex={eventIndex}
                    isInView={componentVisibility[eventIndex]}
                  />
                </div>
              </motion.div>

              <motion.div
                ref={lineRef}
                className="flex md:h-[580px] md:w-fit"
                initial={{ opacity: 0 }}
                animate={{ opacity: lineVisibility[eventIndex] ? 1 : 0 }}
                transition={{
                  delay: 0,
                  ease: "easeInOut",
                }}
              >
                <LineContainer
                  event={event}
                  eventIndex={eventIndex}
                  isInView={lineVisibility[eventIndex]}
                  totalEvents={totalEvents.length}
                />
              </motion.div>
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};

export default MainBox;