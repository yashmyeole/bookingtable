import React, { useState, useRef, useEffect } from "react";

const timelineData = [
  { year: 2024 },
  { year: 2023 }, 
  { year: 2022 },
  { year: 2021 },
  { year: 2020 },
  { year: 2019 },
  { year: 2018 },
  { year: 2017 },
  { year: 2016 },
  { year: 2015 },
];

const Seekbar = ({ handlejump, showModiAnimation, yearToMove }) => {
  const [value, setValue] = useState(0);
  const [currentYear, setCurrentYear] = useState(timelineData[0].year);
  const seekbarRef = useRef(null);
  const isDragging = useRef(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const calculateYear = (value) => {
    const index = Math.round((value / 100) * (timelineData.length));
    return timelineData[index].year;
  };

  const calculateValueFromYear = (year) => {
    const yearIndex = timelineData.findIndex((item) => item.year == year);
    return (yearIndex / (timelineData.length - 1)) * 100;
  };

  const handleDrag = (clientX) => {
    const seekbar = seekbarRef.current;
    const seekbarRect = seekbar.getBoundingClientRect();
    const offsetX = clientX - seekbarRect.left;
    const newValue = (offsetX / seekbarRect.width) * 100;
    const boundedValue = Math.min(Math.max(newValue, 0), 100);
    setValue(boundedValue);
    const curYear = calculateYear(boundedValue);
    setCurrentYear(curYear);
    handlejump(curYear);
  };

  const handleMouseDown = (e) => {
    e.preventDefault();
    isDragging.current = true;
    handleDrag(e.clientX);
    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
  };

  const handleMouseMove = (e) => {
    if (isDragging.current) {
      handleDrag(e.clientX);
    }
  };

  const handleMouseUp = () => {
    isDragging.current = false;
    document.removeEventListener("mousemove", handleMouseMove);
    document.removeEventListener("mouseup", handleMouseUp);
  };

  const handleTouchStart = (e) => {
    e.preventDefault();
    isDragging.current = true;
    handleDrag(e.touches[0].clientX);
    document.addEventListener("touchmove", handleTouchMove);
    document.addEventListener("touchend", handleTouchEnd);
  };

  const handleTouchMove = (e) => {
    if (isDragging.current) {
      handleDrag(e.touches[0].clientX);
    }
  };

  const handleTouchEnd = () => {
    isDragging.current = false;
    document.removeEventListener("touchmove", handleTouchMove);
    document.removeEventListener("touchend", handleTouchEnd);
  };

  const handleSeekbarClick = (e) => {
    handleDrag(e.clientX);
  };

  const handleScroll = (e) => {
    // console.log("Scrolling: ", isScrolled, e);
    if (!isScrolled) {
      const timeline = setTimeout(() => {
        setIsScrolled(true);
        clearTimeout(timeline);
      }, 3000);
    }
  };

  //  useEffect(() => {
  // showModiAnimation &&
  //  }, [showModiAnimation])

  useEffect(() => {
    document.addEventListener("wheel", handleScroll);

    return () => {
      document.removeEventListener("scroll", handleScroll);
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.removeEventListener("touchmove", handleTouchMove);
      document.removeEventListener("touchend", handleTouchEnd);
    };
  }, []);

  useEffect(() => {
    if (yearToMove) {
      const newValue = calculateValueFromYear(yearToMove);
      console.log("NewVAlue: ", newValue, "yearToMove: ", yearToMove);
      setValue(newValue);
      setCurrentYear(yearToMove);
    }
  }, [yearToMove]);

  return (
    <>
      {isScrolled && showModiAnimation && (
        <div
          className="absolute flex justify-center items-center w-[100%] h-[8%] cursor-pointer p-5 overflow-x-auto bottom-5 bg-transparent"
          onClick={handleSeekbarClick}
        >
          <div
            className="flex flex-row w-[70%] h-full rounded-md relative items-center justify-between"
            ref={seekbarRef}
          >
            {timelineData.map((item, index) => (
              <div
                key={item.year}
                className="flex flex-row items-center flex-shrink-0"
              >
                <div className="w-[10px] h-[10px] bg-[#b4b0a7] rounded-full mx-1" />
              </div>
            ))}
            <div
              className="w-[16px] h-[16px] absolute cursor-grab transition-all duration-300 ease-in-out"
              style={{ left: `${value - 2.5}%` }}
              onMouseDown={handleMouseDown}
              onTouchStart={handleTouchStart}
            >
              <div className="absolute bg-[#CD6A00] text-white px-4 py-3 rounded-full -top-5">
                {currentYear}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Seekbar;
