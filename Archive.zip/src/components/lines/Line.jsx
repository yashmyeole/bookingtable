import React, { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Player } from "@lottiefiles/react-lottie-player";

const Line = ({ delay = 0, duration = 6, isInView, lineSvg, eventIndex, totalEvents }) => {
  const playerRef = useRef(null);

  const location = eventIndex % 2 === 0 ? "left" : "right";

  // Play animation when in view
  useEffect(() => {
    if (isInView && playerRef.current) {
      playerRef.current.play(); // Play Lottie animation
    } else if (playerRef.current) {
      playerRef.current.stop(); // Stop animation when out of view
    }
  }, [isInView]);

  return (
    <>
      { eventIndex !== totalEvents - 1 && (<motion.div
      style={{ overflow: "hidden" }}
      className={`w-full absolute 
        ${eventIndex % 6 === 0 ? "top-32 left-6" : "" } 
        ${eventIndex % 6 === 1 ? "top-44 left-6" : "" } 
        ${eventIndex % 6 === 2 ? "top-72 left-16" : "" } 
        ${eventIndex % 6 === 3 ? "top-56 left-16" : "" } 
        ${eventIndex % 6 === 4 ? "top-32 -left-6" : ""} 
        ${eventIndex % 6 === 5 ? "top-48 -left-7 scale-110" : ""} 
        
        flex`}
    >
      <Player
        // className={`w-full ${location !== "left" && "scale-y-[-1]"}`}
        className={`w-full`}
        ref={playerRef}
        autoplay={false} // Disable autoplay
        loop={false} // Disable looping
        src={lineSvg} // Unique Lottie source
        keepLastFrame={true} // Keep the last frame of the animation
        speed={2}
      />
    </motion.div>)}
    </>
  );
};

export default Line;
