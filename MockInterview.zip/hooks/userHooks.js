import axiosInstance from "@/api/axiosInstance";
import { useMutation, useQuery } from "@tanstack/react-query";
import axios from "axios";
// import { signOut } from "next-auth/react";
import { toast } from "react-toastify";

const clearSession = async () => {
  // const session = await getSession();
  // if (session) {
  // await signOut({ redirect: false });
  console.log("Session cleared");
  // }
};

const useGetUserProfile = () => {
  const query = useQuery({
    queryKey: ["getProfile"],
    queryFn: () =>
      axiosInstance.get(`/mockInterview/api/getProfile`, {
        suppressToast: true, // ✅ suppress toast for this call
      }),
    staleTime: 1000 * 60 * 5,
    refetchOnWindowFocus: false,
    gcTime: 1000 * 60,
  });

  return query;
};

const useCreateUserProfile = () => {
  const mutation = useMutation({
    mutationFn: (userData) =>
      axiosInstance.post(`/mockInterview/api/createProfile`, userData),
      onSuccess: (data) => {
      localStorage.removeItem('profileData'); 
      localStorage.removeItem('form-experience'); 
      localStorage.removeItem('payout'); 
    }
  });

  return mutation;
};

const useGetMentors = (body) => {
  const query = useQuery({
    queryKey: ["getMentors", body],
    queryFn: () => axiosInstance.post(`/mockInterview/api/getMentors`, body),
    staleTime: 1000 * 60 * 5,
    refetchOnWindowFocus: false,
    gcTime: 1000 * 60,
  });

  return query;
};

// const useGetRoles = () => {
//   const query = useQuery({
//     queryKey: ["getRoles"],
//     queryFn: () =>
//       axiosInstance.get(`${baseUrl}/centralized-mod/moderation/getRoles`),
//     staleTime: 1000 * 60 * 5,
//     refetchOnWindowFocus: false,
//     gcTime: 1000 * 60,
//   });

//   return query;
// };
// const useGetMyProfile = () => {
//   const query = useQuery({
//     queryKey: ["getTokenDetails"],
//     queryFn: () =>
//       axiosInstance.post(
//         `${baseUrl}/centralized-mod/moderation/getTokenDetails`
//       ),
//     staleTime: 1000 * 60 * 5,
//     refetchOnWindowFocus: false,
//     gcTime: 1000 * 60,
//   });

//   return query;
// };

// const removeUser = ({ userId, refetch }) => {
//   axiosInstance
//     .post(`${baseUrl}/centralized-mod/moderation/removeUser`, {
//       id: [{ userId: userId }],
//     })
//     .then((res) => {
//       if (res.status === 200) {
//         toast.success("User removed successfully");
//         refetch();
//       }
//     });
// };

// const addUser = async (data) => {
//   const response = await axiosInstance.post(
//     baseUrl + "/centralized-mod/moderation/createUser",
//     data
//   );
//   return response.data; // Returns the API response
// };

// const useAddUser = (refetch) => {
//   return useMutation({
//     mutationFn: addUser,
//     onSuccess: (data) => {
//       if (data?.statusCode == 200) {
//         toast.success("User Added successfully! 🎉");
//         // console.log("API Response:", data);
//         refetch();
//       } else {
//         toast.error(data?.statusMsg);
//       }
//     },
//     onError: (error) => {
//       toast.error(
//         `Failed to add user ❌: ${
//           error.response?.data?.message || error.message
//         }`
//       );
//       console.error("Error:", error);
//     },
//   });
// };
// const editUser = async (data) => {
//   const response = await axiosInstance.post(
//     baseUrl + "/centralized-mod/moderation/createUser",
//     data
//   );
//   return response.data; // Returns the API response
// };

// const useEditUser = ({ refetch }) => {
//   return useMutation({
//     mutationFn: editUser,
//     onSuccess: (data) => {
//       if (data?.statusCode == 200) {
//         toast.success("User Edited successfully! 🎉");
//         // console.log("API Response:", data);
//         refetch();
//       } else {
//         toast.error(data?.statusMsg);
//       }
//     },
//     onError: (error) => {
//       toast.error(
//         `Failed to edit user ❌: ${
//           error.response?.data?.message || error.message
//         }`
//       );
//       console.error("Error:", error);
//     },
//   });
// };

// const generateToken = ({ email, setLoading }) => {
//   axios
//     .post(baseUrl + "/centralized-mod/moderation/generateToken", {
//       emailId: email,
//     })
//     .then((res) => {
//       if (res.data.statusCode === 200) {
//         axios
//           .post(
//             baseUrl + "/centralized-mod/moderation/getTokenDetails",
//             {},
//             { headers: { Authorization: `Bearer ${res.data.token}` } }
//           )
//           .then((res2) => {
//             if (res2.status === 200) {
//               typeof window !== "undefined" &&
//                 localStorage.setItem("token", res.data.token);
//               typeof window !== "undefined" &&
//                 localStorage.setItem("userId", res2.data.userid);
//               toast.success("User Authenticated Successfully");
//               // const { data, isFetched } = useGetUserDetails({
//               //   userId: res2.data.userid,
//               // });
//               // if (isFetched) {
//               //   localStorage.setItem("role", data?.data.role);
//               //   setLoading(false);
//               axios
//                 .post(
//                   `${baseUrl}/centralized-mod/moderation/getUserProfile`,
//                   {
//                     userId: res2.data.userid,
//                   },
//                   { headers: { Authorization: `Bearer ${res.data.token}` } }
//                 )
//                 .then((res3) => {
//                   // console.log(res3.data);
//                   typeof window !== "undefined" &&
//                     localStorage.setItem("role", res3.data.role);
//                   typeof window !== "undefined" &&
//                     localStorage.setItem("profilePic", res3.data.profilePic);
//                   typeof window !== "undefined" &&
//                     localStorage.setItem("roleId", res3.data.roleId);
//                   typeof window !== "undefined" &&
//                     localStorage.setItem("emailId", res3.data.emailId);
//                   typeof window !== "undefined" &&
//                     localStorage.setItem("name", res3.data.name);
//                   typeof window !== "undefined" &&
//                     localStorage.setItem("phoneNumber", res3.data.phoneNumber);

//                   window.location.href = "/moderation/dashboard";
//                 });
//               // }
//             } else {
//               toast.error(res2.data.message);
//               setLoading(false);
//             }
//           });
//       } else if (res.data.statusCode === 404) {
//         toast.error("Email not registered");
//         setLoading(false);
//         clearSession();
//       } else {
//         toast.error(res.data.statusMsg);
//         setLoading(false);
//       }
//     });
// };

// const useGetUserDetails = ({ userId, enable }) => {
//   const query = useQuery({
//     queryKey: ["getUserDetails"],
//     enabled: enable,
//     queryFn: () =>
//       axiosInstance.post(
//         `${baseUrl}/centralized-mod/moderation/getUserProfile`,
//         {
//           userId: userId,
//         }
//       ),
//     staleTime: 1000 * 60 * 5,
//     refetchOnWindowFocus: false,
//     gcTime: 1000 * 60 * 60,
//   });

//   return query;
// };

// const addUserInCampaign = async (data) => {
//   const response = await axiosInstance.post(
//     baseUrl + "/centralized-mod/moderation/createUserByCampaign",
//     data
//   );
//   return response.data; // Returns the API response
// };
// const addUserByCampaign = ({ refetch }) => {
//   return useMutation({
//     mutationFn: addUserInCampaign,
//     onSuccess: (data) => {
//       if (data.statusCode == 200) {
//         toast.success("User Added successfully! 🎉");
//         console.log("API Response:", data);
//         refetch();
//       } else {
//         toast.error(data.statusMsg);
//       }
//     },
//     onError: (error) => {
//       toast.error(
//         `Failed to edit users ❌: ${
//           error.response?.data?.message || error.message
//         }`
//       );
//       console.error("Error:", error);
//     },
//   });
// };
// const removeUserInCampaign = async (data) => {
//   const response = await axiosInstance.post(
//     baseUrl + "/centralized-mod/moderation/removeUserFromCampaign",
//     data
//   );
//   return response.data; // Returns the API response
// };
// const removeUserByCampaign = ({ refetch }) => {
//   return useMutation({
//     mutationFn: removeUserInCampaign,
//     onSuccess: (data) => {
//       if (data?.statusCode == 200) {
//         toast.success("User Removed successfully! 🎉");
//         console.log("API Response:", data);
//         refetch();
//       } else {
//         toast.error(data?.statusMsg);
//       }
//     },
//     onError: (error) => {
//       toast.error(
//         `Failed to edit users ❌: ${
//           error.response?.data?.message || error.message
//         }`
//       );
//       console.error("Error:", error);
//     },
//   });
// };

export {
  // useGetAllUsers,
  // removeUser,
  // useAddUser,
  // useEditUser,
  // useGetMyProfile,
  // useGetRoles,
  // generateToken,
  useGetUserProfile,
  useCreateUserProfile,
  useGetMentors,
  // addUserByCampaign,
  // removeUserByCampaign,
};
