import { useMutation, useQuery } from "@tanstack/react-query";
import axiosInstance from "@/api/axiosInstance";
import { toast } from "react-toastify";

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL;

const useGetFeedbacks = ({ date, status }) => {
  const query = useQuery({
    queryKey: ["getFeedbackStatusDetailsList", date, status],
    queryFn: () =>
      axiosInstance.post(
        `${baseUrl}/mockInterview/api/getFeedbackStatusDetailsList`,
        {
          date: date || null,
          status: status || "",
        }
      ),
    staleTime: 1000 * 60 * 20,
    refetchOnWindowFocus: false,
    gcTime: 1000 * 60 * 60 * 24,
    // enabled: date != "" || status != "",
  });
  return query;
};

const useGetFeedbackDetails = ({ interviewId }) => {
  const query = useQuery({
    queryKey: ["getFeedbackDetails", interviewId],
    queryFn: () =>
      axiosInstance.post(`${baseUrl}/mockInterview/api/getFeedbackDetails`, {
        interviewId: interviewId || null,
      }),
    staleTime: 1000 * 60 * 20,
    refetchOnWindowFocus: false,
    gcTime: 1000 * 60 * 60 * 24,
    // enabled: date != "" || status != "",
  });
  return query;
};

export { useGetFeedbacks, useGetFeedbackDetails };
