import axiosInstance from "@/api/axiosInstance";
import { userAtom } from "@/store/authAtoms";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { getDefaultStore, useAtom, useSetAtom } from "jotai";
import { useRouter } from "next/navigation";
import { toast } from "react-toastify";
import { useGetUserProfile } from "./userHooks";
import { useEffect } from "react";

// import { signOut } from "next-auth/react";
// import { getSession } from "next-auth/react";

/**
 * Payload example:
 * {
 *   type: "Mobile",
 *   value: "9999977777",
 *   deviceId: 1289,
 *   resendFlag: "0"
 * registration:1
 * }
 */

const generateOtp = async (payload) => {
  try {
    const response = await axiosInstance.post(
      "/mockInterview/api/generateOTP",
      payload
    );
    return response.data;
  } catch (error) {
    // ✅ Rethrow to allow React Query's onError to catch it
    throw error;
  }
};
const validateOtp = async (payload) => {
  try {
    const response = await axiosInstance.post(
      "/mockInterview/api/verifyOTP", // Adjust endpoint if different
      payload
    );
    return response.data;
  } catch (error) {
    console.error("validateOtp API error:", error);
    throw error; // re-throw to let React Query handle it
  }
};
const createAccount = async (payload) => {
  try {
    const response = await axiosInstance.post(
      "/mockInterview/api/createAccount",
      payload
    );
    return response.data;
  } catch (error) {
    console.error("createAccount API error:", error);
    throw error;
  }
};

const getTokenDetails = async () => {
  try {
    const response = await axiosInstance.get(
      "/mockInterview/api/getTokenDetails",
      {
        suppressToast: true, // ✅ suppress toast for this call
      }
    );

    return response?.data || null;
  } catch (error) {
    // console.error("🔴 getTokenDetails error:", error);
    return null; // return null so token check fails silently
  }
};

const useGenerateOtpMutation = () => {
  return useMutation({
    mutationFn: generateOtp,
    onSuccess: (data) => {
      if (data?.status === "Success") {
        toast.success(data?.statusMsg || "OTP sent successfully");
      } else {
        toast.error(data?.statusMsg || "Failed to generate OTP");
      }
    },
    onError: (error) => {
      // Global error toast is already handled in the Axios interceptor
      console.error("Generate OTP Error:", error);
    },
  });
};
const useValidateOtpMutation = () => {
  return useMutation({
    mutationFn: validateOtp,
    onError: (error) => {
      const msg = error?.response?.data?.statusMsg;
      // toast.error(msg || "OTP validation failed");
    },
  });
};
const useCreateAccountMutation = (onAccountSuccess) => {
  return useMutation({
    mutationFn: createAccount,
    onSuccess: (data) => {
      if (data?.status === "Success") {
        // toast.success(data?.statusMsg || "Account created successfully");
        onAccountSuccess?.(data); // Trigger follow-up like redirect or storing token
      } else {
        toast.error(data?.message || "Account creation failed");
      }
    },
    // onError: (error) => {
    //   const msg = error?.response?.data?.statusMsg;
    //   toast.error(msg || "Something went wrong during account creation");
    // },
  });
};

export const logout = async () => {
  const response = await axiosInstance.post("/mockInterview/api/logout");
  return response.data;
};
const useLogoutMutation = () => {
  const router = useRouter();
  const [userData, setuserData] = useAtom(userAtom);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: logout,
    onSuccess: () => {
      toast.success("Logged out successfully");
      // 1. 🧼 Clear cookie
      document.cookie = "token=; Max-Age=0; path=/;";

      // 2. 🧼 Reset global atom state
      // jotaiStore.set(userAtom, null);
      setuserData(null);

      // 3. 🧼 Clear all TanStack cache (optional but recommended)
      queryClient.clear();

      // 5. 🔁 Optional: Redirect to login
      router.push("/");
    },
    onError: (error) => {
      console.error("Logout failed", error);
      toast.error(
        error?.response?.data?.statusMsg || "Logout failed. Try again."
      );
    },
  });
};
const useTokenDetailsQuery = (enabled = true) => {
  return useQuery({
    queryKey: ["token-details"],
    queryFn: getTokenDetails,
    enabled,
    // onSuccess: (data) => {
    //   toast.success(data?.message || "User details fetched successfully");
    // },
    // onError: (error) => {
    //   const msg = error?.response?.data?.message || error.message;
    //   toast.error(msg || "Failed to fetch token details");
    // },
    staleTime: 5 * 60 * 1000, // optional: cache for 5 mins
  });
};

const useSyncProfileToAtom = () => {
  const { data: userTokenData, isSuccess: isSuccessToken } =
    useTokenDetailsQuery();
  const { data: userProfileData, isSuccess: isSuccessProfile } =
    useTokenDetailsQuery();

  //Get profile data also
  const [userData, setuserData] = useAtom(userAtom);

  useEffect(() => {
    console.log("SYNC HOOK - userTokenData", userTokenData);
    console.log("SYNC HOOK - userProfileData", userProfileData);

    if (
      isSuccessToken &&
      userTokenData &&
      isSuccessProfile &&
      userProfileData
    ) {
      const combinedData = {
        token: userTokenData,
        profile: userProfileData,
      };
      console.log("SETTING USER DATA", combinedData);
      setuserData(combinedData);
    } else {
      console.log("NOT SETTING USER DATA - reason:", {
        isSuccessToken,
        userTokenData,
        isSuccessProfile,
        userProfileData,
      });
    }
  }, [isSuccessToken, isSuccessProfile, userTokenData, userProfileData]);
};

export {
  useGenerateOtpMutation,
  useValidateOtpMutation,
  useCreateAccountMutation,
  useTokenDetailsQuery,
  useLogoutMutation,
  getTokenDetails,
  useSyncProfileToAtom,
};
