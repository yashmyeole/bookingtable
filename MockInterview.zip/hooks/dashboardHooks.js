"use client";
import axiosInstance from "@/api/axiosInstance";
// src/api/dashboard/getDashboardDetails.js

import { useQuery } from "@tanstack/react-query";
import { toast } from "react-toastify";
const getDashboardDetails = async () => {
  const response = await axiosInstance.get(
    "/mockInterview/api/getDashboardDetails"
  );
  return response.data;
};

const useDashboardDetailsQuery = () => {
  return useQuery({
    queryKey: ["dashboardDetails"],
    queryFn: getDashboardDetails,
    onError: (error) => {
      toast.error(
        error?.response?.data?.statusMsg || "Failed to fetch dashboard data"
      );
    },
    staleTime: 1000 * 60 * 2,
    // directly return 'data' field
  });
};
// ✅ API function to submit form data
// const submitCampaign = async (data) => {
//   const response = await axiosInstance.post(
//     baseUrl + "/centralized-mod/moderation/createCampaign",
//     data
//   );
//   return response.data; // Returns the API response
// };

// ✅ Custom Hook to use mutation
// const useSubmitCampaign = ({ refetch }) => {
//   return useMutation({
//     mutationFn: submitCampaign,
//     onSuccess: (data) => {
//       if (data?.statusCode == 200) {
//         toast.success("Campaign submitted successfully! 🎉");
//         // console.log("API Response:", data);
//         refetch();
//       } else {
//         toast.error(data?.statusMsg);
//       }
//     },
//     onError: (error) => {
//       toast.error(
//         `Failed to submit campaign ❌: ${
//           error.response?.data?.message || error.message
//         }`
//       );
//       console.error("Error:", error);
//     },
//   });
// };

// const useGetCampaignUsers = ({ campaignId }) => {
//   const query = useQuery({
//     queryKey: ["getUsers", campaignId],
//     queryFn: () =>
//       axiosInstance.post(`${baseUrl}/centralized-mod/moderation/getUsers`, {
//         campaignId: campaignId,
//       }),
//     staleTime: 1000 * 60 * 5,
//     refetchOnWindowFocus: false,
//     gcTime: 1000 * 60,
//   });

//   return query;
// };

export { useDashboardDetailsQuery };
