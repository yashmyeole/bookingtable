import { useMutation, useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { toast } from "react-toastify";

const { default: axiosInstance } = require("@/api/axiosInstance");

const createInterviewScheduleAvailability = async (payload) => {
  const response = await axiosInstance.post(
    "/mockInterview/api/createInterviewScheduleAvailability",
    payload
  );
  return response.data;
};
const getInterviewScheduleByInterviewer = async ({ startDate, offset }) => {
  const response = await axiosInstance({
    method: "post",
    url: "/mockInterview/api/getAvailableInterviewScheduleByInterviewer",
    data: {
      startDate,
      offset,
    },
    suppressToast: true, // ✅ this flag will now be picked up by the interceptor
  });
  return response.data;
};

export const deleteInterviewScheduledByInterviewer = async (payload) => {
  const response = await axiosInstance.post(
    "/mockInterview/api/deleteInterviewScheduledByInterviewer",
    payload
  );
  return response.data;
};
export const editSlot = async (payload) => {
  const response = await axiosInstance.post(
    "/mockInterview/api/editSlot",
    payload
  );
  return response.data;
};
const useCreateInterviewSchedule = () => {
  return useMutation({
    mutationFn: createInterviewScheduleAvailability,
    onSuccess: (data) => {
      if (data.status === "Success") {
        toast.success(data.statusMsg || "Availability saved successfully");
        // onSuccessCallback?.(data);
      }
    },
    onError: (error) => {
      // console.log("Errro hai", error);
      const errorArray = error.response?.data?.response || [];
      console.log("error arr", errorArray);
      if (errorArray.length > 0) {
        toast.error(errorArray[0]);
      }
    },
  });
};

// Hook that calls the query
const useInterviewSchedules = (currentPage) => {
  const offset = currentPage - 1; // Convert to 0-based index
  const startDate = format(new Date(), "yyyy-MM-dd"); // Always today's date

  return useQuery({
    queryKey: ["interviewSchedules", startDate, offset], // Unique cache key
    queryFn: () =>
      getInterviewScheduleByInterviewer({
        startDate,
        offset,
      }),
    keepPreviousData: true, // So old data shows while new one loads
    staleTime: 1000 * 60 * 5, // 5 min cache
  });
};
const useDeleteInterviewSchedule = () => {
  return useMutation({
    mutationFn: deleteInterviewScheduledByInterviewer,
    onSuccess: (data) => {
      if (data.status === "Success") {
        toast.success(data.statusMsg || "Interview deleted successfully");
      } else {
        toast.error(data.statusMsg || "Failed to delete interview");
      }
    },
    // onError: (error) => {
    //   toast.error(
    //     error?.response?.data?.statusMsg ||
    //       "Something went wrong while deleting interview"
    //   );
    // },
  });
};
const useEditSlot = () => {
  return useMutation({
    mutationFn: editSlot,
    onSuccess: (data) => {
      if (data.status === "Success") {
        toast.success(data.statusMsg || "Slot updated successfully");
      }
    },
    onError: (error) => {
      // console.log("Errro hai", error);
      const errorArray = error.response?.data?.response || [];
      console.log("error arr", errorArray);
      // if (errorArray.length > 0) {
      //   toast.error(errorArray[0]);
      // }
    },
  });
};
export {
  useCreateInterviewSchedule,
  useInterviewSchedules,
  useDeleteInterviewSchedule,
  useEditSlot,
};
