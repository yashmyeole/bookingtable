import axiosInstance from "@/api/axiosInstance";
import { useQuery } from "@tanstack/react-query";
import { parseISO } from "date-fns";
import { toast } from "react-toastify";

const getAvailableDays = async (params) => {
  const response = await axiosInstance.post(
    "/mockInterview/api/getAvailableDays",
    params
  );
  return response.data;
};

export const getInterviewScheduleByDate = async (payload) => {
  const response = await axiosInstance.post(
    "/mockInterview/api/getInterviewScheduleByDate",
    payload
  );
  return response.data;
};
const useAvailableDaysQuery = (
  { userId, startDate, endDate },
  enabled = true
) => {
  return useQuery({
    queryKey: ["availableDays", userId, startDate, endDate],
    queryFn: () => getAvailableDays({ userId, startDate, endDate }),
    enabled: enabled && !!userId && !!startDate && !!endDate,
    select: (data) =>
      (data?.availableDates || []).map((dateStr) => parseISO(dateStr)),
    onError: (error) => {
      toast.error(
        error?.response?.data?.statusMsg || "Failed to fetch available days"
      );
    },
    staleTime: 1000 * 60 * 3,
  });
};

const useInterviewScheduleByDateQuery = (
  { userId, startDate, endDate },
  enabled = true
) => {
  return useQuery({
    queryKey: ["interviewSchedules", userId, startDate, endDate],
    queryFn: () => getInterviewScheduleByDate({ userId, startDate, endDate }),
    enabled: enabled && !!userId && !!startDate && !!endDate,
    select: (data) => {
      // Filter out 'scheduled' status entries
      return data?.data?.filter((entry) => entry.status !== "scheduled") || [];
    },
    onError: (error) => {
      toast.error(
        error?.response?.data?.statusMsg ||
          "Failed to fetch interview schedules"
      );
    },
  });
};
export { useAvailableDaysQuery, useInterviewScheduleByDateQuery };
