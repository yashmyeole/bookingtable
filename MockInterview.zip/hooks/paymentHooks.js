import axiosInstance from "@/api/axiosInstance";
import { useMutation, useQuery } from "@tanstack/react-query";
import axios from "axios";
// import { signOut } from "next-auth/react";
import { toast } from "react-toastify";
// import { getSession } from "next-auth/react";

// const useGetUserProfile = () => {
//   const query = useQuery({
//     queryKey: ["getProfile"],
//     queryFn: () => axiosInstance.get(`${baseUrl}/getProfile`),
//     staleTime: 1000 * 60 * 5,
//     refetchOnWindowFocus: false,
//     gcTime: 1000 * 60,
//   });

//   return query;
// };

// const useCreateUserProfile = () => {
//   const mutation = useMutation({
//     mutationFn: (userData) =>
//       axiosInstance.post(`${baseUrl}/createProfile`, userData ),
//   });
 
//   return mutation;
// };

const useAddBankAccount = () => {
  const mutation = useMutation({
    mutationFn: (bankData) =>
      axiosInstance.post(`/mockInterview/api/addBankAccount`, bankData),
      onSuccess: () => {
      localStorage.removeItem('payout'); 
    }
  });

  return mutation;
};

const useDeleteBankAcount = () => {
  const mutation = useMutation({
    mutationFn: (userId) =>
      axiosInstance.post(`/mockInterview/api/deleteBankAcount`, userId),
  });

  return mutation;
};

const useFetchBankAccount= (body) => {
  const query = useQuery({
    queryKey: ["fetchBankAccount", body],
    queryFn: () => axiosInstance.post(`/mockInterview/api/addBankAccount`, body),
    // staleTime: 1000 * 60 * 5,
    // refetchOnWindowFocus: false,
    // gcTime: 1000 * 60,
  });

  return query;
};

const useGetWalletBalance= () => {
  const query = useQuery({
    queryKey: ["getWalletBalance"],
    queryFn: () => axiosInstance.get(`/mockInterview/api/getWalletBalance`),
    // staleTime: 1000 * 60 * 5,
    // refetchOnWindowFocus: false,
    // gcTime: 1000 * 60,
  });

  return query;
};

const useGetTransactions= () => {
  const query = useQuery({
    queryKey: ["getTransactions"],
    queryFn: () => axiosInstance.post(`/mockInterview/api/getTransactions`),
    // staleTime: 1000 * 60 * 5,
    // refetchOnWindowFocus: false,
    // gcTime: 1000 * 60,
  });

  return query;
};

export {
  useAddBankAccount,
  useGetWalletBalance,
  useGetTransactions,
  useDeleteBankAcount,
  useFetchBankAccount,
};