"use client"
import Image from 'next/image'
import React from 'react'
import profile from "@/assets/kartik.png";
import star from "@/assets/star_icon.png";
import ExploreProfile from '@/components/main/ExploreProfile';
import { useParams } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { useGetMentor } from '@/hooks/userHooks';

const page = () => {
  const { slug } = useParams();
  const { data: profileData, isFetched, isSuccess } = useGetMentor({});
  // const mentor = main?.find((m) => m.id === id);
   console.log("id", slug)
  return (
    <div className=''>
      <div className='bg-gradient-to-b from-cyan-700 to-[#CCE5EF] w-full py-15'>
      </div>
      <div className='px-[14vw] flex w-full py-12 mb-40'>
          <ExploreProfile
            mentorId={slug}
            mentor={profileData?.data?.mentors}
          />
      </div>
    </div>
  )
}

export default page
