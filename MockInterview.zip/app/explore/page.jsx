import { DropDownComponent } from '@/components/main/DropdownComponent'
import Filters from '@/components/main/Filters'
import InterviewerInfo from '@/components/main/InterviewerInfo'
import React from 'react'
import {sortByOptions} from '@/utils/Utility'
import Explore from '@/components/main/Explore'

const page = () => {
  
  return (
    <div className='px-[8vw] flex w-full py-12'>
       <Explore/>
    </div>
  )
}

export default page
