import Profile from "@/components/Interviewer/Profile";
import React from "react";

const page = () => {
  return (
    <div className="flex flex-col p-12">
      <div className="">
        <h2 className="text-xl font-semibold">Profile</h2>
      </div>
      
        <Profile/>
    </div>
  )
};

export default page;
