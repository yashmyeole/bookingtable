"use client"
import BankInput from "@/components/interviewer/ProfileSteps/BankInput";
import NoData from "@/components/main/NoData";
import React, { useState } from "react";
import bank from "@/assets/bank_icon.png";

const page = () => {
  const showDetails = false;
  const [bankStatus, setBankStatus] = useState(true)
  return (
    <div className="">
      <div className="">
        <BankInput 
          setBankStatus={setBankStatus}
        />
      </div>

      {bankStatus && <NoData
        // mainCss='border border-[#E0E0E0] rounded-xl shadow '
        icon={bank}
        iconWidth={60}
        altTtitle='No bank account details added'
        altPara1='Add your bank details to receive payments'
      />}
    </div>
  )
};

export default page;
