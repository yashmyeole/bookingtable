import ScheduleTimingsMain from "@/components/interviewer/scheduleTimings/ScheduleTimingsMain";
import React from "react";

const page = () => {
  return <ScheduleTimingsMain />;
};

export default page;
