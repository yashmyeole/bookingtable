import InterviewerScheduleContainer from "@/components/interviewer/schedule/InterviewerScheduleContainer";
import React from "react";

const page = () => {
  return <InterviewerScheduleContainer />;
};

export default page;
