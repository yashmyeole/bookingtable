import FeedbackDetails from "@/components/interviewer/FeedbackDetails";
import React from "react";

const page = () => {
  return (
    <div className="flex w-full h-full px-4">
      <FeedbackDetails />
    </div>
  );
};

export default page;
