import Feedback from "@/components/interviewer/Feedback";
import React from "react";

const page = () => {
  return <Feedback />;
};

export default page;
