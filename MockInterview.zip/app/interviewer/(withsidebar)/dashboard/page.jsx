import Dashboard from "@/components/interviewer/Dashboard";
import React from "react";

const page = () => {
  return (
    <div>
      <Dashboard />
    </div>
  );
};

export default page;
