import InterviewerSidebar from "@/components/main/Sidebar/InterviewerSidebar";
import React from "react";

const layout = ({ children }) => {
  return (
    <div className="flex w-screen max-w-screen h-[calc(100vh-120px)] max-h-screen overflow-x-hidden">
      <InterviewerSidebar />
      <div className="flex flex-1 p-8 bg-[#F9FAFB] overflow-y-auto ">
        {children}
      </div>
    </div>
  );
};

export default layout;
