import Feedback from "@/components/candidate/Feedback";
import React from "react";

const page = () => {
  return (
    <div className="w-full">
      <Feedback />
    </div>
  );
};

export default page;
