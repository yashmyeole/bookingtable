import CandidateSidebar from "@/components/main/Sidebar/CandidateSidebar";
import React from "react";

const layout = ({ children }) => {
  return (
    <div className="flex w-screen max-w-screen h-[calc(100vh-120px)] max-h-screen overflow-x-hidden">
      <CandidateSidebar />
      <div className="flex flex-1 p-8 bg-greyBgColor overflow-y-auto">
        {children}
      </div>
    </div>
  );
};

export default layout;
