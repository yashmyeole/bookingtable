import React from "react";

const layout = ({ children }) => {
  return (
    <div className="bg-white w-full h-fit rounded-[12px] p-8 border-[1px] border-gray-200">
      {children}
    </div>
  );
};

export default layout;
