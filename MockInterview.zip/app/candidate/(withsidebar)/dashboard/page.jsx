import Dashboard from "@/components/candidate/Dashboard";
import React from "react";

const page = () => {
  return (
    <div>
      <Dashboard />
    </div>
  );
};

export default page;
