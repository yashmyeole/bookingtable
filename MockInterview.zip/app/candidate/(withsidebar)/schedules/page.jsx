import ScheduleMainContainer from "@/components/candidate/schedule/ScheduleMainContainer";
import React from "react";

const page = () => {
  return <ScheduleMainContainer />;
};

export default page;
