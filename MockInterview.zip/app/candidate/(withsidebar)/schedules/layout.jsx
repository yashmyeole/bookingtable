import React from "react";

const layout = ({ children }) => {
  return (
    <div className="flex flex-col pb-3 w-full ">
      <p className="text-[28px] font-semibold">Schedule summary</p>
      <div className="flex bg-white w-full rounded-[12px] p-8 border-[1px] border-gray-200 mt-3">
        {children}
      </div>
    </div>
  );
};

export default layout;
