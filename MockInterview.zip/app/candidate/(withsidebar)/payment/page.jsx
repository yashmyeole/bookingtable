import Payment from "@/components/Candidate/Payment";
import React from "react";

const page = () => {
  return (
    <div className="w-full">
      <Payment />
    </div>
  );
};

export default page;
