import React from "react";
import overlay from "../../../assets/Background-overlay.png";
import Image from "next/image";
import PaymentFailure from "@/components/main/PaymentFailure";
const page = () => {
  return (
    <div className="relative w-full h-[calc(100vh-120px)]">
      <div className="absolute inset-0 z-10 pointer-events-none">
        <Image
          src={overlay}
          alt="overlay"
          fill
          className="object-cover"
          priority
        />
      </div>

      {/* Foreground content */}
      <div className="relative  px-[8vw] flex items-center justify-center h-full w-full  py-12 gap-6">
        {/* Right block with shadow */}
        <div className="flex-1 z-20 max-w-3xl bg-white bg-opacity-90 py-8 px-12 rounded-xl shadow-[-1px_-1px_17px_rgba(0,0,0,0.16)]">
          <PaymentFailure />
        </div>
      </div>
    </div>
  );
};

export default page;
