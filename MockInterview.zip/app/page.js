import Image from "next/image";
import BgImage from "@/assets/Mask.png";
import { IoIosArrowForward } from "react-icons/io";
import { TbStarFilled } from "react-icons/tb";

import JioLogo from "@/assets/jio_logo.png";

export default function Home() {
  const companies = [
    "Google",
    "Apple",
    "Amazon",
    "Microsoft",
    "Netflix",
    "Tesla",
    "Meta",
  ];
  const domains = [
    "AI",
    "Cloud",
    "Finance",
    "Healthcare",
    "Gaming",
    "Education",
    "E-commerce",
  ];
  const skills = [
    "React",
    "Node.js",
    "Python",
    "Java",
    "Docker",
    "Kubernetes",
    "SQL",
  ];

  const renderItems = (items) =>
    items.map((item, index) => (
      <div
        className="flex grid-item w-full justify-between items-center"
        key={index}
      >
        <span className="text-[18px] text-[#007FAD] cursor-pointer">
          {item}
        </span>
        <IoIosArrowForward color="#007FAD" className="cursor-pointer" />
      </div>
    ));

  const CardLayoutPersonInfo = () => {
    return (
      <div className="flex flex-col w-[270px] h-[350px] rounded-lg bg-[#F5F5F5] px-4">
        <div className="flex gap-x-2 font-semibold items-center justify-end text-end mt-4">
          <TbStarFilled color="#F4CD49" />
          <span>4.0</span>
        </div>
        <div className="flex  w-full justify-center py-4">
          <Image
            alt="Logo"
            src={JioLogo}
            width={100}
            height={100}
            className="w-[100px] h-[100px]"
          />
        </div>
        <p className="font-bold ">Anurag Tyagi</p>
        <p className="text-sm text-gray-600 mt-2">
          Technical Lead , Walmart Global Tech India 10 years of Experience
        </p>
        <div className="flex justify-center">
          <button className="cursor-pointer bg-[#007FAD] px-[12px] py-[8px] rounded-[6px] font-bold mt-[5vh] w-[200px] text-gray-100 text-[14px]">
            Book appointment
          </button>
        </div>
      </div>
    );
  };
  return (
    <div className="flex flex-col pb-[60px] h-[calc(100vh-120px)] overflow-y-auto items-center">
      <div className="flex relative">
        <Image
          alt="banner"
          src={BgImage}
          width={3000}
          height={3000}
          className="w-screen min-h-[calc(100vh-60px)]"
        />
        <div className="flex flex-col justify-center absolute px-[8vw] left-0 top-0 h-full ">
          <p className="text-[52px] leading-[76px] font-bold w-[40%]">
            Crack your next Interview with real-world practice
          </p>
          <button className="cursor-pointer bg-[#007FAD] px-[28px] py-[16px] rounded-[6px] font-bold mt-[5vh] w-[200px] text-gray-100">
            Get Started
          </button>
        </div>
      </div>
      <div className="flex flex-col py-12 px-[8vw] text-center">
        <p className="flex text-[42px] leading-[60px] font-semibold w-full justify-center">
          <span className="w-[70%]">
            Empower your journey with tailored mock interviews
          </span>
        </p>
        <div className="grid grid-cols-3 divide-x-1 divide-gray-200 gap-x-8 mt-8 border-[1px] border-gray-200 p-6">
          <div className="space-y-2 pr-6">
            <h3 className="text-start column-heading mb-4 text-[24px] font-semibold text-gray-700">
              Companies
            </h3>
            {renderItems(companies)}
          </div>
          {/* <div className="w-[1px] h-full bg-gray-200" /> */}
          <div className="space-y-2 pr-6">
            <h3 className="text-start  column-heading mb-4 text-[24px] font-semibold text-gray-700">
              Domains
            </h3>
            {renderItems(domains)}
          </div>
          <div className="space-y-2">
            <h3 className="text-start column-heading mb-4 text-[24px] font-semibold text-gray-700">
              Skills
            </h3>
            {renderItems(skills)}
          </div>
        </div>
        <div className="mt-3">
          <button className="cursor-pointer bg-[#007FAD] px-[28px] py-[12px] rounded-[6px] font-bold mt-[5vh] w-[200px] text-gray-100">
            Explore all
          </button>
        </div>
      </div>
      <div className="flex flex-col py-12 px-[8vw] text-center">
        <p className="text-[42px] font-semibold">Get started in 3 easy steps</p>
        <p className="text-[22px] mt-2">
          Follow these three simple steps to get started with Mentorship
        </p>
      </div>
      <div className="flex flex-col py-12  px-[8vw] text-center items-center">
        <p className="text-[42px] font-semibold">
          Get your mock interview with 500+ expert interviewers
        </p>
        <div className="grid grid-cols-4 mt-8 gap-4">
          <CardLayoutPersonInfo />
          <CardLayoutPersonInfo />
          <CardLayoutPersonInfo />
          <CardLayoutPersonInfo />
          <CardLayoutPersonInfo />
          <CardLayoutPersonInfo />
        </div>
        <button className="cursor-pointer border-[1px] text-[#007FAD] border-[#007FAD] px-[12px] py-[8px] rounded-[6px] font-bold mt-6 w-[200px] text-[14px]">
          Explore All Mentors
        </button>
      </div>
    </div>
  );
}
