import Profile from "@/components/interviewer/InterviewerProfile";
import React from "react";

const page = () => {
  return (
    <div className="px-[8vw] flex overflow-y-auto w-full py-12 mb-30">
      <div className="flex flex-col w-full items-center justify-center">
        <div className="text-center text-sm/7">
        <h2 className="text-xl font-bold tracking-wider">Your profile</h2>
        <span className="text-sm">Fill out the form in minutes! Share your professional details and experience.</span>
        
      </div>
      <Profile/>
      </div>
      
        
    </div>
  )
};

export default page;
