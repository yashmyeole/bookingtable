import { Label } from "./label";

const CustomTextarea = ({
  label,
  width = "w-full",
  name,
  placeholder,
  span,
  value = "",
  onChange = () => {},
  onBlur = () => {},
  inputRef = null,
  error = "", // <-- error prop
}) => {
  return (
    <div className={`flex flex-col ${width}`}>
      <Label className="text-md pb-2">{label}</Label>
      <div className={`border-[1.2px] px-3 rounded-lg ${error ? 'border-red-500' : 'border-[#E0E0E0]'}`}>
        <textarea
          name={name}
          value={value}
          onChange={onChange}
          onBlur={onBlur}
          ref={inputRef}
          placeholder={placeholder}
          className="w-full border-none outline-none resize-none text-[#666666] text-sm px-2 py-2 placeholder:text-[#979797] placeholder:text-sm"
          aria-invalid={!!error}
        />
      </div>

      {/* Optional helper text */}
      {span && <span className="text-xs mt-2 text-gray-500">{span}</span>}

      {/* Show error if exists */}
      {error && <span className="text-xs text-red-500 mt-1">{error}</span>}
    </div>
  );
};

export default CustomTextarea;
