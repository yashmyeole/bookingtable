import { Controller } from "react-hook-form";
import Image from "next/image";
import { useRef } from "react";
import useravatar from '/public/icons/profile_avatar.png'


const FileUpload = ({ control, name, previewUrl, setPreviewUrl }) => {
  const fileInputRef = useRef(null);

  return (
    <Controller
      name={name}
      control={control}
      rules={{ required: "Profile picture is required" }}
      render={({ field: { onChange } }) => (
        <div className="flex justify-center">
          <div
            onClick={() => fileInputRef.current?.click()}
            className="pb-6 cursor-pointer w-fit"
          >
            {/* Preview image */}
            <Image
              alt="ProfilePic"
              src={previewUrl || useravatar} // fallback image
              width={100}
              height={100}
              className="hover:opacity-80 transition"
            />

            {/* Hidden file input */}
            <input
              type="file"
              accept="image/*"
              ref={fileInputRef}
              onChange={(e) => {
                const file = e.target.files[0];
                if (file) {
                  onChange(file); // 👈 Send to react-hook-form
                  setPreviewUrl(URL.createObjectURL(file)); // 👈 Show preview
                }
              }}
              className="hidden"
            />
          </div>
        </div>
      )}
    />
  );
};
 export default FileUpload;