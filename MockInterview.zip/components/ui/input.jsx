import * as React from "react";

import { cn } from "@/lib/utils";
import { Label } from "./label";

function Input({ className, type, label, ...props }) {
  return (
    <div>
      {label && (
        <Label className="text-base text-textgrey font-normal">{label}</Label>
      )}
      <input
        type={type}
        data-slot="input"
        className={cn(
          "placeholder:text-placeholdertext selection:bg-primary selection:text-primary-foreground border-input flex h-[50px] w-full min-w-0 rounded-lg border bg-transparent p-4 text-base   outline-none disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
          className
        )}
        {...props}
      />
    </div>
  );
}

export { Input };
