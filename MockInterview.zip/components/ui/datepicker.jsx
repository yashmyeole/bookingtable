import { useState, useEffect } from "react";
import { format } from "date-fns"; // use `format`, not `formatDate`
import { Popover, PopoverContent, PopoverTrigger } from "./popover";
import { Calendar } from "./calendar";
import { Button } from "./button";
import { BiSolidCalendarHeart } from "react-icons/bi";

function isValidDate(d) {
  return d instanceof Date && !isNaN(d);
}

export function Calendar28({ value, onChange }) {
  const [open, setOpen] = useState(false);
  const [month, setMonth] = useState();
  const [inputValue, setInputValue] = useState(() =>
    isValidDate(value) ? format(value, "yyyy-MM-dd") : ""
  );

  useEffect(() => {
    setInputValue(isValidDate(value) ? format(value, "yyyy-MM-dd") : "");
  }, [value]);

  const handleDateChange = (date) => {
    if (isValidDate(date)) {
      onChange(date);
      setOpen(false);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="relative flex gap-2 border-[1px] border-gray-200 px-2 py-1 rounded-lg">
        <input
          id="date"
          value={inputValue}
          placeholder="Select Date"
          className="bg-background pr-10 h-[28px]"
          onChange={(e) => {
            const newValue = e.target.value;
            const date = new Date(newValue);
            setInputValue(newValue);
            if (isValidDate(date)) {
              onChange(date);
              setMonth(date);
            }
          }}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setOpen(true);
            }
          }}
        />
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button
              id="date-picker"
              variant="ghost"
              className="absolute top-1/2 right-2 size-6 -translate-y-1/2"
            >
              <BiSolidCalendarHeart className="size-3.5" />
              <span className="sr-only">Select date</span>
            </Button>
          </PopoverTrigger>
          <PopoverContent
            className="w-auto overflow-hidden p-0"
            align="end"
            alignOffset={-8}
            sideOffset={10}
          >
            <Calendar
              mode="single"
              selected={value}
              captionLayout="dropdown"
              month={month}
              onMonthChange={setMonth}
              onSelect={handleDateChange}
            />
          </PopoverContent>
        </Popover>
      </div>
    </div>
  );
}
