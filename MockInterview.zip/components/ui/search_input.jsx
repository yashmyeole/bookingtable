"use client";
import Image from "next/image";
import SearchIcon from "@/assets/search_icon.png";

export function SearchInput({
  label,
  name,
  width,
  register,
  rules = {},
  errors,
  placeholder,
  verifiable = false,
  isVerified = false,
  onVerify,
  type = "text",
  ...rest
}) {
  const hasError = !!errors?.[name];

  return (
    <div className={`flex flex-col ${width} relative`}>
      {label && (
        <label className='text-md pb-2'>{label}</label>
      )}
      
      <input
            name={name}
            type={type}
            placeholder={placeholder}
            className='text-base text-[#666666] bg-[#f5f5f5] rounded-md px-10 py-2 placeholder:text-[#979797] placeholder:text-base w-full'
            aria-invalid={hasError}
            {...(register && typeof register === 'function' ? register(name, rules) : {})}
            {...rest}
            // value={userData.firstname}
            //onChange={handleChange}
        />
        <Image src={SearchIcon} alt="Search" width={25} className="absolute left-2 top-2"/>
      {/* <Input
        id={name}
        type={type}
        className='border border-1 border-[#E0E0E0] rounded-sm px-2 py-1 max-w-[320px]'
        aria-invalid={hasError}
        placeholder={placeholder}
        // {...register(name, rules)}
        {...rest}
      /> */}

      {/* Verification Section Below Input */}
      {/* {verifiable && (
        <div className="flex items-center justify-between mt-1">
          {isVerified ? (
            <>
              <div className="flex items-center gap-1 text-green-600 text-sm font-medium">
                <Image src={Greentick} alt="Verified" width={14} height={14} />
                <span>Verified</span>
              </div>
              <span
                onClick={onVerify}
                className="text-sm font-medium text-customblue cursor-pointer hover:underline"
              >
                Verify {label?.toLowerCase()}
              </span>
            </>
          ) : (
            <span
              onClick={onVerify}
              className="text-sm font-medium text-customblue cursor-pointer hover:underline ml-auto"
            >
              Verify {label?.toLowerCase()}
            </span>
          )}
        </div>
      )}

      {hasError && (
        <div className="flex items-center gap-2 mt-1">
          <Image src={RedCrossIcon} alt="error" width={16} height={16} />
          <span className="text-sm text-red-500">{errors[name]?.message}</span>
        </div>
      )} */}
    </div>
  );
}
