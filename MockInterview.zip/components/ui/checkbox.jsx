"use client"
import { useState } from 'react';
import { Check } from 'lucide-react'; // Optional icon library

const Checkbox = ({title, label, options=['Option 1', 'Option 2', 'Option 3']}, onChange) => {
  //const options = ['Option 1', 'Option 2', 'Option 3'];
  const [selectedOptions, setSelectedOptions] = useState([]);
 
  const handleChange = (option) => {
    setSelectedOptions((prev) =>
      prev.includes(option)
        ? prev.filter((item) => item !== option)
        : [...prev, option]
    );
  };

  return (
    <div className="space-y-3 text-[#979797]">
      {title && <span className='font-medium text-base leading-5 tracking-[-0.005em] align-middle mt-2'>{title}</span>}
      {options.map((option) => (
        <label
          key={option}
          className="flex items-center space-x-2 cursor-pointer"
        >
          <input
            type="checkbox"
            value={option}
            checked={selectedOptions.includes(option)}
            onChange={() => handleChange(option)}
            className="h-4 w-4 text-blue-600 rounded border-[#979797] focus:ring-2 focus:ring-blue-500"
          />
          <span className="text-[#979797]">{option}</span>
        </label>
      ))}
    </div>
  );
};

export default Checkbox;
