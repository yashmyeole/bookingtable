"use client";

import { useState } from "react";
import { Label } from "./label";

export default function PillInput({ defaultSkills, setSkills }) {
  const [input, setInput] = useState("");

  const addSkill = (e) => {
    if (e.key === "Enter" && input.trim() !== "") {
      e.preventDefault();
      if (!defaultSkills.includes(input.trim())) {
        setSkills([...defaultSkills, input.trim()]);
      }
      setInput("");
    }
  };

  const removeSkill = (skillToRemove) => {
    setSkills(defaultSkills.filter((skill) => skill !== skillToRemove));
  };

  // function getSkills() {
  //   return defaultSkills.join("||");
  // }

  return (
    <div className="w-full max-w-xl">
      <Label className="text-base text-textgrey font-normal">
        Skills <span className="text-xs">(Type the skill and press enter)</span>
      </Label>
      <div className="flex flex-wrap items-center gap-2 border-[1.2px] p-2 rounded-lg mt-3">
        {defaultSkills.map((skill) => (
          <span
            key={skill}
            className="flex items-center bg-blue-100 text-black px-3 py-1 rounded-full text-sm"
          >
            {skill}
            <button
              onClick={() => {
                removeSkill(skill);
              }}
              className="ml-2 text-black hover:text-red-500 cursor-pointer"
            >
              &times;
            </button>
          </span>
        ))}
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={addSkill}
          placeholder="Add a new skill"
          className="flex-grow  outline-none text-sm p-2 min-w-[120px] placeholder:text-gray-400"
        />
      </div>
    </div>
  );
}
