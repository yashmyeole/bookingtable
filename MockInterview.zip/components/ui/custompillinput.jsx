"use client";

import { useState } from "react";
import { Label } from "./label";

export default function CustomPillInput({
  label,
  width,
  name,
  placeholder,
  span,
  value = [],
  onChange = () => {},
  onBlur = () => {},
  inputRef,
  error, // 🔴 new error prop from react-hook-form
}) {
  const [input, setInput] = useState("");

  const addSkill = (e) => {
    if (e.key === "Enter" && input.trim() !== "") {
      e.preventDefault();
      if (!value.includes(input.trim())) {
        onChange([...value, input.trim()]);
      }
      setInput("");
    }
  };

  const removeSkill = (skillToRemove) => {
    onChange(value.filter((skill) => skill !== skillToRemove));
  };

  return (
    <div className={`flex flex-col ${width}`}>
      <Label className="text-md pb-2">{label}</Label>

      <div
        className={`flex flex-wrap items-center gap-1 border-[1.2px] px-3 rounded-lg ${
          error ? "border-red-500" : "border-[#E0E0E0]"
        }`}
      >
        {value.map((skill) => (
          <span
            key={skill}
            className="flex items-center bg-blue-100 text-black px-3 py-1 rounded-full text-sm"
          >
            {skill}
            <button
              onClick={() => removeSkill(skill)}
              className="ml-2 text-black hover:text-red-500 cursor-pointer"
            >
              &times;
            </button>
          </span>
        ))}
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={addSkill}
          onBlur={onBlur}
          placeholder={placeholder}
          ref={inputRef}
          className="flex-grow text-[#666666] outline-none text-sm px-2 py-4 placeholder:text-[#979797] placeholder:text-sm"
        />
      </div>

      {error && (
        <div className="flex items-center gap-2 mt-1">

          <span className="text-sm text-red-500 mt-1">{error.message}</span>
          </div>
        
      )}
      {span && <span className="text-xs mt-2">{span}</span>}
    </div>
  );
}
