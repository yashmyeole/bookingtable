import React from "react";
import { capitalizeFirstLetter, cn } from "@/lib/utils"; // optional: for conditional classnames

const StatusChip = ({
  text,
  // color = "bg-gray-200",
  // textColor = "text-black",
}) => {
  let color, textColor;
  if (capitalizeFirstLetter(text) === "Cancelled") {
    color = "bg-lightRedBg";
    textColor = "text-redText";
  } else if (
    capitalizeFirstLetter(text) === "Completed" ||
    capitalizeFirstLetter(text) === "Submitted" ||
    capitalizeFirstLetter(text) === "Available"
  ) {
    color = "bg-lightGreenBg";
    textColor = "text-greenText";
  } else if (capitalizeFirstLetter(text) === "Reschedule Pending") {
    color = "bg-lightOrangeBg";
    textColor = "text-orangeText";
  } else if (capitalizeFirstLetter(text) === "Scheduled") {
    color = "bg-customblue-light";
    textColor = "text-[#007FAD]";
  } else if (capitalizeFirstLetter(text) === "Pending") {
    color = "bg-lightOrangeBg";
    textColor = "text-orangeText";
  } else if (capitalizeFirstLetter(text) === "Draft") {
    color = "bg-gray-400";
    textColor = "text-black";
  }
  return (
    <span
      className={cn(
        "flex   rounded-md w-[120px] h-[30px] px-3 py-1 text-sm font-medium justify-center items-center",
        color,
        textColor
      )}
    >
      {capitalizeFirstLetter(text)}
    </span>
  );
};

export default StatusChip;
