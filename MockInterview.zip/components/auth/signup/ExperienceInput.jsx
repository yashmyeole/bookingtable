"use client";

import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils"; // If you're using a utility like `cn`

export function ExperienceInput({
  control,
  errors,
  nameYear = "experienceYear",
  nameMonth = "experienceMonth",
  label = "Experience Years & Months *",
  placeholderYear = "Years",
  placeholderMonth = "Months",
  register,
  rulesYear = {},
  rulesMonth = {},
}) {
  const errorYear = errors?.[nameYear]?.message;
  const errorMonth = errors?.[nameMonth]?.message;

  return (
    <div className="flex flex-col gap-1 w-full">
      <Label className="text-base text-textgrey font-normal">{label}</Label>

      <div className="flex gap-4 w-full">
        <div className="flex flex-col w-full">
          <Input
            placeholder={placeholderYear}
            aria-invalid={!!errorYear}
            {...register(nameYear, rulesYear)}
          />
          {errorYear && (
            <span className="text-sm text-red-500 mt-1">{errorYear}</span>
          )}
        </div>

        <div className="flex flex-col w-full">
          <Input
            placeholder={placeholderMonth}
            aria-invalid={!!errorMonth}
            {...register(nameMonth, rulesMonth)}
          />
          {errorMonth && (
            <span className="text-sm text-red-500 mt-1">{errorMonth}</span>
          )}
        </div>
      </div>
    </div>
  );
}
