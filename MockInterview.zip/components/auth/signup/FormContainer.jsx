"use client";
import React, { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import SignUpFormCandidate from "./SignUpFormCandidate";
import SignUpFormInterviewer from "./SignUpFormInterviewer";
import { useAtom } from "jotai";
import { userTypeAtom } from "@/store/authAtoms";
import PopupWrapper from "@/components/Wrappers/PopupWrapper";
import SuccefullRegestrationModal from "./SuccefullRegestrationModal";
import { succefullRegestrationModalAtom } from "@/store/modalOpenAtoms";

const FormContainer = () => {
  const [userType, setUserType] = useAtom(userTypeAtom);

  const [openSuccefullRegestrationModal, setopenSuccefullRegestrationModal] =
    useAtom(succefullRegestrationModalAtom);
  return (
    <>
      {" "}
      <Tabs
        value={userType}
        onValueChange={(value) => {
          setUserType(value); // prevent switch in OTP mode
        }}
        className="flex flex-col justify-center w-full gap-6"
      >
        <TabsList className="w-full">
          <TabsTrigger value="candidate">Candidate</TabsTrigger>
          <TabsTrigger value="interviewer">Interviewer</TabsTrigger>
        </TabsList>
        <TabsContent value="candidate">
          <SignUpFormCandidate />
        </TabsContent>
        <TabsContent value="interviewer">
          <SignUpFormInterviewer />
        </TabsContent>
      </Tabs>
      <PopupWrapper
        isOpen={openSuccefullRegestrationModal}
        isClose={() =>
          setopenSuccefullRegestrationModal(!openSuccefullRegestrationModal)
        }
      >
        <SuccefullRegestrationModal type={userType} />
      </PopupWrapper>
    </>
  );
};

export default FormContainer;
