"use client";

import React from "react";
import {
  Dialog,
  DialogContent,
  DialogOverlay,
  DialogTitle,
} from "@/components/ui/dialog";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";
export default function TestPopupWrapper({ isOpen, isClose, children }) {
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && isClose()}>
      <DialogOverlay className="fixed inset-0 bg-black/50" />
      <DialogContent className="max-w-md w-full p-6 rounded-2xl bg-white shadow-xl">
        <VisuallyHidden>
          <DialogTitle>Popup</DialogTitle>
        </VisuallyHidden>
        {children}
      </DialogContent>
    </Dialog>
  );
}
