"use client";
import React, { useEffect, useState } from "react";
import { CustomInput } from "./CustomInput";
import { useForm } from "react-hook-form";
import { CustomDropDown } from "./CustomDropDown";
import { ExperienceInput } from "./ExperienceInput";
import { Button } from "@/components/ui/button";
import Otp from "@/components/main/Otp";
import PopupWrapper from "@/components/Wrappers/PopupWrapper";
import { useAtom } from "jotai";
import { registerFormDataAtom, userTypeAtom } from "@/store/authAtoms";
import {
  openOtpPopUpModalAtom,
  succefullRegestrationModalAtom,
} from "@/store/modalOpenAtoms";
import {
  useCreateAccountMutation,
  useGenerateOtpMutation,
} from "@/hooks/authHooks";

const SignUpForm = () => {
  const [formData, setFormData] = useAtom(registerFormDataAtom);
  const [userType, setUserType] = useAtom(userTypeAtom);
  const [openSuccefullRegestrationModal, setopenSuccefullRegestrationModal] =
    useAtom(succefullRegestrationModalAtom);
  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
    watch,
    trigger,
    setError,
    reset,
  } = useForm({
    defaultValues: formData[userType] || {},
  });
  useEffect(() => {
    const subscription = watch((value) => {
      setFormData((prev) => ({
        ...prev,
        [userType]: { ...prev[userType], ...value },
      }));
    });
    return () => subscription.unsubscribe();
  }, [watch, userType]);
  const dynamicText =
    userType === "candidate"
      ? "Ace your tech career with realistic mock interviews led by industry experts."
      : "Contribute to the tech community through mock interviews and feedback.";
  const [isOtpVerify, setIsOtpVerify] = useState(false);
  const [isEmailVerify, setIsEmailVerify] = useState(false);
  const [mobileNoOrEmail, setmobileNoOrEmail] = useState(null);
  // const [openOtpPopUp, setopenOtpPopUp] = useState(false);
  const [openOtpPopUp, setopenOtpPopUp] = useAtom(openOtpPopUpModalAtom);
  const [otpFor, setotpFor] = useState(""); //Email or Mobile
  const { mutate: generateOtp, isLoading } = useGenerateOtpMutation();
  const { mutate: createAccount, isLoading: createAccountLoading } =
    useCreateAccountMutation();
  const closePopUp = () => {
    setopenOtpPopUp(false);
  };
  const handleVerify = async (type, fieldName) => {
    //Check if user has filled the verifiable filed and is valid
    const isValid = await trigger(fieldName);
    if (!isValid) return; // Don't proceed if invalid

    if (type === "mobile") {
      setotpFor("mobile");
      setmobileNoOrEmail(formData[userType].mobile);
      // toast.success("test");
      generateOtp(
        {
          type: "Mobile",
          value: formData[userType].mobile,
          deviceId: 1215,
          resendFlag: "0",
          registration: 1,
        },
        {
          onSuccess: (data) => {
            // Only runs when OTP was successfully sent
            if (data?.status === "Success") {
              setopenOtpPopUp(true);
            }
          },
        }
      );

      //Call generate api here .
      // setopenOtpPopUp(true);
    } else {
      setotpFor("email");
      setmobileNoOrEmail(formData[userType].email);
      generateOtp(
        {
          type: "email",
          value: formData[userType].email,
          deviceId: 1215,
          resendFlag: "0",
          registration: 1,
        },
        {
          onSuccess: (data) => {
            // Only runs when OTP was successfully sent
            if (data?.status === "Success") {
              setopenOtpPopUp(true);
            }
          },
        }
      );
    }
  };
  const handleFormSubmit = (data) => {
    let hasError = false;

    //If mobile no is not verified
    if (!isOtpVerify) {
      setError("mobile", {
        type: "manual",
        message: "Please verify your mobile number first",
      });
      hasError = true;
    }

    //If email is not verified
    if (!isEmailVerify) {
      setError("email", {
        type: "manual",
        message: "Please verify your email address first",
      });
      hasError = true;
    }

    if (hasError) return; // Stop form submission

    const body = {
      firstName: formData[userType].firstName,
      lastName: formData[userType].lastName,
      email: formData[userType].email,
      mobileNumber: formData[userType].mobile,
      education: formData[userType].education,
      company: formData[userType].company,
      jobTitle: formData[userType].jobTitle,
      expInYear: formData[userType].experienceYear,
      expInMonth: formData[userType].experienceMonth,
      domain: "",
      goal: "",
      role: "Interviewer",
    };
    console.log("Data ready to submit:", body);
    createAccount(body, {
      onSuccess: (data) => {
        // Only runs when OTP was successfully sent
        if (data?.status === "Success") {
          setFormData((prev) => ({
            ...prev,
            [userType]: {},
          }));
          reset();
          document.cookie = `token=${data.token}; path=/; max-age=${
            60 * 60 * 24
          }; secure; samesite=lax`;
          // localStorage.setItem("token", data.token);
          setopenSuccefullRegestrationModal(true);
        }
      },
      onError: (data) => {
        // Only runs when OTP was successfully sent
        console.log("Onerro data", data.response.data.status);
        if (data?.response?.data?.status === "error") {
          console.log("inside if error");
          setFormData((prev) => ({
            ...prev,
            [userType]: {},
          }));
          reset();
          setIsEmailVerify(false);
          setIsOtpVerify(false);
        }
      },
    });
  };
  return (
    <>
      <form
        onSubmit={handleSubmit(handleFormSubmit)}
        className="flex flex-col gap-6"
      >
        {/* Heading */}
        <div className="flex flex-col gap-2">
          <h2 className="text-[32px] leading-[100%] font-semibold text-center">
            Create account get started.
          </h2>
          {dynamicContent(dynamicText)}
        </div>
        {/* Form */}
        <div className="grid grid-cols-2 gap-x-6 gap-y-5">
          <CustomInput
            label="First Name"
            name="firstName"
            placeholder="Enter your first name"
            register={register}
            errors={errors}
            rules={{ required: "First name is required" }}
          />
          <CustomInput
            label="Last Name"
            name="lastName"
            placeholder="Enter your last name"
            register={register}
            errors={errors}
            rules={{ required: "Last name is required" }}
          />
          <CustomInput
            label="Mobile Number"
            name="mobile"
            verifiable={true}
            isVerified={isOtpVerify}
            onVerify={() => handleVerify("mobile", "mobile")}
            placeholder="Enter your mobile number"
            register={register}
            errors={errors}
            onKeyDown={(e) => {
              const allowedKeys = [
                "Backspace",
                "Delete",
                "ArrowLeft",
                "ArrowRight",
                "Tab",
              ];
              if (!/[0-9]/.test(e.key) && !allowedKeys.includes(e.key)) {
                e.preventDefault();
              }
            }}
            rules={{
              required: "Mobile number is required",
              pattern: {
                value: /^[6-9]\d{9}$/, // Indian 10-digit number starting with 6-9
                message: "Please enter valid mobile number",
              },
            }}
          />
          <CustomInput
            label="Email"
            name="email"
            placeholder="Enter your email"
            verifiable={true}
            isVerified={isEmailVerify}
            onVerify={() => handleVerify("email", "email")}
            register={register}
            errors={errors}
            rules={{
              required: "Email is required",
              pattern: {
                value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                message: "Enter a valid email address",
              },
            }}
          />
          <CustomInput
            label="Education"
            name="education"
            placeholder="Enter your education"
            register={register}
            errors={errors}
            rules={{ required: "Education is required" }}
          />
          <CustomInput
            label="Company"
            name="company"
            placeholder="Enter your company"
            register={register}
            errors={errors}
            rules={{ required: "Company is required" }}
          />
          <CustomDropDown
            label="Job Title"
            name="jobTitle"
            placeholder="Select your Job title"
            register={register}
            control={control}
            errors={errors}
            options={jobTittleOptions}
            rules={{ required: "Job title is required" }}
          />

          <ExperienceInput
            register={register}
            errors={errors}
            nameYear="experienceYear"
            nameMonth="experienceMonth"
            rulesYear={{
              required: "Year is required",
              pattern: {
                value: /^\d+$/,
                message: "Only numbers allowed",
              },
            }}
            rulesMonth={{
              required: "Month is required",
              pattern: {
                value: /^([0-9]|1[0-1])$/,
                message: "Enter month between 0 and 11",
              },
            }}
          />
        </div>
        {/* Submit button */}
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-center h-[50px]">
            <Button type="submit" className="w-[240px]" size={"lg"}>
              Create Account
            </Button>
          </div>
          <label className="text-sm text-center font-normal  text-textgrey">
            Don’t you have an account ?
            <span className="text-customblue">Sign up</span>
          </label>
        </div>
      </form>
      <PopupWrapper isOpen={openOtpPopUp} isClose={closePopUp}>
        <Otp
          useCaseName={otpFor}
          mobileNoOrEmail={mobileNoOrEmail}
          setIsOtpVerify={setIsOtpVerify}
          setIsEmailVerify={setIsEmailVerify}
        />
      </PopupWrapper>
    </>
  );
};
const dynamicContent = (text) => {
  return (
    <p className="text-center text-base text-wrap text-textgrey">{text}</p>
  );
};
const goalOptions = [
  { label: "Placement", value: "placement" },
  { label: "Learning", value: "learning" },
  { label: "Networking", value: "networking" },
  { label: "Career Change", value: "career_change" },
];
const jobTittleOptions = [
  { label: "Team Lead", value: "team_lead" },
  { label: "Manager", value: "manager" },
];
export default SignUpForm;
