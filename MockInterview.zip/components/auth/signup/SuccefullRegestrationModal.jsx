"use client";
import React from "react";
import GreenTick from "../../../assets/greentick.png";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { succefullRegestrationModalAtom } from "@/store/modalOpenAtoms";
import { useAtom } from "jotai";

const SuccefullRegestrationModal = ({ type }) => {
  const [openSuccefullRegestrationModal, setopenSuccefullRegestrationModal] =
    useAtom(succefullRegestrationModalAtom);
  const router = useRouter();
  const handleRedirection = () => {
    setopenSuccefullRegestrationModal(false);
    if (type === "candidate") {
      router.push("/login");
    } else {
      window.location.href = "/register/interviewer/editprofile";
    }
  };
  return (
    <div className="flex flex-col justify-center min-w-xl space-y-3">
      <div className="flex justify-center">
        <Image src={GreenTick} alt="greentick" width={28} height={28} />
      </div>

      <h1 className="text-xl text-center font-medium">Congratulations</h1>

      <p className="text-base  text-wrap font-medium text-textgrey  text-center">
        {type === "candidate" ? (
          "Your account has been successfully created. You can login"
        ) : (
          <>
            Your account has been successfully created.
            <br />
            Please continue to create your profile.
          </>
        )}
      </p>
      <div className="flex justify-center">
        <Button onClick={handleRedirection} className="px-6 w-[100px]">
          {type === "candidate" ? "Login" : "Continue"}
        </Button>
      </div>
    </div>
  );
};

export default SuccefullRegestrationModal;
