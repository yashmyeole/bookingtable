"use client";

import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import Image from "next/image";
import RedCrossIcon from "@/assets/ic_error_colored.png"; // Adjust path as needed
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import Greentick from "../../../assets/greentick.png";

export function CustomInput({
  label,
  name,
  register,
  rules = {},
  errors,
  placeholder,
  verifiable = false,
  isVerified = false,
  onVerify,
  type = "text",
  ...rest
}) {
  const hasError = !!errors?.[name];

  return (
    <div className="flex flex-col gap-1 w-full">
      {label && (
        <Label htmlFor={name} className="text-base text-textgrey font-normal">
          {label}
        </Label>
      )}

      <Input
        id={name}
        type={type}
        aria-invalid={hasError}
        placeholder={placeholder}
        disabled={isVerified}
        {...register(name, rules)}
        {...rest}
      />

      {/* Verification Section Below Input */}
      {verifiable && (
        <div className="flex items-center justify-end mt-1">
          {verifiable && (
            <div className="flex items-center justify-between mt-1">
              {isVerified ? (
                <div className="flex items-center gap-1 text-green-600 text-sm font-medium">
                  <Image
                    src={Greentick}
                    alt="Verified"
                    width={14}
                    height={14}
                  />
                  <span>Verified</span>
                </div>
              ) : (
                <span
                  onClick={onVerify}
                  className="text-sm  font-medium text-customblue cursor-pointer hover:underline ml-auto"
                >
                  Verify {label?.toLowerCase()}
                </span>
              )}
            </div>
          )}
          {/* {isVerified ? (
            <>
              <div className="flex items-center gap-1 text-green-600 text-sm font-medium">
                <Image src={Greentick} alt="Verified" width={14} height={14} />
                <span>Verified</span>
              </div>
              <span
                onClick={onVerify}
                className="text-sm font-medium text-customblue cursor-pointer hover:underline"
              >
                Verify {label?.toLowerCase()}
              </span>
            </>
          ) : (
            <span
              onClick={onVerify}
              className="text-sm font-medium text-customblue cursor-pointer hover:underline ml-auto"
            >
              Verify {label?.toLowerCase()}
            </span>
          )} */}
        </div>
      )}

      {hasError && (
        <div className="flex items-center gap-2 mt-1">
          <Image
            src={RedCrossIcon}
            alt="error"
            width={16}
            style={{ height: "auto" }}
          />
          <span className="text-sm text-red-500">{errors[name]?.message}</span>
        </div>
      )}
    </div>
  );
}
