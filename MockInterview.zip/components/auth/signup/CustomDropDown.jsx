"use client";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import Image from "next/image";
import RedCrossIcon from "@/assets/ic_error_colored.png";
import { cn } from "@/lib/utils";
import { Controller } from "react-hook-form";

export function CustomDropDown({
  label,
  name,
  control,
  options = [],
  classNameTrigger,
  errors,
  placeholder = "Select an option",
  defaultValue,
  rules = {},
}) {
  const hasError = !!errors?.[name];

  return (
    <div className="flex flex-col gap-1">
      {label && (
        <Label htmlFor={name} className="text-base text-textgrey font-normal">
          {label}
        </Label>
      )}
      {console.log(defaultValue)}

      <Controller
        name={name}
        control={control}
        rules={rules}
        defaultValue={defaultValue} // prevent uncontrolled-to-controlled switch
        render={({ field }) => (
          <Select
            value={field.value}
            onValueChange={field.onChange}
            name={field.name}
          >
            <SelectTrigger
              id={name}
              size="custom"
              ref={field.ref} // Important for RHF validation and focus management
              className={cn(
                "selection:bg-primary selection:text-primary-foreground border-input flex h-[50px] w-full min-w-0 rounded-xl border bg-transparent p-4 text-base outline-none disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
                "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
                hasError && "border-red-500",
                classNameTrigger
              )}
              aria-invalid={hasError}
            >
              <SelectValue placeholder={placeholder} />
            </SelectTrigger>
            <SelectContent>
              {options.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      />

      {hasError && (
        <div className="flex items-center gap-2 mt-1">
          <Image src={RedCrossIcon} alt="error" width={16} height={16} />
          <span className="text-sm text-red-500">{errors[name]?.message}</span>
        </div>
      )}
    </div>
  );
}
