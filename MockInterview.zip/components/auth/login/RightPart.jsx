"use client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import LoginForm from "./LoginForm";
import { useState } from "react";
import AuthWrapper from "./AuthWrapper";
import { userTypeAtom } from "@/store/authAtoms";
import { useAtom } from "jotai";

export function RightPart() {
  const [userType, setUserType] = useAtom(userTypeAtom);
  const [otpMode, setOtpMode] = useState(false);
  return (
    <div className="flex justify-center  w-full  flex-col">
      <Tabs
        value={userType}
        onValueChange={(value) => {
          // console.log("otmode", otpMode);
          if (!otpMode) setUserType(value); // prevent switch in OTP mode
        }}
      >
        <TabsList className="w-full">
          <TabsTrigger disabled={otpMode} value="candidate">
            Candidate
          </TabsTrigger>
          <TabsTrigger disabled={otpMode} value="interviewer">
            Interviewer
          </TabsTrigger>
        </TabsList>
        <TabsContent value="candidate">
          <AuthWrapper
            userType={userType}
            otpMode={otpMode}
            setOtpMode={setOtpMode}
          />
        </TabsContent>
        <TabsContent value="interviewer">
          <AuthWrapper
            userType={userType}
            otpMode={otpMode}
            setOtpMode={setOtpMode}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
