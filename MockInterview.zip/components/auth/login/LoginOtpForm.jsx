import Image from "next/image";
import React from "react";
import Back from "../../../assets/Back.png";
import Otp from "@/components/main/Otp";
import { useAtom } from "jotai";
import { mobileNoAtom } from "@/store/authAtoms";
const LoginOtpForm = ({ userType, onBack }) => {
  const [mobileNoState, setMobileNoState] = useAtom(mobileNoAtom);
  return (
    <div className="flex flex-col gap-4 ">
      {/* back button */}
      <div className="flex  items-center">
        <div
          onClick={onBack}
          className="flex items-center cursor-pointer justify-center h-4 w-4"
        >
          <Image src={Back} alt="back" height={13} width={6.5} />
        </div>
        <span onClick={onBack} className="text-base font-medium cursor-pointer">
          Back
        </span>
      </div>
      {/* Otp component */}
      <Otp
        useCaseName="mobile"
        mobileNoOrEmail={mobileNoState}
        useFor="login"
      />
    </div>
  );
};

export default LoginOtpForm;
