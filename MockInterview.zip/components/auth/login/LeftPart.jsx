"use client";
import React from "react";
import greentick from "../../../assets/greentick.png";
import Image from "next/image";
import { userTypeAtom } from "@/store/authAtoms";
import { useAtom } from "jotai";
const LeftPart = () => {
  const [userType, setUserType] = useAtom(userTypeAtom);
  const candidateDisplayText = [
    "Build confidence and excel in your interviews.",
    "Build confidence and excel in your interviews.",
    "Build confidence and excel in your interviews.",
  ];
  const interviewerDisplayText = [
    "Share expertise through realistic mock interviews.",
    "Help candidates refine interview skills with feedback",
    "Enjoy flexible scheduling around commitments.",
  ];

  let displayText =
    userType === "candidate" ? candidateDisplayText : interviewerDisplayText;

  return (
    <div className="flex flex-col gap-y-2">
      {userType === "candidate" ? CandidateHeading() : InterviewerHeading()}
      <div className="flex  flex-col space-y-1">
        {displayText.map((text, index) => {
          return (
            <div
              key={`${text}${index}`}
              className={
                displayText.length - 1 !== index
                  ? `flex mt-3 items-center w-[441px] pb-3 border-b border-gray-400`
                  : `flex mt-3 items-center w-[441px] pb-3`
              }
            >
              <div className="w-6 h-6">
                <Image
                  src={greentick}
                  alt="greentick"
                  width="18px"
                  height="18px"
                />
              </div>

              <p className=" flex-1 text-[18px] leading-[34px] tracking-[-0.005em]">
                {text}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const CandidateHeading = () => {
  return (
    <h2 className="text-[44px] leading-[55px] font-extrabold mb-4">
      You're One Step Away
      <br />
      from Your <span className="text-customblue">Dream Job</span>
    </h2>
  );
};
const InterviewerHeading = () => {
  return (
    <h2 className="text-[44px] leading-[55px] font-extrabold mb-4">
      One Step Away from
      <br />
      <span className="text-customblue">Guiding</span> Candidates
    </h2>
  );
};
export default LeftPart;
