"use client";
import { Input } from "@/components/ui/input";
import Image from "next/image";
import React, { useEffect, useState } from "react";
import Redcross from "../../../assets/ic_error_colored.png";
import GoogleIcon from "../../../assets/Google-Original.png";

import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useForm } from "react-hook-form";
import { useAtom } from "jotai";
import { mobileNoAtom } from "@/store/authAtoms";
import { useGenerateOtpMutation } from "@/hooks/authHooks";
const LoginForm = ({ userType, setOtpMode }) => {
  const userSpecificContent =
    userType === "candidate" ? candidateContent() : interviewerContent();
  const [mobileNoState, setMobileNoState] = useAtom(mobileNoAtom);
  const { mutate: generateOtp } = useGenerateOtpMutation();
  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm();
  const mobileNo = watch("mobileNo"); // 👈 Watch the field in real time
  const isDisabled = !mobileNo || mobileNo.trim() === "";
  const handleGenerateOtp = async (data) => {
    console.log("this isd data", data.mobileNo);
    // Call generate otpmut
    setMobileNoState(data.mobileNo);
    generateOtp(
      {
        type: "Mobile",
        value: data.mobileNo,
        deviceId: 1215,
        resendFlag: "0",
        registration: 0,
      },
      {
        onSuccess: (data) => {
          // Only runs when OTP was successfully sent
          if (data?.status === "Success") {
            setOtpMode(true);
          }
        },
      }
    );
  };
  return (
    <form
      onSubmit={handleSubmit(handleGenerateOtp)}
      className="flex flex-col gap-10 pt-5"
    >
      {/* heading */}
      <div className="flex flex-col ">
        <h2 className="text-[40px] leading-[100%] font-semibold text-center mb-4">
          Log in to get started.
        </h2>
        {userSpecificContent}
      </div>
      {/* Mobile no */}
      <div className="flex flex-col gap-3">
        <label className="text-base text-textgrey font-normal">
          Mobile number
        </label>
        <Input
          placeholder="Enter your mobile number"
          aria-invalid={!!errors.mobileNo}
          onKeyDown={(e) => {
            const allowedKeys = [
              "Backspace",
              "Delete",
              "ArrowLeft",
              "ArrowRight",
              "Tab",
            ];
            if (!/[0-9]/.test(e.key) && !allowedKeys.includes(e.key)) {
              e.preventDefault();
            }
          }}
          {...register("mobileNo", {
            required: "Mobile number is required",
            pattern: {
              value: /^[6-9]\d{9}$/, // Indian 10-digit number starting with 6-9
              message: "Please enter valid mobile number",
            },
          })}
        />
        {/* Incorrect error message */}
        {errors.mobileNo && (
          <div className="flex items-center gap-2">
            <div className="h-4 w-6">
              <Image src={Redcross} alt="redcross" height={16} width={16} />
            </div>
            <label className="text-sm text-red-500">
              {errors.mobileNo.message}
            </label>
          </div>
        )}
        {/* <div className="flex items-center gap-2">
          <div className="h-4 w-6">
            <Image src={Redcross} alt="redcross" height={16} width={16} />
          </div>

          <label className="text-sm text-red-500">
            Please enter valid mobile number
          </label>
        </div> */}
      </div>
      {/* Generate OTP or Login gmail */}
      <div className="flex flex-col gap-8">
        <Button type="submit" disabled={isDisabled} size={"lg"}>
          Generate Otp
        </Button>
        {/* Separator */}

        <div className="flex items-center px-14 gap-2">
          <Separator className="flex-1" />
          <span className="text-sm font-normal text-textgrey">OR</span>
          <Separator className="flex-1" />
        </div>
        {/* Google Login */}
        <Button size={"lg"} variant={"googleButton"}>
          <Image src={GoogleIcon} alt="google" height={16} width={16} />
          <span>Continue with Google</span>
        </Button>
        <div className="flex justify-center px-14 gap-2">
          <label className="text-sm font-normal  text-textgrey">
            Don’t you have an account ?
            <span className="text-customblue">Sign up</span>
          </label>
        </div>
      </div>
    </form>
  );
};

const candidateContent = () => {
  return (
    <p className="text-center text-base text-wrap text-textgrey">
      Ace your tech career with realistic mock interviews
      <br /> led by industry experts.
    </p>
  );
};
const interviewerContent = () => {
  return (
    <p className="text-center text-base text-wrap text-textgrey">
      Contribute to the tech community through
      <br /> mock interviews and feedback.
    </p>
  );
};
export default LoginForm;
