import React from "react";
import LoginOtpForm from "./LoginOtpForm";
import LoginForm from "./LoginForm";

const AuthWrapper = ({ userType, otpMode, setOtpMode }) => {
  return otpMode ? (
    <LoginOtpForm userType={userType} onBack={() => setOtpMode(false)} />
  ) : (
    <LoginForm userType={userType} setOtpMode={setOtpMode} />
  );
};

export default AuthWrapper;
