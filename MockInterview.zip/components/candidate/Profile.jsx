"use client";
import React, { useEffect, useRef, useState } from "react";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import PillInput from "../ui/pill-input";
import { ExperienceInput } from "../auth/signup/ExperienceInput";
import { useForm } from "react-hook-form";
import { CustomDropDown } from "../auth/signup/CustomDropDown";
import { CustomInput } from "../auth/signup/CustomInput";
import { useEditUserProfile, useGetUserProfile } from "@/hooks/userHooks";
import Image from "next/image";
import { FaEdit } from "react-icons/fa";

const Profile = () => {
  const { data: profileData, isFetched, isSuccess } = useGetUserProfile();
  const editMutation = useEditUserProfile();

  const {
    register,
    handleSubmit,
    control,
    getValues,
    setValue,
    formState: { errors },
    watch,
  } = useForm({});

  const goalOptions = [
    { label: "Placement", value: "Placement" },
    { label: "Learning", value: "Learning" },
    { label: "Networking", value: "Networking" },
    { label: "Career Change", value: "Career Change" },
    { label: "Job Search", value: "Job Search" },
  ];

  const [skills, setSkills] = useState([]);

  useEffect(() => {
    setSkills(profileData?.data?.result?.skills?.split("||") || []);
    setValue("firstName", profileData?.data?.result?.firstName);
    setValue("lastName", profileData?.data?.result?.lastName);
    setValue("mobile", profileData?.data?.result?.phone);
    setValue("email", profileData?.data?.result?.email);
    setValue("goal", profileData?.data?.result?.goal);
    setValue("experienceYear", profileData?.data?.result?.experienceInYears);
    setValue("experienceMonth", profileData?.data?.result?.experienceInMonths);
    setValue("domain", profileData?.data?.result?.domain);
    setValue("education", profileData?.data?.result?.education);
    // console.log(profileData?.data?.result);
  }, [profileData]);

  const onSubmit = (data) => {
    // console.log(data);
    const oldData = profileData?.data?.result;

    // console.log(oldData);

    const formData = new FormData();
    oldData?.firstName != data?.firstName &&
      formData.append("firstName", data?.firstName);
    oldData?.lastName != data?.lastName &&
      formData.append("lastName", data?.lastName);
    oldData?.phone != data?.mobile && formData.append("phone", data?.mobile);
    oldData?.email != data?.email && formData.append("email", data?.email);
    oldData?.goal != data?.goal && formData.append("goal", data?.goal);
    oldData?.experienceInYears != data?.experienceYear &&
      formData.append("experienceInYears", data?.experienceYear);
    oldData?.experienceInMonths != data?.experienceMonth &&
      formData.append("experienceInMonths", data?.experienceMonth);
    oldData?.domain != data?.domain && formData.append("domain", data?.domain);
    oldData?.education != data?.education &&
      formData.append("education", data?.education);

    formData.append("skillsUsed", skills.join("||"));

    // console.log(oldData?.firstName != data?.firstName && data?.firstName);

    // // If uploading files (e.g., profile picture)
    // if (profileImageFile) {
    //   formData.append("profileImage", profileImageFile);
    // }

    const confirmation = confirm(
      "Are you sure want to make the changes in yoour profile?"
    );

    confirmation && editMutation.mutate(formData);
  };

  const fileInputRef = useRef();
  const [imagePreview, setImagePreview] = useState();

  const handleEditClick = () => {
    fileInputRef.current?.click(); // Trigger hidden file input
  };

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === "string") {
          setImagePreview(reader.result);
          // You can now send `file` in a FormData if needed
          const formData = new FormData();
          formData.append("image", file);
          // TODO: send formData to API or backend here
          console.log("Ready to upload:", file);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const [emailEditMode, setEmailEditMode] = useState(false);
  const [mobileEditMode, setMobileEditMode] = useState(false);
  const [emailValue, setEmailValue] = useState("");
  const [mobileValue, setMobileValue] = useState("");

  const handleEmailClick = () => {
    if (!emailEditMode) {
      setEmailEditMode(true);
    } else {
      // Email verification logic here
      console.log("Verifying email:", emailValue);
      // setEmailEditMode(false); // Optional: lock it again after verification
    }
  };

  const handleMobileClick = () => {
    if (!mobileEditMode) {
      setMobileEditMode(true);
    } else {
      // Mobile verification logic here
      console.log("Verifying mobile:", mobileValue);
      // setMobileEditMode(false); // Optional
    }
  };

  return (
    <div>
      {isSuccess && (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          <div className="flex w-full justify-between items-center">
            <div className="flex items-center gap-x-6 select-none">
              <div className="relative w-[90px] h-[90px]">
                <Image
                  src={
                    imagePreview || profileData?.data?.result?.profilePicture
                  } // Replace with your default image URL
                  alt=""
                  fill
                  className="rounded-full object-cover bg-gray-300"
                />
                <div
                  onClick={handleEditClick}
                  className="absolute bottom-0 right-0 bg-white rounded-full p-1 shadow-sm cursor-pointer"
                >
                  <FaEdit className="text-gray-600 text-xs" />
                </div>
                <input
                  type="file"
                  accept="image/*"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  className="hidden"
                />
              </div>
              <div>
                <p>
                  {profileData?.data?.result?.firstName}{" "}
                  {profileData?.data?.result?.lastName}
                </p>
                <p className="text-xs text-gray-400">
                  {profileData?.data?.result?.email}
                </p>
              </div>
            </div>
          </div>

          <div>
            <div className="grid grid-cols-3 gap-x-8 gap-y-4">
              <CustomInput
                label="First Name"
                name="firstName"
                placeholder="Enter your first name"
                register={register}
                errors={errors}
                rules={{ required: "First name is required" }}
              />
              <CustomInput
                label="Last Name"
                name="lastName"
                placeholder="Enter your last name"
                register={register}
                errors={errors}
                rules={{ required: "Last name is required" }}
              />
              <div>
                <CustomInput
                  label="Mobile Number"
                  name="mobile"
                  placeholder="Enter your mobile number"
                  register={register}
                  errors={errors}
                  rules={{ required: "Mobile number is required" }}
                  disabled={!mobileEditMode}
                />
                <p
                  onClick={handleMobileClick}
                  style={{ cursor: "pointer" }}
                  className="text-customblue text-xs text-end mt-2"
                >
                  {mobileEditMode ? "Verify Mobile" : "Change Mobile Number"}
                </p>
              </div>

              <div>
                <CustomInput
                  label="Email"
                  name="email"
                  placeholder="Enter your email"
                  register={register}
                  errors={errors}
                  rules={{
                    required: "Email is required",
                    pattern: {
                      value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                      message: "Enter a valid email address",
                    },
                  }}
                  disabled={!emailEditMode}
                />
                <p
                  onClick={handleEmailClick}
                  style={{ cursor: "pointer" }}
                  className="text-customblue text-xs text-end mt-2"
                >
                  {emailEditMode ? "Verify Email" : "Change Email"}
                </p>
              </div>
              <CustomInput
                label="Education"
                name="education"
                placeholder="Enter your education"
                register={register}
                errors={errors}
                rules={{ required: "Education is required" }}
              />

              <CustomDropDown
                label="Goal"
                name="goal"
                placeholder="Select your Goal"
                register={register}
                control={control}
                errors={errors}
                options={goalOptions}
                rules={{ required: "Goal is required" }}
                defaultValue={profileData?.data?.result?.goal}
              />
              <ExperienceInput
                register={register}
                errors={errors}
                nameYear="experienceYear"
                nameMonth="experienceMonth"
                rulesYear={{
                  required: "Year is required",
                  pattern: {
                    value: /^\d+$/,
                    message: "Only numbers allowed",
                  },
                }}
                rulesMonth={{
                  required: "Month is required",
                  pattern: {
                    value: /^([0-9]|1[0-1])$/,
                    message: "Enter month between 0 and 11",
                  },
                }}
              />

              <CustomInput
                label="Domain"
                name="domain"
                placeholder="Enter your domain"
                register={register}
                errors={errors}
                rules={{ required: "Domain is required" }}
              />
            </div>

            <div className="mt-4 w-full">
              <PillInput defaultSkills={skills} setSkills={setSkills} />
            </div>
          </div>

          <Button className={"px-8"} type="submit">
            Save
          </Button>
        </form>
      )}
    </div>
  );
};

export default Profile;
