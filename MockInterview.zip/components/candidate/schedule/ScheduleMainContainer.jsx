"use client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import React, { useState } from "react";
import { Separator } from "@/components/ui/separator";
import PopupWrapper from "@/components/Wrappers/PopupWrapper";
import InterviewCard from "./InterviewCard/InterviewCard";
import { useAtom } from "jotai";
import {
  openCancelModalAtom,
  openCandidateRescheduleModalAtom,
  openConfirmRescheduleModalAtom,
  openInterviewResceduleModalAtom,
  openSuccesfulResceduleModalAtom,
} from "@/store/modalOpenAtoms";
import RescheduleMainContainer from "./Reschedule/RescheduleMainContainer";
import ConfirmRescheduleModal from "./ConfirmRescheduleModal";
import SuccesfulResceduleModal from "./SuccesfulResceduleModal";
import CancelModal from "./CancelModal";
import RescheduleTab from "./InterviewCard/RescheduleTab";
import NoData from "@/components/main/NoData";
import scheduleCandidate from "@/assets/scheduleCandidate.png";
import { useDashboardDetailsQuery } from "@/hooks/dashboardHooks";
import InterviewrRescheduleModal from "@/components/interviewer/schedule/InterviewrRescheduleModal";
const ScheduleMainContainer = () => {
  const { data: dashboard, isLoading, error } = useDashboardDetailsQuery();
  const [openRescheduleModal, setopenRescheduleModal] = useAtom(
    openCandidateRescheduleModalAtom
  );
  const [openConfirmRescheduleModal, setopenConfirmRescheduleModal] = useAtom(
    openConfirmRescheduleModalAtom
  );
  const [openSuccesfulResceduleModal, setopenSuccesfulResceduleModal] = useAtom(
    openSuccesfulResceduleModalAtom
  );
  const [openRescheduleReasonModal, setopenRescheduleReasonModal] = useAtom(
    openInterviewResceduleModalAtom
  );
  const [openCancelModal, setopenCancelModal] = useAtom(openCancelModalAtom);
  const [typeOfInterviewCard, settypeOfInterviewCard] = useState("Upcoming");

  // Replace these flags with real query/data logic

  const isUpcomingData = dashboard?.upcomingInterviews?.length > 0;
  const isCompletedData = dashboard?.completedInterviews?.length > 0;
  const isRescheduledData = dashboard?.rescheduleRequested?.length > 0;
  const isCancelledData = dashboard?.cancelledInterviews?.length > 0;

  const isFirstTimeUser =
    !isUpcomingData &&
    !isCompletedData &&
    !isRescheduledData &&
    !isCancelledData;
  if (isLoading) {
    return (
      <div className="text-center py-16 text-muted-foreground">Loading...</div>
    );
  }
  return (
    <div className="flex w-full flex-col gap-6">
      {isFirstTimeUser ? (
        <NoData
          mainCss=""
          paddingX=""
          paddingY="py-17"
          titleOfPage=""
          icon={scheduleCandidate}
          iconWidth="100"
          altTtitle="Your interview journey starts here."
          altPara1="Take the first step toward confidence and clarity. Book your mock interview now."
          backgroundButtonLink="/explore"
          backgroundButton="Explore Interviewers"
        />
      ) : (
        <>
          {" "}
          <h1 className="text-base font-semibold">
            Manage your upcoming and past interviews
          </h1>
          <Tabs
            defaultValue={typeOfInterviewCard}
            onValueChange={(value) => settypeOfInterviewCard(value)}
          >
            <TabsList className="w-fit gap-x-6 h-[40px]">
              <TabsTrigger value="Upcoming">Upcoming</TabsTrigger>
              <TabsTrigger value="Completed">Completed</TabsTrigger>
              <TabsTrigger value="Rescheduled">Rescheduled Request</TabsTrigger>
              <TabsTrigger value="Cancelled">Cancelled</TabsTrigger>
            </TabsList>

            <TabsContent
              className="bg-greyBgColor rounded-2xl p-4"
              value="Upcoming"
            >
              {isUpcomingData ? (
                <>
                  {dashboard?.upcomingInterviews.map((data, index) => {
                    return (
                      <div key={data.scheduleId}>
                        <InterviewCard type={typeOfInterviewCard} data={data} />
                        {index !== dashboard.upcomingInterviews.length - 1 && (
                          <Separator />
                        )}
                      </div>
                    );
                  })}
                </>
              ) : (
                <NoData
                  mainCss=""
                  paddingX=""
                  paddingY="py-17"
                  titleOfPage=""
                  altPara1="No upcoming interviews found."
                />
              )}
            </TabsContent>

            <TabsContent
              className="bg-greyBgColor rounded-2xl p-4"
              value="Completed"
            >
              {isCompletedData ? (
                <>
                  <InterviewCard type={typeOfInterviewCard} />
                  <Separator />
                  <InterviewCard type={typeOfInterviewCard} />
                </>
              ) : (
                <NoData
                  mainCss=""
                  paddingX=""
                  paddingY="py-17"
                  titleOfPage=""
                  altPara1="No completed interviews found."
                />
              )}
            </TabsContent>

            <TabsContent
              className="bg-greyBgColor rounded-2xl p-4"
              value="Rescheduled"
            >
              {isRescheduledData ? (
                <RescheduleTab />
              ) : (
                <NoData
                  mainCss=""
                  paddingX=""
                  paddingY="py-17"
                  titleOfPage=""
                  altPara1="No rescheduled interviews found."
                />
              )}
            </TabsContent>

            <TabsContent
              className="bg-greyBgColor rounded-2xl p-4"
              value="Cancelled"
            >
              {isCancelledData ? (
                <InterviewCard type={typeOfInterviewCard} />
              ) : (
                <NoData
                  mainCss=""
                  paddingX=""
                  paddingY="py-17"
                  titleOfPage=""
                  altPara1="No cancelled interviews found."
                />
              )}
            </TabsContent>
          </Tabs>
        </>
      )}

      {/* Popups */}
      <PopupWrapper
        isOpen={openRescheduleModal}
        isClose={() => setopenRescheduleModal(!openRescheduleModal)}
      >
        <RescheduleMainContainer />
      </PopupWrapper>

      <PopupWrapper
        isOpen={openRescheduleReasonModal}
        isClose={() => setopenRescheduleReasonModal(!openRescheduleReasonModal)}
      >
        <InterviewrRescheduleModal />
      </PopupWrapper>
      <PopupWrapper
        isOpen={openConfirmRescheduleModal}
        isClose={() =>
          setopenConfirmRescheduleModal(!openConfirmRescheduleModal)
        }
      >
        <ConfirmRescheduleModal />
      </PopupWrapper>

      <PopupWrapper
        isOpen={openSuccesfulResceduleModal}
        isClose={() =>
          setopenSuccesfulResceduleModal(!openSuccesfulResceduleModal)
        }
      >
        <SuccesfulResceduleModal />
      </PopupWrapper>

      <PopupWrapper
        isOpen={openCancelModal}
        isClose={() => setopenCancelModal(!openCancelModal)}
      >
        <CancelModal />
      </PopupWrapper>
    </div>
  );
};

export default ScheduleMainContainer;
