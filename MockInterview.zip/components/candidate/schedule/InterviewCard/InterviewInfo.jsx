import React from "react";
import { BsCalendar, BsClock } from "react-icons/bs";
import Chip from "../Chip";
import { formatTimeRange } from "@/lib/utils";
import { da } from "date-fns/locale";
import { format } from "date-fns";

const InterviewInfo = ({
  type,
  data = {
    scheduleId: 21,
    slotId: 28,
    date: "2025-07-01",
    startTime: "12:00:00",
    endTime: "13:00:00",
    status: "scheduled",
    skill: "Springboot",
    userName: "TestInter One",
    videoConferenceLink: null,
    feedbackStatus: null,
    rating: null,
    rescheduleReason: null,
    rescheduleBy: 0,
    cancelledReason: null,
    cancelledBy: 0,
  },
}) => {
  return (
    <div>
      <p className="">{data?.userName}</p>
      <div className="flex gap-x-8 text-[14px] text-[#979797] mt-2">
        <div className="flex items-center gap-x-1">
          <BsCalendar />
          <span>{format(new Date(data?.date), "MMM dd, yyyy")}</span>
        </div>
        <div className="flex items-center gap-x-1">
          <BsClock />
          <span>{formatTimeRange(data?.startTime, data?.endTime)}</span>
        </div>
      </div>
      <div className="flex flex-wrap gap-x-4 text-xs mt-2">
        {data?.skill?.split("||").map((text) => {
          return <Chip key={text} text={text} />;
        })}
        {/* <Chip text={"Vue Js"} />

        <Chip text={"React Js"} />
        <Chip text={"Node Js"} /> */}
      </div>
    </div>
  );
};

export default InterviewInfo;
