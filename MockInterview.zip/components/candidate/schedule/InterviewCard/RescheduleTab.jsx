import React from "react";
import InterviewInfo from "./InterviewInfo";
import { RightPart } from "@/components/auth/login/RightPart";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import TimeIcon from "../../../../assets/TimeIcon.png";
import { BsCalendar, BsClock } from "react-icons/bs";
import Chip from "../Chip";
import { MdOutlineSchedule } from "react-icons/md";
import { Separator } from "@/components/ui/separator";
import { useAtom } from "jotai";
import {
  openCancelModalAtom,
  openCandidateRescheduleModalAtom,
  openSuccesfulResceduleModalAtom,
} from "@/store/modalOpenAtoms";
import StatusChip from "@/components/ui/CustomStatusChip";
const RescheduleTab = () => {
  return (
    <div className="flex flex-col space-y-3">
      {/* Interviewr request */}
      <div className="flex flex-col space-y-4">
        <ReqCard />
        <ReqCard />
      </div>
      <div className=" flex flex-col bg-greyBgColor rounded-2xl p-4">
        <CandidateReqCard />
        <Separator />
        <CandidateReqCard />
      </div>
    </div>
  );
};

const ReqCard = () => {
  return (
    <div className="flex justify-between my-4 bg-[#FFFBED]  border border-[#FAE696] rounded-xl p-4">
      <ReqInterviewInfo />
      <ResceduleRightPart type={"request"} />
    </div>
  );
};

const CandidateReqCard = () => {
  return (
    <div className="flex justify-between my-4 ">
      <InterviewInfo />
      <ResceduleRightPart />
    </div>
  );
};
const ResceduleRightPart = ({ type }) => {
  const [openCancelModal, setopenCancelModal] = useAtom(openCancelModalAtom);
  const [openRescheduleModal, setopenRescheduleModal] = useAtom(
    openCandidateRescheduleModalAtom
  );
  return (
    <div className="flex  items-center space-x-6">
      {type !== "request" && <StatusChip text={"Pending"} />}

      {/* Buttons */}
      <div className="flex items-center space-x-4">
        <Button
          onClick={() => setopenCancelModal(true)}
          variant={"outline"}
          size={"sm"}
        >
          Cancel
        </Button>
        <Button onClick={() => setopenRescheduleModal(true)}>
          Reschedule Now
        </Button>
      </div>
    </div>
  );
};

const ReqInterviewInfo = () => {
  return (
    <div className="flex space-x-1.5">
      <div className="flex items-center justify-center w-6 h-6">
        <MdOutlineSchedule className="text-base text-[#F59E0B]" />
      </div>

      <div className="flex flex-col space-y-2 flex-1">
        <p>
          Karuna Varma{" "}
          <span className="text-xs text-textgrey font-medium ">
            (2 hours ago)
          </span>
        </p>
        <div className="flex gap-x-8 text-[14px] text-[#979797] mt-2">
          <div className="flex items-center gap-x-1">
            <BsCalendar />
            <span>Apr 16, 2025</span>
          </div>
          <div className="flex items-center gap-x-1">
            <BsClock />
            <span>010:00 AM - 30:00 AM</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-x-4 text-xs mt-2">
          <Chip text={"Vue Js"} />
          <Chip text={"React Js"} />
          <Chip text={"Node Js"} />
        </div>
        <p className="text-sm text-textgrey font-normal">
          The interviewer has requested to reschedule this interview
        </p>
      </div>
    </div>
  );
};
export default RescheduleTab;
