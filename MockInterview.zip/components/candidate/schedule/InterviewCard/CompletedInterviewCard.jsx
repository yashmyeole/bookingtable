import React from "react";
import InterviewInfo from "./InterviewInfo";

import CompletedRightPart from "./CompletedRightPart";

const CompletedInterviewCard = () => {
  return (
    <div className="flex justify-between my-4 ">
      <InterviewInfo />
      <CompletedRightPart />
    </div>
  );
};

export default CompletedInterviewCard;
