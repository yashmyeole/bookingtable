import React from "react";

import InterviewInfo from "./InterviewInfo";
import UpcomingRightPart from "./UpcomingRightPart";
import CompletedRightPart from "./CompletedRightPart";
import CancelledInterviewCard from "./CancelledInterviewCard";

const InterviewCard = ({ type, data }) => {
  return (
    //my-4 for separator
    <div className="flex justify-between my-4 ">
      <InterviewInfo data={data} />
      {type === "Upcoming" && <UpcomingRightPart data={data} />}
      {type === "Completed" && <CompletedRightPart />}
      {type === "Cancelled" && <CancelledInterviewCard />}
    </div>
  );
};

export default InterviewCard;
