import React from "react";
import { Star } from "lucide-react";

/**
 * StarRating Component (Controlled)
 *
 * Props:
 * - value: Current selected rating (controlled)
 * - totalStars: Total number of stars (default 5)
 * - size: Star icon size in pixels (default 24)
 * - fillColor: Tailwind class for filled stars (default "text-yellow-400")
 * - emptyColor: Tailwind class for empty stars (default "text-gray-200")
 * - onChange: Callback function when rating changes
 * - readOnly: If true, disables interaction
 */
const StarRating = ({
  value,
  totalStars = 5,
  size = 24,
  fillColor = "text-yellow-400",
  emptyColor = "text-gray-200",
  onChange = () => {},
  readOnly = false,
}) => {
  const handleClick = (index) => {
    if (readOnly) return;
    onChange(index);
  };

  return (
    <div className="flex gap-1">
      {Array.from({ length: totalStars }, (_, i) => {
        const current = i + 1;
        const isFilled = current <= value;

        return (
          <Star
            key={i}
            onClick={() => handleClick(current)}
            className={`transition-all duration-200 ease-in-out 
              ${isFilled ? fillColor : emptyColor} 
              ${readOnly ? "cursor-default" : "cursor-pointer"}`}
            size={size}
            fill={isFilled ? "currentColor" : "none"}
            strokeWidth={1.5}
            stroke="currentColor"
          />
        );
      })}
    </div>
  );
};

export default StarRating;
