import React, { useState } from "react";
import StatusChip from "../../../ui/CustomStatusChip";
import { Button } from "@/components/ui/button";
import { TfiDownload } from "react-icons/tfi";
import StarRating from "./StartRating";

const CompletedRightPart = () => {
  const [rating, setRating] = useState(0);

  return (
    <div className="flex  items-center space-x-6">
      <StatusChip text={"Completed"} />
      {/* <StatusChip
        text={"Rescheduled"}
        color={"bg-lightOrangeBg"}
        textColor={"text-orangeText"}
      /> */}

      {/* Buttons */}
      <div className=" flex items-center space-x-4">
        <Button variant={"outline"} size={"sm"}>
          <TfiDownload />
          Recording
        </Button>
        <Button variant={"outline"} size={"sm"}>
          View Feedback
        </Button>
      </div>

      {/* Ratings */}
      <div className="flex flex-col space-y-4">
        <p className="text-base font-normal text-textgrey">Rate Rohan Mehta</p>
        <StarRating
          value={rating}
          onChange={setRating}
          fillColor="text-yellow-500"
          emptyColor="text-gray-300"
          size={28}
        />
      </div>
    </div>
  );
};

export default CompletedRightPart;
