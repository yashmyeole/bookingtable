import React from "react";
import StatusChip from "../../../ui/CustomStatusChip";
import { Button } from "@/components/ui/button";
import { useAtom } from "jotai";
import {
  openCandidateRescheduleModalAtom,
  openInterviewResceduleModalAtom,
} from "@/store/modalOpenAtoms";
import { capitalizeFirstLetter } from "@/lib/utils";
import { rescheduleSlotDataAtom } from "@/store/rescheduleAtom";

const UpcomingRightPart = ({ data }) => {
  const [openRescheduleModal, setopenRescheduleModal] = useAtom(
    openCandidateRescheduleModalAtom
  );
  const [openRescheduleReasonModal, setopenRescheduleReasonModal] = useAtom(
    openInterviewResceduleModalAtom
  );
  const [rescheduleSlotData, setopenrescheduleSlotData] = useAtom(
    rescheduleSlotDataAtom
  );
  const handleReschedule = () => {
    console.log("Data that i Have", data);
    setopenrescheduleSlotData(data);
    setopenRescheduleReasonModal(true);
  };
  return (
    <div className="flex  items-center space-x-6">
      {/* It will be scheduled or resheduled whic diffrent Color */}
      <StatusChip text={capitalizeFirstLetter(data.status)} />
      {/* <StatusChip
        text={"Rescheduled"}
        color={"bg-lightOrangeBg"}
        textColor={"text-orangeText"}
      /> */}

      {/* Buttons */}
      <div className=" flex items-center space-x-4">
        <Button size={"sm"}>Meet Link </Button>
        <Button onClick={handleReschedule} variant={"outline"} size={"sm"}>
          Reschedule
        </Button>
      </div>
    </div>
  );
};

export default UpcomingRightPart;
