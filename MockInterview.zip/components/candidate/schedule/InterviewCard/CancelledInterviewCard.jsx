import React from "react";
import InterviewInfo from "./InterviewInfo";
import StatusChip from "../../../ui/CustomStatusChip";

const CancelledInterviewCard = () => {
  return (
    <div className="flex  items-center space-x-6">
      <StatusChip text={"Cancelled"} />
    </div>
  );
};

export default CancelledInterviewCard;
