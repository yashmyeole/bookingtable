import Image from "next/image";
import React from "react";
import GreenTick from "../../../assets/greentick.png";
import { Button } from "@/components/ui/button";
const SuccesfulResceduleModal = () => {
  return (
    <div className="flex flex-col justify-center min-w-xl space-y-6">
      <div className="flex justify-center">
        <Image src={GreenTick} alt="greentick" width={28} height={28} />
      </div>
      <div className="flex flex-col ">
        <h1 className="text-xl text-center font-medium">
          Your interview with Anurag Tyagi has been <br />
          rescheduled
        </h1>
        <p className="text-base font-medium text-center text-[#666666]">
          Your interview has been rescheduled successfully
        </p>
      </div>
      <p className="text-base font-normal  text-center">
        New schedule: April 18, 2025,02:00 PM - 03:00 PM
      </p>
      <div className="flex justify-center">
        <Button className="px-6">Done</Button>
      </div>
    </div>
  );
};

export default SuccesfulResceduleModal;
