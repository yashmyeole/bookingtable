import { Button } from "@/components/ui/button";
import React from "react";
import { MdOutlineSchedule } from "react-icons/md";
const ConfirmRescheduleModal = () => {
  return (
    <div className="flex flex-col gap-6 min-w-xl">
      {/* Title */}
      <div className="flex w-full flex-col ">
        <h1 className="text-[22px] font-medium">Confirm Reschedule</h1>
        <p className="text-[16px] text-textgrey">
          Please review the new interview date and time
        </p>
      </div>
      {/* Review Part */}
      <div className="flex flex-col bg-[#F9FAFB] space-y-2 py-3 px-6 border border-[#E0E0E0] rounded-md ">
        <div className="flex justify-between">
          <p className="text-base text-[#666666]">Previous Date & Time :</p>
          <p className="text-base">April 12, 2025, 09:00 AM - 10:00 AM</p>
        </div>
        <div className="flex justify-between">
          <p className="text-base text-[#666666]">New Date & Time :</p>
          <p className="text-base">11:30 AM - 12:30 PM</p>
        </div>
        <div className="flex justify-between">
          <p className="text-base text-[#666666]">Reason :</p>
          <p className="text-base">Personal emergency</p>
        </div>
      </div>
      {/* Interview rescedule by interviewe */}
      <div className="flex space-x-2 items-center border border-[#FAE696] bg-[#FFFBED] rounded-md p-4">
        <MdOutlineSchedule className="text-base text-[#F59E0B]" />
        <p className="text-base text-[#666666]">
          {" "}
          The interviewer has requested to reschedule this interview
        </p>
      </div>
      {/* Buttons */}
      <div className="flex justify-center space-x-6">
        <Button variant={"outline"}>Cancel</Button>
        <Button>Confirm Reschedule</Button>
      </div>
    </div>
  );
};

export default ConfirmRescheduleModal;
