"use client";
import { Calendar } from "@/components/ui/calendar";
import React, { useEffect, useState } from "react";

const CustomCalender = () => {
  const [date, setDate] = useState(new Date(2025, 6, 15));
  const [highlightedDates, setHighlightedDates] = useState([]);

  useEffect(() => {
    setDate(new Date(2025, 6, 15));
    setHighlightedDates([
      new Date(2025, 6, 5),
      new Date(2025, 6, 12),
      new Date(2025, 6, 20),
    ]);
  }, []);
  // Create modifier object
  const modifiers = {
    highlighted: highlightedDates,
  };
  return (
    <Calendar
      mode="single"
      defaultMonth={date}
      selected={date}
      onSelect={setDate}
      modifiers={modifiers}
      className="scale-[0.72] origin-top"
      showOutsideDays={false}
    />
  );
};

export default CustomCalender;
