"use client";
import { Calendar } from "@/components/ui/calendar";
import { rescheduleSlotDataAtom } from "@/store/rescheduleAtom";
import { setDate } from "date-fns";
import { useAtom } from "jotai";
import React, { useEffect, useState } from "react";

const CustomCalenderReschedule = ({
  selectedDate,
  setSelectedDate,
  highlightedDays = [],
}) => {
  // Create modifier object
  let modifiers = {
    highlighted: highlightedDays,
  };
  console.log("modifier", modifiers);

  // Allow only highlighted dates + selectedDate
  const allowedDates = [...highlightedDays?.map((d) => d.toDateString())];
  if (selectedDate) allowedDates.push(selectedDate.toDateString());

  const isAllowedDate = (date) => {
    return allowedDates.includes(date.toDateString()) ? false : true; // false = not disabled
  };
  return (
    <Calendar
      mode="single"
      defaultMonth={selectedDate}
      selected={selectedDate}
      onSelect={setSelectedDate}
      modifiers={modifiers}
      disabled={isAllowedDate}
      className="scale-[0.72] origin-top"
      showOutsideDays={false}
    />
  );
};

export default CustomCalenderReschedule;
