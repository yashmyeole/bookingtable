"use client";
import React, { useState } from "react";

import AvailableSlot from "./AvailableSlot";
import { Button } from "@/components/ui/button";
import dynamic from "next/dynamic";
import {
  rescheduleReasonAtom,
  rescheduleSlotDataAtom,
} from "@/store/rescheduleAtom";
import { useAtom } from "jotai";
import CustomCalenderReschedule from "./CustomCalenderReschedule";
import { endOfMonth, format, startOfMonth } from "date-fns";
import {
  useAvailableDaysQuery,
  useInterviewScheduleByDateQuery,
} from "@/hooks/scheduleHooks";

// const CustomCalendar = dynamic(() => import("./CustomCalender"), {
//   ssr: false,
// });
const RescheduleMainContainer = () => {
  const [rescheduleSlotData, setrescheduleSlotData] = useAtom(
    rescheduleSlotDataAtom
  );
  const [date, setDate] = useState(new Date(rescheduleSlotData.date));
  const monthStartDate = format(startOfMonth(date), "yyyy-MM-dd");
  const monthEndDate = format(endOfMonth(date), "yyyy-MM-dd");
  const { data: availableDates, isLoadingDate } = useAvailableDaysQuery({
    userId: 48, //harcoded
    startDate: monthStartDate,
    endDate: monthEndDate,
  });
  const { data: interviewSlots, isLoadingSlots } =
    useInterviewScheduleByDateQuery({
      userId: 48,
      startDate: format(date, "yyyy-MM-dd"),
      endDate: format(date, "yyyy-MM-dd"),
    });
  const [selectedId, setSelectedId] = useState();
  return (
    <div className="flex w-xl  flex-col  space-y-4">
      {/* Tittle */}
      <div className="flex flex-col">
        <h1 className="text-[22px] font-medium">Reschedule interview</h1>
        <p className="text-sm text-textgrey font-medium">
          {`Reschedule your interview with ${rescheduleSlotData.userName}`}
        </p>
      </div>
      <div className="flex flex-col space-y-3">
        <p className="text-base font-medium text-center">
          Select new date & time slot
        </p>
        <div className="flex justify-center h-[200px] border border-[#C4C4C4] rounded-xl  w-full">
          {isLoadingDate ? (
            <div>Loading ...</div>
          ) : (
            <CustomCalenderReschedule
              selectedDate={date}
              setSelectedDate={setDate}
              highlightedDays={availableDates}
            />
          )}
        </div>
        <div className="flex  border border-[#C4C4C4] rounded-xl h-[319px] w-full overflow-y-scroll">
          {isLoadingSlots ? (
            <div>Loading...</div>
          ) : (
            <AvailableSlot
              slotDate={date}
              interviewSlots={interviewSlots}
              selectedId={selectedId}
              setSelectedId={setSelectedId}
            />
          )}
        </div>
        <div className="flex justify-center">
          <div className="flex space-x-3">
            <Button variant="outline">Cancel</Button>
            <Button>Continue</Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RescheduleMainContainer;
