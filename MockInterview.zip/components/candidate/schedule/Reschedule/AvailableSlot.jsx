"use client";
import React, { useState } from "react";
import Chip from "../Chip";
import TimeIcon from "../../../../assets/TimeIcon.png";
import Image from "next/image";
import { formatTimeRange } from "@/lib/utils";
import { format } from "date-fns";

const AvailableSlot = ({ interviewSlots = [], setSelectedId, slotDate }) => {
  const handleSelect = (id) => {
    setSelectedId(id);
  };

  return (
    <div className="flex flex-col space-y-3 w-full p-4">
      <p className="text-base font-normal text-textgrey">
        {`Showing available time slots for ${format(
          slotDate,
          "MMMM dd, yyyy"
        )} `}
      </p>
      <div className="grid grid-cols-2 gap-x-6 gap-y-5 pb-6">
        {interviewSlots.map((data, index) => {
          return (
            <SlotCard
              key={index}
              id={data.slotId}
              selectedId={data.slotId}
              onSelect={handleSelect}
              data={data}
            />
          );
        })}
      </div>
    </div>
  );
};

const SlotCard = ({ id, selectedId, onSelect, data }) => {
  const isSelected = selectedId === id;
  console.log("Selectedid", selectedId, id);
  return (
    <div
      onClick={() => onSelect(data.slotId)}
      className={`flex flex-col space-y-3 border rounded-lg p-2 cursor-pointer ${
        isSelected ? "border-customblue border-2" : "border-[#E0E0E0]"
      }`}
    >
      {/* Time */}
      <p className="text-base font-medium">
        {formatTimeRange(data.startTime, data.endTime)}
      </p>

      {/* Chips */}
      <div className="flex space-x-0.5 flex-wrap">
        {data?.skills.split("||").map((text) => {
          return <Chip key={text} text={text} />;
        })}
      </div>

      {/* Duration and price */}
      <div className="flex items-center space-x-1">
        <Image src={TimeIcon} alt="Timeicon" height={16} width={16} />
        <span className="text-textgrey">1 hr |</span>
        <span className="text-customblue">₹{data.fee}</span>
      </div>
    </div>
  );
};
export default AvailableSlot;
