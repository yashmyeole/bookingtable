import { cn } from "@/lib/utils";
import React from "react";

const Chip = ({ text, size = "regular" }) => {
  const isSmall = size === "small";

  return (
    <div
      className={cn(
        "rounded-lg bg-[#D9F4FE] flex items-center justify-center",
        isSmall
          ? "text-xs  h-[22px] rounded-[34px] px-[6px] py-[2px]"
          : "text-sm px-2 py-1"
      )}
    >
      {text}
    </div>
  );
};

export default Chip;
