import { Button } from "@/components/ui/button";
import React from "react";

const CancelModal = () => {
  return (
    <div className="flex flex-col space-y-5 py-3">
      <p className="text-base font-medium text-center">
        Do you really want to cancel the interview with{" "}
        <span className="font-semibold">Karun Sharma</span> <br />
        on <span className="font-semibold">April 20, 2025</span>?
      </p>
      <p className="text-center">
        If you proceed, a refund will be initiated to your wallet.
      </p>
      <div className="flex justify-center space-x-6">
        <Button variant={"outline"}>Yes, Cancel Interview</Button>
        <Button>No, keep Interview</Button>
      </div>
    </div>
  );
};

export default CancelModal;
