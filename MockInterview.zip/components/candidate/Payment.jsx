"use client"
import React from "react";
import { BsPlus, BsWallet } from "react-icons/bs";
import { Button } from "../ui/button";
import { FaArrowUpLong } from "react-icons/fa6";
import { FaArrowUp } from "react-icons/fa";
import NoData from "../main/NoData";
import transaction from "@/assets/transaction.png";
import { useGetTransactions, useGetWalletBalance } from "@/hooks/paymentHooks";

const Payment = () => {
  const { data: wallet} = useGetWalletBalance();
  //const { data: transactions, isFetched, isSuccess } = useGetTransactions();
  

  console.log("Wallet",wallet?.data?.data)
  const showHistory = false;
  return (
    <div className="w-full space-y-8">
      <div className="bg-[#F9F9F9] rounded-xl p-6 w-full">
        <div>
          <p className="text-lg">Your wallet</p>
          <p className="text-sm text-textgrey">
            Available balance for booking interviews
          </p>
        </div>
        <div className="flex justify-between mt-4">
          <div className="flex gap-x-6 items-center">
            <div className="flex justify-center items-center not-only:bg-customblue-light w-[60px] h-[60px] rounded-full">
              <BsWallet className="text-customblue" size={30} />
            </div>
            <div>
              <p className="text-lg text-customblue font-semibold">Rs {wallet?.data?.data?.walletBalance}</p>
              <p className="text-sm">Total balance</p>
            </div>
          </div>
          <Button>
            <BsPlus/>
            <p>Recharge wallet</p>
          </Button>
        </div>
      </div>
      {showHistory ? (
        <div className="bg-[#F9F9F9] rounded-lg p-6 w-full">
        <p className="text-lg mb-6">Transaction history</p>
        <div className="p-6 bg-white w-full rounded-lg">
          <History />
        </div>
      </div>
      ):(
        <div>
          <NoData
            mainCss=''
            paddingX=''
            paddingY='py-17'
            titleOfPage=''
            icon={transaction}
            iconWidth='100'
            altTtitle='No Transaction History Yet'
            altPara1='Your transaction history will appear here once you start booking interviews or adding money to your wallet.'
            noBackgroundButtonLink='/explore'
            noBackgroundButton='Explore Interviewers' 
          />
        </div>
      )}
    </div>
  );
};

// History Component
const History = () => {
  const HistoryComponent = () => {
    return (
      <div className="flex justify-between w-full">
        <div className="flex items-center gap-x-4">
          <div className="flex justify-center items-center bg-lightgreen w-[45px] h-[45px] rounded-full">
            <FaArrowUp className="text-darkgreen" size={20} />
          </div>
          <div className="flex flex-col justify-between">
            <p>Added to wallet</p>
            <p className="text-textgrey text-sm">April 15, 2025</p>
          </div>
        </div>
        <div className="flex flex-col items-end">
          <p className="text-darkgreen">+ 100</p>
          <p className="text-textgrey text-sm">Successful</p>
        </div>
      </div>
    );
  };
  return (
    <div className="space-y-6">
      <HistoryComponent />
      <HistoryComponent />
      <HistoryComponent />
      <HistoryComponent />
    </div>
  );
};

export default Payment;
