"use client";
import React, { useState } from "react";
import { BsCalendar, BsClock } from "react-icons/bs";
import { CustomDropDown } from "../auth/signup/CustomDropDown";
import { useForm, Controller } from "react-hook-form";
import { Button } from "../ui/button";
import StatusChip from "../ui/CustomStatusChip";
import { Calendar28 } from "../ui/datepicker";
import { Separator } from "../ui/separator";
import { useRouter } from "next/navigation";
import { useGetFeedbacks } from "@/hooks/feedbackHooks";
import { format } from "date-fns";

const Feedback = () => {
  const {
    register,
    handleSubmit,
    getValues,
    control,
    formState: { errors },
    watch,
  } = useForm();

  const statusOptions = [
    { label: "Completed", value: "completed" },
    { label: "Pending", value: "pending" },
  ];

  const [feedbackState, setFeedbackState] = useState({ date: "", status: "" });
  const { data: feedbackData, refetch } = useGetFeedbacks(feedbackState);

  const onSubmit = (data) => {
    setFeedbackState({
      date: format(data?.date, "yyyy-MM-dd"),
      status: data?.status,
    });
  };

  return (
    <div className="space-y-4">
      <p className="text-lg font-semibold">Your Interview Feedback</p>

      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex items-center gap-x-6"
      >
        <span>Filter by</span>

        <Controller
          name="date"
          control={control}
          render={({ field }) => (
            <Calendar28 value={field.value} onChange={field.onChange} />
          )}
        />

        <CustomDropDown
          name="status"
          placeholder="Status"
          register={register}
          control={control}
          errors={errors}
          options={statusOptions}
          classNameTrigger={"h-[40px] rounded-lg"}
        />

        <Button type="submit">Apply</Button>
      </form>

      {/* Feedback List */}
      {feedbackData?.data?.data?.length > 0 ? (
        <div className="bg-[#F9FAFB] px-4 py-6">
          <FeedbackDataComponent />
        </div>
      ) : (
        <div>No Data Found</div>
      )}
    </div>
  );
};

const FeedbackDataComponent = () => {
  const router = useRouter();

  const FeedbackChip = ({ text }) => (
    <div className="bg-[#D9F4FE] rounded-lg px-2 py-1">{text}</div>
  );

  return (
    <div className="flex justify-between">
      <div>
        <p className="">Karuna Varma</p>
        <div className="flex gap-x-8 text-[14px] text-[#979797] mt-2">
          <div className="flex items-center gap-x-1">
            <BsCalendar />
            <span>Apr 16, 2025</span>
          </div>
          <div className="flex items-center gap-x-1">
            <BsClock />
            <span>01:00 AM - 30:00 AM</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-x-4 text-xs mt-2">
          <FeedbackChip text={"Vue Js"} />
          <FeedbackChip text={"React Js"} />
          <FeedbackChip text={"Node Js"} />
        </div>
      </div>
      <div className="flex flex-col justify-between items-end gap-x-16 text-end">
        <p>4/5</p>
        <div className="flex justify-between items-center gap-x-12">
          <StatusChip text="Completed" />
          <button
            onClick={() => router.push("./feedback/3")}
            className="text-customblue border-[1.2px] border-customblue px-4 py-1 rounded-lg cursor-pointer"
          >
            View Feedback
          </button>
        </div>
      </div>
    </div>
  );
};

export default Feedback;
