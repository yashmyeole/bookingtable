"use client";

import { useParams, useRouter } from "next/navigation";
import { useState } from "react";
import { Separator } from "../ui/separator";
import { useGetFeedbackDetails } from "@/hooks/feedbackHooks";

export default function FeedbackDetails() {
  const skills = [
    { name: "JavaScript", rating: 4 },
    { name: "HTML", rating: 4 },
    { name: "CSS", rating: 5 },
  ];

  const router = useRouter();
  const { slug } = useParams();

  const { data: feedbackDetails, isSuccess } = useGetFeedbackDetails({
    interviewId: slug,
  });

  const tempData = isSuccess && feedbackDetails?.data;

  return (
    <>
      {isSuccess && (
        <div className="flex flex-col w-full  rounded-lg">
          <button
            className="flex text-sm text-blue-500 mb-4 hover:underline cursor-pointer"
            onClick={() => router.push("./")}
          >
            {"< Back"}
          </button>

          <div className="flex items-center gap-4 mb-12 bg-[#F9FAFB] rounded-lg p-4">
            <div className="w-16 h-16 rounded-full bg-gray-200 overflow-hidden">
              {/* Add image here if available */}
            </div>
            <div>
              <h2 className="text-xl font-semibold">
                {tempData?.student?.studentName}
              </h2>
              <p className="text-gray-500 text-sm">
                {tempData?.student?.email || "email null"}
              </p>
              <div className="flex mt-6 text-sm text-gray-600 gap-x-8">
                <div>
                  <p>Skills to be assessed:</p>
                  <p>
                    {Object.keys(tempData?.student?.technicalSkills).join(", ")}
                  </p>
                </div>
                <div>
                  <p>Experience:</p>
                  <p>{"null"} years</p>
                </div>
                <div>
                  <p>Interview date: </p>
                  <p>{tempData?.interviewDate}</p>
                </div>
              </div>
            </div>
            <div className="ml-auto">
              <span className="bg-green-100 text-green-800 px-3 py-1 text-sm rounded-full">
                Interviewed
              </span>
            </div>
          </div>

          <h3 className="text-lg font-semibold mb-2">
            Technical Skills Assessment
          </h3>
          <div className="bg-[#F9FAFB] space-y-4 rounded-lg p-4">
            {Object.entries(tempData?.student?.technicalSkills)?.map(
              (skill, index) => (
                <div key={skill[0]} className="">
                  <div className="flex items-center justify-between">
                    <span className="w-24 font-medium">{skill[0]}</span>
                    <div className="flex gap-y-2 gap-x-6">
                      {[1, 2, 3, 4, 5].map((num) => (
                        <div
                          key={num}
                          className={`w-8 h-8 flex items-center justify-center rounded-full border ${
                            num == skill[1]
                              ? " text-white bg-[#007FAD]"
                              : "bg-white text-gray-500 border-[1px] border-[#007FAD]"
                          }`}
                        >
                          {num}
                        </div>
                      ))}
                    </div>
                  </div>
                  {index != skills.length && (
                    <div className="mt-3">
                      <Separator />
                    </div>
                  )}
                </div>
              )
            )}
          </div>

          <div className="mt-12">
            <h4 className="font-semibold text-gray-800 mb-1">Strengths</h4>
            <p className="text-gray-400 text-sm">
              {tempData?.student?.strengths}
            </p>
          </div>

          <div className="mt-12">
            <h4 className="font-semibold text-gray-800 mb-1">
              Areas for Improvement
            </h4>
            <p className="text-gray-400 text-sm">
              {tempData?.student?.areasForImprovement}
            </p>
          </div>

          <div className="mt-12 flex items-center justify-between">
            <div className="flex-1 mr-4 items-center">
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className={`flex h-full bg-blue-600`}
                  style={{
                    width: `${(tempData?.student?.overallRating / 5) * 100}%`,
                  }}
                />
              </div>
              <p className="text-sm text-gray-600 mt-1">Overall Rating</p>
            </div>
            <span className="text-lg font-semibold">4/5</span>
          </div>

          <div className="mt-6 text-center">
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-md text-sm">
              Download Certificate
            </button>
          </div>
        </div>
      )}
    </>
  );
}
