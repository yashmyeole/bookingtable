"use client";
import React, { useEffect, useState } from "react";
import { BsCalendar, BsClock } from "react-icons/bs";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Separator } from "../ui/separator";
import { Button } from "../ui/button";
import StatusChip from "../ui/CustomStatusChip";
import ScheduleMainContainer from "./schedule/ScheduleMainContainer";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useGetUserProfile } from "@/hooks/userHooks";
import { useAtom } from "jotai";
import { userAtom } from "@/store/authAtoms";

const Dashboard = () => {
  const router = useRouter();
  const [userData] = useAtom(userAtom);
  const [isReady, setIsReady] = useState(false);

  // useEffect(() => {
  //   console.log("From dashboard", userData);
  //   if (userData) {
  //     setIsReady(true);
  //   }
  // }, [userData]);

  // if (!isReady) {
  //   return <div>Loading Dashboard...</div>;
  // }

  if (!userData) {
    return <div>Loading Dashboard...</div>;
  }
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-4 gap-x-6">
        <DashboardStatsComponent title="Upcoming Interviews" />
        <DashboardStatsComponent title="Completed Interviews" />
        <DashboardStatsComponent title="Awaiting Feedback" />
        <DashboardStatsComponent title="Total Spent" />
      </div>
      <div className="space-y-4">
        <div className="flex justify-between">
          <p className="text-lg">Interviews</p>
          <button
            onClick={() => router.push("./schedules")}
            className="text-customblue cursor-pointer border-[1px] border-customblue px-2 py-1 rounded-sm text-sm"
          >
            View all
          </button>
        </div>
        <div className="border-[1.2px] border-gray-200 rounded-lg p-4">
          <div>
            {/* Note this container should display only max 2 details per tab in Dashboard page */}
            <ScheduleMainContainer />
          </div>
          <div></div>
        </div>
      </div>
      <div className="space-y-4">
        <div className="flex justify-between">
          <p className="text-lg">Recent Feedback</p>
          <Link
            href="/candidate/feedback"
            className="text-customblue cursor-pointer border-[1px] border-customblue px-2 py-1 rounded-sm text-sm"
          >
            View all
          </Link>
        </div>
        <div className="border-[1.2px] border-gray-200 rounded-lg p-4 space-y-4">
          <FeedbackDataComponent />
          <div className="bg-gray-200 h-[1px]" />
          <FeedbackDataComponent />
        </div>
      </div>
    </div>
  );
};

// Components
const DashboardStatsComponent = ({ logo, number = 4, title = "title" }) => {
  return (
    <div className="flex items-center gap-x-3 border-[1.2px] border-gray-200 rounded-lg p-[16px]">
      <div className="flex justify-center items-center bg-[#D7F4FF] rounded-sm h-[55px] w-[55px]">
        {logo}
      </div>
      <div>
        <p className="text-customblue text-[24px] font-semibold">{number}</p>
        <p className="text-[#070707] text-[14px] ">{title}</p>
      </div>
    </div>
  );
};

const FeedbackDataComponent = ({}) => {
  const FeedbackChip = ({ text }) => {
    return <div className="bg-[#D9F4FE] rounded-lg px-2 py-1">{text}</div>;
  };
  return (
    <div className="flex justify-between">
      <div>
        <p className="">Karuna Varma</p>
        <div className="flex gap-x-8 text-[14px] text-[#979797] mt-2">
          <div className="flex items-center gap-x-1">
            <BsCalendar />
            <span>Apr 16, 2025</span>
          </div>
          <div className="flex items-center gap-x-1">
            <BsClock />
            <span>010:00 AM - 30:00 AM</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-x-4 text-xs mt-2">
          <FeedbackChip text={"Vue Js"} />
          <FeedbackChip text={"React Js"} />
          <FeedbackChip text={"Node Js"} />
        </div>
      </div>
      <div className="flex flex-col justify-between space-y-2 text-end">
        <p>4/5</p>
        <button className="text-customblue border-[1.2px] border-customblue px-2 py-1 rounded-lg">
          View Feedback
        </button>
      </div>
    </div>
  );
};

const InterviewDataComponent = () => {
  const UpcomingInterviewComponent = () => {
    const Chip = ({ text }) => {
      return <div className="bg-[#D9F4FE] rounded-lg px-2 py-1">{text}</div>;
    };
    return (
      <div className="flex justify-between my-4">
        <div>
          <p className="">Karuna Varma</p>
          <div className="flex gap-x-8 text-[14px] text-[#979797] mt-2">
            <div className="flex items-center gap-x-1">
              <BsCalendar />
              <span>Apr 16, 2025</span>
            </div>
            <div className="flex items-center gap-x-1">
              <BsClock />
              <span>010:00 AM - 30:00 AM</span>
            </div>
          </div>
          <div className="flex flex-wrap gap-x-4 text-xs mt-2">
            <Chip text={"Vue Js"} />

            <Chip text={"React Js"} />
            <Chip text={"Node Js"} />
          </div>
        </div>
        <div className="flex items-center space-x-4 text-end">
          <StatusChip />
          <Button>Meet link</Button>
          <button className="text-customblue border-[1.2px] border-customblue px-2 py-1 h-[40px] rounded-lg">
            Reschedule
          </button>
        </div>
      </div>
    );
  };
  return (
    <div>
      {" "}
      <Tabs
        // value={userType}
        defaultValue="Upcoming"
        onValueChange={(value) => {
          // console.log("otmode", otpMode);
          // if (!otpMode) setuserType(value); // prevent switch in OTP mode
        }}
      >
        <TabsList className="w-fit gap-x-6 h-[40px]">
          <TabsTrigger value="Upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="Completed">Completed</TabsTrigger>
          <TabsTrigger value="Rescheduled">Rescheduled</TabsTrigger>
          <TabsTrigger value="Cancelled">Cancelled</TabsTrigger>
        </TabsList>
        <TabsContent value="Upcoming">
          <div>
            <UpcomingInterviewComponent />
            <Separator />
            <UpcomingInterviewComponent />
          </div>
        </TabsContent>
        <TabsContent value="Completed">
          <div>Tab2 </div>
        </TabsContent>
        <TabsContent value="Rescheduled">
          <div>Tab3 </div>
        </TabsContent>
        <TabsContent value="Cancelled">
          <div>Tab4 </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Dashboard;
