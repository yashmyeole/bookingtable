"use client" // Enables client-side rendering in Next.js app directory

import React, { useState, useRef, useEffect } from 'react'
import useravatar from '/public/icons/profile_avatar.png'
import Image from 'next/image'
import { useAtom } from 'jotai';

// Custom input components
import { InputComponent } from '@/components/main/InputComponent'
import { ExperienceInput } from '@/components/auth/signup/ExperienceInput'

// React Hook Form for handling form state and validation
import { useForm } from "react-hook-form";
import { profileAtom } from './formAtoms'
import { useGetUserProfile } from '@/hooks/userHooks';

const ProfileInput = ({ image, setImage, handleFileChange, previewUrl, setPreviewUrl, onStepSuccess, currentStep, steps, goBack, goNext }) => {
    const { data: profileData, isFetched, isSuccess } = useGetUserProfile();
    // Initialize useForm for managing form inputs and validations
    const [formData, setFormData] = useAtom(profileAtom);
    const {
        register,        // function to register inputs
        handleSubmit,    // handles form submission
        control,         // for advanced use (like controlled components)
        setValue,        // set value programmatically
        getValues,       // get current form values
        formState: { errors }, // contains validation errors
        watch,           // watch specific input values
    } = useForm(profileData || {});

    // useEffect(() => {
    //     //setSkills(profileData?.data?.result?.skills?.split("||") || []);
    //     setValue("firstName", profileData?.data?.result?.firstName);
    //     setValue("lastName", profileData?.data?.result?.lastName);
    //     setValue("mobileNumber", profileData?.data?.result?.phone);
    //     setValue("email", profileData?.data?.result?.email);
    //     setValue("goal", profileData?.data?.result?.goal); 
    //     setValue("expInYear", profileData?.data?.result?.experienceInYears);
    //     setValue("expInMonth", profileData?.data?.result?.experienceInMonths);
    //     setValue("domain", profileData?.data?.result?.domain);
    //     setValue("education", profileData?.data?.result?.education);
    //     setValue("company", profileData?.data?.result?.company);
    //     setValue("jobTitle", profileData?.data?.result?.designation);
    //     // console.log(profileData?.data?.result);
    //   }, [profileData]);
    // Ref to trigger the hidden file input when image is clicked
    const fileInputRef = useRef(null);
    //const [previewUrl, setPreviewUrl] = useState(null)
    
//    const handleFileChange = (e) => {
//     const file = e.target.files[0];
//     if (file) {
//       setImage(file); // ✅ set File in parent
//       setPreviewUrl(URL.createObjectURL(file));
//     }
//   };
console.log(formData.profilePic)
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
    };
//     const previewUrl =
//   formData.profilePic instanceof File
//     ? URL.createObjectURL(file)
//     : null;


    function submitData(data) {
        onStepSuccess(data.profilePic);
    }

    return (
        <form className='text-[#666666]' onSubmit={handleSubmit(submitData)}>
            <div className='bg-white border border-[#E0E0E0] rounded-xl shadow px-8 py-8 max-w-[736px] mx-auto'>
                {/* Avatar Upload Section */}
                <div className="flex justify-center">
                    <div
                        onClick={() => fileInputRef.current?.click()}
                        className="pb-6 cursor-pointer w-fit"
                    >
                        {previewUrl ? (
                            // Show preview or default avatar
                            <Image
                                alt="ProfilePic"
                                src={previewUrl}
                                width={100}
                                height={100}
                                className="hover:opacity-80 transition"
                            />
                        ) : (
                            // Placeholder if no avatar
                            <Image
                                alt="Avatar"
                                src={useravatar}
                                width={100}
                                height={100}
                                className="hover:opacity-80 transition"
                            />
                        )}

                        {/* Hidden file input for avatar */}
                        <input
                            type="file"
                            name='profilePic'
                            accept="image/*"
                            ref={fileInputRef}
                            onChange={handleFileChange}
                            className="hidden"
                            //{...register('profilePic', { required: true })}
                        />
                    </div>
                </div>


                {/* Form Fields Section */}
                <div className='space-y-8'>

                    {/* First Name & Last Name */}
                    <div className='grid grid-cols-2 gap-x-10'>
                        <InputComponent
                            label='First name'
                            name='firstName'
                            value={profileData?.data?.result?.firstName}
                            register={register}
                            width='min-w-[50%]'
                            onChange={handleChange}
                            //rules={{ required: 'First name is required' }}
                            errors={errors}
                        />
                        <InputComponent
                            label='Last name'
                            name='lastName'
                            value={profileData?.data?.result?.lastName}
                            register={register}
                            onChange={handleChange}
                            width='min-w-[50%]'
                            //rules={{ required: "Last name is required" }}
                            errors={errors}
                        />
                    </div>

                    {/* Mobile & Email */}
                    <div className='grid grid-cols-2 gap-x-10'>
                        <InputComponent
                            label='Mobile number'
                            name='mobileNumber'
                            value={profileData?.data?.result?.phone}
                            register={register}
                            onChange={handleChange}
                            width='min-w-[50%]'
                            //rules={{ required: "Mobile number is required" }}
                            errors={errors}
                        />
                        <InputComponent
                            label='Email ID'
                            name='email'
                            //type='email'
                            register={register}
                            value={profileData?.data?.result?.email}
                            onChange={handleChange}
                            width='min-w-[50%]'
                            // rules={{
                            //     required: "Email ID is required",
                            //     pattern: {
                            //         value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                            //         message: "Enter a valid email address",
                            //     },
                            // }}
                             errors={errors}
                        />
                    </div>

                    {/* Education & Company */}
                    <div className='grid grid-cols-2 gap-x-10'>
                        <InputComponent
                            label='Education'
                            name='education'
                            register={register}
                            width='min-w-[50%]'
                            value={profileData?.data?.result?.education}
                            onChange={handleChange}
                            //rules={{ required: "Education is required" }}
                             errors={errors}
                        />
                        <InputComponent
                            label='Company'
                            name='company'
                            value={profileData?.data?.result?.company}
                            onChange={handleChange}
                            register={register}
                            width='min-w-[50%]'
                            //rules={{ required: "Company is required" }}
                             errors={errors}
                        />
                    </div>

                    {/* Job Title */}
                    <div className='grid grid-cols-2 gap-x-10'>
                        <InputComponent
                            label='Job Title'
                            value={profileData?.data?.result?.designation}
                            width='min-w-[50%]'
                            register={register}
                            onChange={handleChange}
                            name='jobTitle'
                            //rules={{ required: "Job Title is required" }}
                             errors={errors}
                        />
                        <div className="flex flex-col gap-1 w-full">
                            <label className="text-md pb-1">Experience in years & months*</label>

                            <div className="flex gap-6 w-full">
                                <div className="flex flex-col w-full">
                                    <input
                                        placeholder='Years'
                                        className='border text-base text-[#666666] border-[#E0E0E0] rounded-md px-4 py-3 placeholder:text-[#979797] placeholder:text-sm w-full'
                                        value={profileData?.data?.result?.experienceInYears}
                                        onChange={handleChange}
                                        name='expInYear'

                                    //aria-invalid={!!errorYear}
                                    // {...register(nameYear, rulesYear)}
                                    />
                                    {/* {errorYear && (
            <span className="text-sm text-red-500 mt-1">{errorYear}</span>
          )} */}
                                </div>

                                <div className="flex flex-col w-full">
                                    <input
                                        placeholder='Months'
                                        className='border text-base text-[#666666] border-[#E0E0E0] rounded-md px-4 py-3 placeholder:text-[#979797] placeholder:text-sm w-full'
                                        value={profileData?.data?.result?.experienceInMonths}
                                        onChange={handleChange}
                                        name='expInMonth'

                                    //aria-invalid={!!errorMonth}
                                    // {...register(nameMonth, rulesMonth)}
                                    />
                                    {/* {errorMonth && (
            <span className="text-sm text-red-500 mt-1">{errorMonth}</span>
          )} */}
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div className="flex justify-center gap-4 mt-6">
                <button
                    onClick={goBack}                
                    className={`border border-[#007FAD] ${currentStep === 0 ? "hidden" : ""} rounded-md px-6 py-2 text-sm text-[#007FAD]`}
                >
                    Previous
                </button>
                <button
                    type="submit"  
                    //onClick={goNext}
                    className={`bg-[#007FAD] rounded-md px-6 py-2 text-sm text-white`}
                >
                    {currentStep === steps.length - 1 ? "Submit" : "Next"}
                </button>
            </div>
        </form>
    )
}
//bg-[#007FAD80]
export default ProfileInput;
