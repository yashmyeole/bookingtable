"use client"
import { useFetchBankAccount, useDeleteBankAcount } from '@/hooks/paymentHooks';
import React, { useState } from 'react'

const FetchBank = ({ payout, setPayout, setSave, setBankStatus }) => {
    const { data: bank } = useFetchBankAccount({});
     const { mutate, isLoading, isError, data } = useDeleteBankAcount();
    const userId = bank?.data?.bankDetails[0].userId;
    //const { data: deleteBank, isFetched, isSuccess } = useDeleteBankAcount({"userId": userId});
    if (!bank?.data?.bankDetails) {
        setBankStatus(false);
    }
    const maskAccountNumber = (accountNumber) => {
        if (!accountNumber) return "";
        const visibleDigits = 4;
        return accountNumber.slice(0, visibleDigits) + "XXXX";
    };
    return (
        <div>
            <div className="min-w-full border border-gray-200 mt-5 rounded-md ">
                <table className="w-full text-sm">
                    <thead className="">
                        <tr>
                            {/* {Object.keys(payout)
                                    .filter((key) => key !== 'ifscCode') 
                                    .map((key) => (
                                        <th key={key} className="px-4 py-2 border-b text-left capitalize">
                                            {key}
                                        </th>
                                    ))} */}
                            <th className="px-4 py-2 border-b text-left">Bank Name</th>
                            <th className="px-4 py-2 border-b text-left">Account Name</th>
                            <th className="px-4 py-2 border-b text-left">Account Number</th>
                            <th className="px-4 py-2 border-b text-left">Action</th> {/* New "Action" header */}
                        </tr>
                    </thead>
                    <tbody>

                        {bank?.data?.bankDetails?.map((user, index) => (
                            <tr key={index} className="hover:bg-gray-50">
                                <td className="py-2 px-4 border-b">{user.bankName}</td>
                                <td className="py-2 px-4 border-b">{user.accountHolderName
                                }</td>
                                <td className="py-2 px-4 border-b">{maskAccountNumber(user.accountNumber)}</td>


                                <td className="px-4 py-2 border-b">
                                    <button
                                        type="button"
                                        onClick={() => {
                                            mutate({"userId":userId});
                                            
                                            setPayout({
                                                bankName: '',
                                                accountHolderName: '',
                                                accountNumber: '',
                                                ifscCode: '',
                                            });
                                            setSave(false);
                                            setBankStatus(true);
                                        }}

                                        className="text-red-500 hover:underline"
                                    >
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    )
}

export default FetchBank
