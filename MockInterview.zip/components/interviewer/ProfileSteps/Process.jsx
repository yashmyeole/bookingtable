const Process = ({ steps = ['Profile', 'Experience', 'Payouts'], currentStep }) => {
  return (
    <div className="relative max-w-3xl mx-auto px-4 py-6 flex items-center justify-between">
      {steps.map((step, index) => (
        <div key={step} className="relative flex-1 flex items-center justify-center">
          {/* Connector line (skip last item) */}
          {index < steps.length - 1 && (
            <div className="absolute top-4 left-1/2 w-full h-px bg-gray-300 z-10" />
          )}

          {/* Step Circle */}
          <div className="flex flex-col items-center">
            <div
              className={`w-8 h-8 rounded-full border ${
                index <= currentStep ? 'border-[#0AA823]' : 'border-[#666666]'
              } bg-white flex items-center justify-center`}
            >
              {index === currentStep && (
                <div className="w-2.5 h-2.5 rounded-full bg-[#0AA823]" />
              )}
            </div>

            {/* Step Label */}
            <span
              className={`mt-2 font-semibold text-sm ${
                index <= currentStep ? 'text-[#0AA823]' : 'text-[#666666]'
              }`}
            >
              {step}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Process;
