"use client"
import { InputComponent } from "@/components/main/InputComponent";
import { payoutAtom } from './formAtoms'
import { useAtom } from 'jotai';
import { useSearchParams } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { se } from "date-fns/locale";
import FetchBank from "./FetchBank";
import { useAddBankAccount } from "@/hooks/paymentHooks";


const BankInput = ({ bankTitleCenter, setSubmitProfile, submitProfile, onStepSuccess, currentStep, steps, goBack, goNext, setBankStatus }) => {
    const { mutate, isLoading, isError, data } = useAddBankAccount();
    const [payout, setPayout] = useAtom(payoutAtom);
    const {
            register,        // function to register inputs
            handleSubmit,    // handles form submission
            control,         // for advanced use (like controlled components)
            setValue,        // set value programmatically
            getValues,       // get current form values
            formState: { errors }, // contains validation errors
            watch,           // watch specific input values
    } = useForm(payout || {});

    const tableData = {
        headers: ["Bank Name", "Account Name", "Account Number", "Action"],
        rows: [
            ["HDFC Bank", "Steve Carol", "1234567890", "Delete"],
            // ["ICICI Bank", "Jane Smith", "9876543210", "Delete"],
        ]
    };
    const [bankForm, setBankForm] = useState({
        bankName: '',
        accountHolderName: '',
        accountNumber: '',
        ifscCode: ''
    });
    const handleChange = (e) => {
        const { name, value } = e.target;
        setBankForm((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    const [save, setSave] = useState(false);
    function handleSave() {
        setPayout((prev) => ({
            ...prev, ...bankForm
        }));
        setSave(true)
        setBankStatus(false)
        //setPayout(bankForm);
        setBankForm({
            bankName: '',
            accountHolderName: '',
            accountNumber: '',
            ifscCode: '',
        });

    }
    function handleBankSubmit(data) {
        setPayout((prev) => ({
            ...prev, ...bankForm
        }));
        setSave(true)
        setBankStatus(false)
        //setPayout(bankForm);
        setBankForm({
            bankName: '',
            accountHolderName: '',
            accountNumber: '',
            ifscCode: '',
        });
        mutate(data);
    }

    function handleCreateProfileApi() {
        onStepSuccess();
    }
    return (
        <form className='text-[#666666] w-full space-y-8' onSubmit={handleSubmit(handleBankSubmit)}>
            <div className='bg-white border border-[#E0E0E0] rounded-xl shadow px-8 py-8  mx-auto flex flex-col '>
                <h3 className={`${bankTitleCenter} text-md pb-6`}>Bank Account Details</h3>
                <div className="flex flex-col space-y-8">
                    <div className='flex gap-10'>
                        <InputComponent
                            label='Account name'
                            value={bankForm.accountHolderName}
                            name='accountHolderName'
                            onChange={handleChange}
                            placeholder='Enter account name'
                            register={register}
                            width='w-[50%]'
                            rules={{ required:'Account name is required' }}
                            errors={errors}
                        />

                        <InputComponent
                            label='Bank name'
                            name='bankName'
                            value={bankForm.bankName}
                            placeholder='Enter bank name'
                            register={register}
                            onChange={handleChange}
                            width='w-[50%]'
                            rules={{ required:'Bank name is required' }}
                            errors={errors}
                        />

                    </div>
                    <div className='flex gap-10 pb-3'>
                        <InputComponent
                            label='Account number'
                            value={bankForm.accountNumber}
                            name='accountNumber'
                            onChange={handleChange}
                            placeholder='Enter account number'
                            register={register}
                            width='w-[50%]'
                            rules={{ required: 'Account number is required' }}
                            errors={errors}
                        />
                        <InputComponent
                            label='IFSC code'
                            name='ifscCode'
                            value={bankForm.ifscCode}
                            onChange={handleChange}
                            placeholder='Enter IFSC code'
                            width='w-[50%]'
                            register={register}
                            rules={{ required: 'IFSC code is required' }}
                            errors={errors}
                        />

                    </div>
                    <div className="flex items-center justify-center">
                        <button type="submit" disabled={save}  className={`${save ? "disabled:cursor-not-allowed bg-[#007FAD80]": "bg-[#007FAD] "}  float-right rounded-md px-10 py-2 text-sm text-white mb-3 cursor-pointer`}>Save</button>
                    </div>
                </div>

                    <FetchBank
                        payout={payout}
                        setPayout={setPayout}
                        setSave={setSave}
                        setBankStatus={setBankStatus}
                    />
                
            </div>
            {currentStep && 
                <div className="flex justify-center gap-4 mt-6">
                <button
                    type="button"
                    onClick={goBack}
                    className={`border border-[#007FAD] ${currentStep === 0 ? "hidden" : ""} rounded-md px-6 py-2 text-sm text-[#007FAD]`}
                >
                    Previous
                </button>
                <button
                    type="button"
                    onClick={handleCreateProfileApi}
                    className={`bg-[#007FAD] rounded-md px-6 py-2 text-sm text-white`}
                >
                    {currentStep === steps.length - 1 ? "Submit" : "Next"}
                </button>
            </div>
            
            }
        </form>
    )
}

export default BankInput;