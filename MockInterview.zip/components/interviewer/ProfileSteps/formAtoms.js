// atoms/formAtoms.js
import { atomWithStorage } from 'jotai/utils';
import { atom } from 'jotai';


//Profile State
export const profileForm = atomWithStorage('profiledata', {
  profilePic: null,
  skillCategory: '',
  domain: [],
  skillsUsed: [],
  overview:'',
  linkedinUrl:'',
  bankName: '',
  accountHolderName: '',
  accountNumber: '',
  ifscCode:'',
  resume:""
})

export const createProfileForm = atomWithStorage('profileData', {
  skillCategory: '',
  domain: [],
  skillsUsed: [],
  overview:'',
  linkedinUrl:'',
  bankName: '',
  accountHolderName: '',
  accountNumber: '',
  ifscCode:'',
}) 
//Step 1: Profile
export const profileAtom = atomWithStorage('form-profile', {
  firstName: '',
  lastName: '',
  email: '',
  mobileNumber: '',
  education: '',
  company: '',
  jobTitle: '',
  expInYear:'',
  expInMonth:'',
});

// Step 2: Experience
export const experienceAtom = atomWithStorage('form-experience', {
  skillCategory: '',
  domain: [],
  skillsUsed: [],
  overview:'',
  linkedinUrl:''
});

//Step 3 : Payouts
export const payoutAtom = atomWithStorage('payout', {
  bankName: '',
  accountHolderName: '',
  accountNumber: '',
  ifscCode:''
});

//export const profileForm = atom(null); 