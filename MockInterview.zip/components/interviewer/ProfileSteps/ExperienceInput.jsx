import { InputComponent } from "@/components/main/InputComponent";
import CustomPillInput from "@/components/ui/custompillinput";
import './CustomCss.css';
import { DropDownComponent } from "@/components/main/DropdownComponent";
import { experienceAtom } from './formAtoms'
import { useAtom } from 'jotai';
import { Controller, useForm } from "react-hook-form";
import { useEffect } from "react";
import CustomTextarea from "@/components/ui/custom_textarea";


const ExperienceInput = ({ onStepSuccess, currentStep, steps, goBack, goNext }) => {
    const categoryOptions = [
        { label: "Frontend", value: "frontend" },
        { label: "Backend", value: "backend" },
        { label: "Full-Stack", value: "fullstack" },
    ];
    const [experience, setExperience] = useAtom(experienceAtom);
    const {
            register,        // function to register inputs
            handleSubmit,    // handles form submission
            control,         // for advanced use (like controlled components)
            setValue,        // set value programmatically
            getValues,       // get current form values
            formState: { errors }, // contains validation errors
            watch,           // watch specific input values
        } = useForm(experience || {});
    
    const handleChange = (e) => {
        const { name, value } = e.target;
        setExperience((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    useEffect(() => {
        const subscription = watch((value) => {
            setExperience((prev) => ({
                ...prev,
                ...value, // sync any changed fields
            }));
        });

        return () => subscription.unsubscribe();
    }, [watch]);

    function submitData(data) {
        
        onStepSuccess(data);
    }

    return (
        <form className='text-[#666666] space-y-6 w-full' onSubmit={handleSubmit(submitData)}>
            <div className="bg-white border border-[#E0E0E0] rounded-xl shadow px-8 py-8 w-[736px] mx-auto space-y-4 ">
                <div className='flex gap-8 pb-4'>
                    <DropDownComponent
                        label='Category'
                        name="skillCategory"
                        placeholder="Select your Domain"
                        onChange={handleChange}
                        width='w-[50%] max-w[50%]'
                        value={experience.skillCategory}
                        control={control}
                        register={register}   
                        errors={errors}   
                        options={categoryOptions}
                        rules={{ required: "Skills Category is required" }}
                    />
                    <Controller
                    name="domain"
                    control={control}
                    rules={{ required: "Domain is required" }}
                    render={({ field, fieldState }) => (
                        <CustomPillInput
                            label='Domain'
                            //value={experience.domain}
                            width='w-[50%] max-w[50%]'
                            name='domain'
                            placeholder='Add domain'
                            onBlur={field.onBlur}
                            error={fieldState.error}
                            {...field} // gives value, onChange, onBlur, ref
                        />
                    )}
                />

                </div>
                <Controller
                    name="skillsUsed"
                    control={control}
                    rules={{ required: "Skills are required" }}
                    render={({ field, fieldState }) => (
                        <CustomPillInput
                            label='Skills'
                            name='skillsUsed'
                            // onChange={(updatedSkills) =>
                            //     setExperience((prev) => ({ ...prev, skillsUsed: updatedSkills }))
                            // }
                            // value={experience.skillsUsed}
                            placeholder='Add your skills'
                            span='Share your expertise to guide and support potential candidates.'
                            error={fieldState.error}
                            {...field} // gives value, onChange, onBlur, ref
                        />
                    )}
                />

                <Controller
                    name="overview"
                    control={control}
                    rules={{ required: "Bio is required" }}
                    render={({ field }) => (
                        <CustomTextarea
                            label="Bio"
                            name="overview"
                            placeholder="Add your bio"
                            span='Tell us about yourself, your job profile, work experience, skills, and achievements.'
                            {...field} // passes value, onChange, onBlur, ref
                        />
                    )}
                />

                
                <InputComponent
                    label='LinkedIn URL'
                    name='linkedinUrl'
                    placeholder='Add LinkedIn url'
                    value={experience.linkedinUrl}
                    onChange={handleChange}
                    register={register}   
                    errors={errors}  
                    rules={{ required: 'Linkedin Url is required' }}
                />
            </div>
            <div className="flex justify-center gap-4 mt-6">
                <button
                    onClick={goBack}                
                    className={`border border-[#007FAD] ${currentStep === 0 ? "hidden" : ""} rounded-md px-6 py-2 text-sm text-[#007FAD]`}
                >
                    Previous
                </button>
                <button
                    type="submit"  
                    //onClick={goNext}
                    className={`bg-[#007FAD] rounded-md px-6 py-2 text-sm text-white`}
                >
                    {currentStep === steps.length - 1 ? "Submit" : "Next"}
                </button>
            </div>
        </form>
    )
}

export default ExperienceInput;