"use client";

import { useParams, useRouter } from "next/navigation";
import { useState } from "react";
import { Separator } from "../ui/separator";
import { CustomDropDown } from "../auth/signup/CustomDropDown";
import { useForm, Controller } from "react-hook-form";

export default function FeedbackDetails() {
  const router = useRouter();
  const { slug } = useParams();

  const {
    register,
    handleSubmit,
    control,
    watch,
    setValue,
    formState: { errors },
  } = useForm({
    defaultValues: {
      name: "Shangeeth Nandwana",
      email: "shangeeth.nandwana@gmail.com",
      experience: "2 years",
      date: "28 Feb 2025",
      strengths: "",
      improvements: "",
      skills: [
        { name: "JavaScript", rating: 0 },
        { name: "HTML", rating: 0 },
        { name: "CSS", rating: 0 },
      ],
      overallRating: null,
    },
  });

  const onSubmit = (data) => {
    console.log("Feedback Submitted:", data);
  };

  const onSaveDraft = (data) => {
    console.log("Draft Saved:", data);
  };

  const skills = watch("skills");

  const handleRatingChange = (index, rating) => {
    const updated = [...skills];
    updated[index].rating = rating;
    setValue("skills", updated);
  };

  return (
    <form
      className="flex flex-col w-full rounded-lg"
      onSubmit={handleSubmit(onSubmit)}
    >
      <button
        className="flex text-sm text-blue-500 mb-4 hover:underline cursor-pointer"
        onClick={() => router.push("./")}
        type="button"
      >
        {"< Back"}
      </button>

      {/* Candidate Info */}
      <div className="flex items-center gap-4 mb-12 bg-[#F9FAFB] rounded-lg p-4">
        <div className="w-16 h-16 rounded-full bg-gray-200 overflow-hidden" />
        <div className="flex-grow">
          <div className="mb-2">
            <input
              {...register("name", { required: true })}
              className="text-xl font-semibold bg-transparent outline-none w-full"
              placeholder="Candidate Name"
            />
            <input
              {...register("email", { required: true })}
              className="text-gray-500 text-sm bg-transparent outline-none w-full mt-1"
              placeholder="Email"
              type="email"
            />
          </div>
          <div className="flex mt-4 text-sm text-gray-600 gap-x-12">
            <div>
              <p>Skills to be assessed:</p>
              <p>JavaScript, HTML, CSS</p>
            </div>
            <div>
              <p>Experience:</p>
              <input
                {...register("experience")}
                className="bg-transparent outline-none"
              />
            </div>
            <div>
              <p>Interview date:</p>
              <input
                {...register("date")}
                className="bg-transparent outline-none"
              />
            </div>
          </div>
        </div>
        <div className="ml-auto">
          <span className="bg-green-100 text-green-800 px-3 py-1 text-sm rounded-full">
            Interviewed
          </span>
        </div>
      </div>

      {/* Skills Rating */}
      <h3 className="text-lg font-semibold mb-2">
        Technical Skills Assessment
      </h3>
      <div className="bg-[#F9FAFB] space-y-4 rounded-lg p-4">
        {skills.map((skill, index) => (
          <div key={skill.name}>
            <div className="flex items-center justify-between">
              <span className="w-24 font-medium">{skill.name}</span>
              <div className="flex gap-y-2 gap-x-6">
                {[1, 2, 3, 4, 5].map((num) => (
                  <button
                    type="button"
                    key={num}
                    className={`w-8 h-8 flex items-center justify-center rounded-full border transition ${
                      num === skill.rating
                        ? "text-white bg-[#007FAD]"
                        : "bg-white text-gray-500 border-[1px] border-[#007FAD]"
                    }`}
                    onClick={() => handleRatingChange(index, num)}
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>
            {index !== skills.length - 1 && (
              <div className="mt-3">
                <Separator />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Strengths */}
      <div className="mt-12">
        <h4 className="font-semibold text-gray-800 mb-1">Strengths</h4>
        <textarea
          {...register("strengths")}
          className="w-full bg-[#F9FAFB] text-sm text-gray-700 p-3 rounded-lg border border-gray-300 placeholder:text-gray-400"
          rows={4}
          placeholder="Write strengths observed during the interview..."
        />
      </div>

      {/* Improvements */}
      <div className="mt-12">
        <h4 className="font-semibold text-gray-800 mb-1">
          Areas for Improvement
        </h4>
        <textarea
          {...register("improvements")}
          className="w-full bg-[#F9FAFB] text-sm text-gray-700 p-3 rounded-lg border border-gray-300 placeholder:text-gray-400"
          rows={4}
          placeholder="Write areas where the candidate can improve..."
        />
      </div>

      {/* Overall Rating Dropdown */}
      <div className="mt-8">
        <CustomDropDown
          label="Overall Rating"
          name={"rating"}
          placeholder="Select a rating"
          options={[
            { label: "1 - Poor", id: 1 },
            { label: "2 - Fair", id: 2 },
            { label: "3 - Good", id: 3 },
            { label: "4 - Very Good", id: 4 },
            { label: "5 - Excellent", id: 5 },
          ]}
          register={register}
          control={control}
          errors={errors}
          rules={{ required: "State is required" }}
        />
      </div>

      {/* Buttons */}
      <div className="flex gap-x-12 mt-12 text-center">
        <button
          type="button"
          onClick={handleSubmit(onSaveDraft)}
          className="text-customblue px-6 py-2 rounded-md text-sm bg-white border-[1px] border-customblue cursor-pointer"
        >
          Save as Draft
        </button>
        <button
          type="submit"
          className="bg-customblue text-white px-6 py-2 rounded-md text-sm cursor-pointer"
        >
          Submit Feedback
        </button>
      </div>
    </form>
  );
}
