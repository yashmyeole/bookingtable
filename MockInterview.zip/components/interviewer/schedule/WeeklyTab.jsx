"use client";
import { Button } from "@/components/ui/button";
import { format, addDays, isSameDay, startOfDay } from "date-fns";
import React, { useState } from "react";
import { GrFormNext, GrFormPrevious } from "react-icons/gr";
import ScheduledInterviewsByDay from "./ScheduledInterviewsByDay";
import WeeklyDatePicker from "./WeeklyDatePicker";

const WeeklyTab = () => {
  const today = startOfDay(new Date()); // ensures time doesn't affect comparisons
  const [startDate, setStartDate] = useState(today);

  const endDate = addDays(startDate, 6); // 7-day range
  const isAtCurrentWeek = isSameDay(startDate, today); // for disabling "Previous"

  const goToNextWeek = () => {
    setStartDate((prev) => addDays(prev, 7));
  };

  const goToPreviousWeek = () => {
    if (!isAtCurrentWeek) {
      setStartDate((prev) => addDays(prev, -7));
    }
  };

  return (
    <div className="flex flex-col space-y-4 w-full">
      {/* Month and year */}
      <h2 className="text-lg font-semibold">
        {format(startDate, "MMMM yyyy")}
      </h2>

      {/* Week picker */}
      <WeeklyDatePicker
        startDate={startDate}
        setStartDate={setStartDate}
        today={today}
      />

      {/* Week range and buttons */}
      <div className="flex justify-between items-center">
        <h1 className="text-lg font-semibold">
          Week of {format(startDate, "MMM d")} -{" "}
          {format(endDate, "MMM d, yyyy")}
        </h1>
        <div className="flex space-x-2">
          <Button
            variant={"ghost"}
            className="w-7 h-7"
            onClick={goToPreviousWeek}
            disabled={isAtCurrentWeek}
          >
            <GrFormPrevious />
          </Button>
          <Button variant={"ghost"} className="w-7 h-7" onClick={goToNextWeek}>
            <GrFormNext />
          </Button>
        </div>
      </div>

      {/* Weekly scheduled content */}
      <ScheduledInterviewsByDay />
      <ScheduledInterviewsByDay />
    </div>
  );
};

export default WeeklyTab;
