import InterviewInfo from "@/components/candidate/schedule/InterviewCard/InterviewInfo";
import { Button } from "@/components/ui/button";
import StatusChip from "@/components/ui/CustomStatusChip";
import { cn } from "@/lib/utils";
import React from "react";

const InterviewInfoCard = ({ isLast }) => {
  return (
    <div
      className={cn(
        "flex justify-between pb-4",
        !isLast && "border-b border-[#C4C4C4]"
      )}
    >
      <InterviewInfo />
      <div className="flex items-center space-x-6">
        <StatusChip text="Scheduled" />
        <div className="flex items-center space-x-4">
          <Button size="sm">Meet Link</Button>
          <Button variant="outline" size="sm">
            Reschedule
          </Button>
          <Button variant="outline" size="sm">
            View Profile
          </Button>
        </div>
      </div>
    </div>
  );
};

export default InterviewInfoCard;
