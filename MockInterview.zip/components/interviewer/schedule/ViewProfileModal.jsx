import React from "react";
import UserImage from "../../../assets/UserImage.png";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import StatusChip from "@/components/ui/CustomStatusChip";
import { cn } from "@/lib/utils";
const ViewProfileModal = () => {
  return (
    <div className="flex flex-col space-y-2 border p-4 min-w-3xl max-w-3xl rounded-md border-[#C4C4C4]">
      {/* User card */}
      <div className="flex items-center justify-between border-b border-[#C4C4C4] pb-3 space-x-2">
        <div className="flex items-center space-x-3 justify-center">
          <Image
            src={UserImage}
            alt="User Image"
            height={60}
            width={60}
            className="rounded-full"
          />
          <div className="flex flex-col space-y-2">
            <h2 className="text-base font-medium">Shangeeth Nandwana</h2>
            <h3 className="text-base font-normal text-textgrey">
              shangeeth.nandawana@gmail.com
            </h3>
            <h3 className="text-base font-normal text-textgrey">7738792910</h3>
          </div>
        </div>

        <div className="flex items-center justify-center">
          <Button variant="outline" className="cursor-pointer">
            View Resume
          </Button>
        </div>
      </div>
      <div className="flex flex-col  border-b border-[#C4C4C4] pb-3 space-y-2">
        <h1 className="text-base font-bold">About</h1>
        <p className="text-wrap">
          Passionate Frontend Developer with 3 years of hands-on UI/UX design
          experience Skilled in HTML, CSS, JavaScript, Angular, and React.
          Strong focus on clean, responsive design and user experience. Eager to
          contribute and grow in a dynamic development team. ....more
        </p>
      </div>
      <div className="flex flex-col border-b border-[#C4C4C4]  pb-3 space-y-2">
        <h1 className="text-base font-bold">Experience</h1>
        <p className="text-wrap">4 years in Frontend developer.</p>
      </div>
      <div className="flex flex-col   pb-3 space-y-2">
        <h1 className="text-base font-bold">Skills</h1>
        <div className="flex space-x-3">
          <Chip text="Design" />
          <Chip text="Brand Strategy" />
          <Chip text="UI/UX" />
          <Chip text="+4more" />
        </div>
      </div>
    </div>
  );
};

const Chip = ({ text }) => {
  return (
    <span
      className={cn(
        "flex   rounded-xs h-[20x] px-1 py-0.5 text-sm font-medium justify-center items-center",
        "bg-[#D9F4FE]",
        "text-customblue"
      )}
    >
      {text}
    </span>
  );
};
export default ViewProfileModal;
