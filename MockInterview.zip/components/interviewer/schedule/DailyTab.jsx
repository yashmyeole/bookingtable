import { format } from "date-fns";
import React from "react";
import ScheduledInterviewsByDay from "./ScheduledInterviewsByDay";

const DailyTab = () => {
  const today = new Date();
  const month = format(today, "MMMM"); // Full month name like "June"
  const year = format(today, "yyyy"); // Full year like "2025"
  return (
    <div className="flex flex-col space-y-2 w-full">
      {/* Display Month and year */}
      <h2 className="text-lg font-semibold">
        {month} {year}
      </h2>
      {/* Display Interview by dat */}
      <ScheduledInterviewsByDay />
    </div>
  );
};

export default DailyTab;
