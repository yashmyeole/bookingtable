import React, { useState, useEffect, useMemo } from "react";
import { GrFormNext, GrFormPrevious } from "react-icons/gr";
import {
  format,
  addMonths,
  subMonths,
  isSameMonth,
  isAfter,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  getDay,
  subDays,
  addDays,
} from "date-fns";
import { cn } from "@/lib/utils";
const inter = [
  { date: subDays(new Date(), 6), title: "Post video" },
  { date: subDays(new Date(), 6), title: "Post video2" },
  { date: subDays(new Date(), 6), title: "Post video 2" },
  { date: subDays(new Date(), 1), title: "Edit video" },
  { date: addDays(new Date(), 3), title: "Code" },
];
const MonthlyCalender = ({
  currentMonth,
  setCurrentMonth,
  today,
  maxMonth,
}) => {
  const goToPreviousMonth = () => {
    const newMonth = subMonths(currentMonth, 1);
    if (!isSameMonth(newMonth, today) && isAfter(today, newMonth)) return;
    setCurrentMonth(newMonth);
  };

  const goToNextMonth = () => {
    const newMonth = addMonths(currentMonth, 1);
    if (isAfter(newMonth, maxMonth)) return;
    setCurrentMonth(newMonth);
  };

  const isAtCurrentMonth = isSameMonth(currentMonth, today);
  const isAtMaxMonth = isSameMonth(currentMonth, maxMonth);

  return (
    <div className="flex flex-col  max-w-3xl rounded-sm">
      {/* Title and month selector */}
      <div className="flex px-2 py-2 bg-customblue border border-[#C4C4C4] rounded-t-sm justify-between items-center">
        <h2 className="text-lg text-white">Interview Calendar</h2>
        <div className="flex items-center gap-3">
          <button
            onClick={goToPreviousMonth}
            disabled={isAtCurrentMonth}
            className={`w-7 h-7 flex items-center justify-center ${
              isAtCurrentMonth
                ? "opacity-30 cursor-not-allowed"
                : "hover:opacity-80 cursor-pointer"
            }`}
          >
            <GrFormPrevious className="text-white" />
          </button>

          <p className="text-white text-base font-medium">
            {format(currentMonth, "MMMM yyyy")}
          </p>

          <button
            onClick={goToNextMonth}
            disabled={isAtMaxMonth}
            className={`w-7 h-7 flex items-center justify-center ${
              isAtMaxMonth
                ? "opacity-30 cursor-not-allowed"
                : "hover:opacity-80 cursor-pointer"
            }`}
          >
            <GrFormNext className="text-white" />
          </button>
        </div>
      </div>
      {/* Calender */}
      <EventCalendar interviews={inter} currentMonth={currentMonth} />
    </div>
  );
};

const EventCalendar = ({ interviews, currentMonth }) => {
  const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const firstDayOfMonth = startOfMonth(currentMonth);
  const lastDayOfMonth = endOfMonth(currentMonth);
  const daysInMonth = eachDayOfInterval({
    start: firstDayOfMonth,
    end: lastDayOfMonth,
  });
  const startingDayIndex = getDay(firstDayOfMonth);
  const totalCells = startingDayIndex + daysInMonth.length;
  const trailingEmptyDays = (7 - (totalCells % 7)) % 7;
  const eventsByDate = useMemo(() => {
    return interviews.reduce((acc, event) => {
      const dateKey = format(event.date, "yyyy-MM-dd");
      if (!acc[dateKey]) {
        acc[dateKey] = [];
      }
      acc[dateKey].push(event);
      return acc;
    }, {});
  }, [interviews]);
  return (
    <div className="grid grid-cols-7 border-r border-[#C4C4C4] ">
      {WEEKDAYS.map((day, index) => {
        return (
          <div
            key={day}
            className={cn(
              "text-base border-b  border-[#C4C4C4] font-normal text-center",
              index === 0 && "border-l border-[#C4C4C4]"
            )}
          >
            {day}
          </div>
        );
      })}

      {Array.from({ length: startingDayIndex }).map((_, index) => {
        return (
          <div
            key={`empty-${index}`}
            className="flex flex-col h-[75px] border-l px-1 border-b border-[#C4C4C4]"
          />
        );
      })}
      {daysInMonth.map((day, index) => {
        const dateKey = format(day, "yyyy-MM-dd");
        const todaysEvents = eventsByDate[dateKey] || [];
        return (
          <div
            key={index}
            className={cn(
              "flex flex-col h-auto min-h-[75px] border-l px-1 border-b border-[#C4C4C4] text-sm",
              todaysEvents.length > 0 && "bg-customblue-light" // light green
            )}
          >
            {/* Top row: day and event count */}
            <div className="flex justify-between items-center">
              <span className="font-medium">{format(day, "d")}</span>
              {todaysEvents.length > 0 && (
                <span className="bg-customblue text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                  {todaysEvents.length}
                </span>
              )}
            </div>

            {/* Events list */}
            <div className="mt-1 flex flex-col gap-1 overflow-hidden">
              {todaysEvents.slice(0, 2).map((event) => (
                <div
                  key={event.title}
                  className="bg-white text-xs text-black rounded-sm p-1 border border-customblue truncate"
                  title={event.title}
                >
                  {event.title}
                </div>
              ))}
              {todaysEvents.length > 2 && (
                <span className="text-[10px] text-green-800 font-medium">
                  +{todaysEvents.length - 2} more
                </span>
              )}
            </div>
          </div>
        );
      })}
      {/* Trailing empty cells */}
      {Array.from({ length: trailingEmptyDays }).map((_, index) => (
        <div
          key={`empty-end-${index}`}
          className="flex flex-col h-[75px] border-l px-1 border-b border-[#C4C4C4]"
        />
      ))}
    </div>
  );
};

export default MonthlyCalender;
