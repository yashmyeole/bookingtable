import { CustomDropDown } from "@/components/auth/signup/CustomDropDown";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  openCandidateRescheduleModalAtom,
  openInterviewResceduleModalAtom,
} from "@/store/modalOpenAtoms";
import {
  rescheduleReasonAtom,
  rescheduleSlotDataAtom,
} from "@/store/rescheduleAtom";
import { useAtom } from "jotai";
import React from "react";
import { useForm } from "react-hook-form";

const InterviewrRescheduleModal = ({ useCase = "interviewer" }) => {
  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
    watch,
  } = useForm();
  const selectedReason = watch("reason");
  const [rescheduleReason, setRescheduleReason] = useAtom(rescheduleReasonAtom);
  const [openrescheduleReasonModal, setrescheduleReasonModal] = useAtom(
    openInterviewResceduleModalAtom
  );
  const [openCandidateRescheduleModal, setCandidateRescheduleModal] = useAtom(
    openCandidateRescheduleModalAtom
  );
  const [rescheduleSlotData, setopenrescheduleSlotData] = useAtom(
    rescheduleSlotDataAtom
  );

  const handleRescheduleReason = (data) => {
    console.log("Data", data);
    //Set reschedule reason to atom atate
    setRescheduleReason(data.reason);
    //Close this current pop up
    setrescheduleReasonModal(false);
    //Open slot selection pop up
    setCandidateRescheduleModal(true);
  };
  return (
    <form
      onSubmit={handleSubmit(handleRescheduleReason)}
      className="flex flex-col space-y-6 p-4"
    >
      <h1 className="text-[22px] font-medium text-center">
        Confirm Reschedule interview
      </h1>
      <p className="text-base text-textgrey text-center ">
        {`Are you sure you want to reschedule interview with`} <br />
        {`${rescheduleSlotData.userName}?`}
      </p>
      <div className="flex flex-col space-y-2">
        <p className="text-center text-base text-textgrey ">
          Reason for rescheduling
        </p>
        <CustomDropDown
          name="reason"
          placeholder="Select reason"
          register={register}
          control={control}
          errors={errors}
          options={cancelInterviewReasons}
          rules={{ required: "State is required" }}
          classNameTrigger="shadow-lg"
        />
      </div>
      <p className="text-center text-base text-textgrey">
        {useCase === "interviewer"
          ? "The candidate will be notified of this change via email."
          : "The interviewer will be notified of this change via email."}
      </p>
      <div className="flex items-center justify-center space-x-3">
        <Button variant="outline">Cancel</Button>
        <Button type="submit" disabled={!selectedReason}>
          Confirm Reschedule
        </Button>
      </div>
    </form>
  );
};
const cancelInterviewReasons = [
  { label: "Personal Reason", value: "personal_reason" },
  { label: "Medical Emergency", value: "medical_emergency" },
  { label: "Unexpected Travel", value: "unexpected_travel" },
  { label: "Family Obligation", value: "family_obligation" },
  { label: "Scheduling Conflict", value: "scheduling_conflict" },
  { label: "Not Interested Anymore", value: "not_interested" },
];
export default InterviewrRescheduleModal;
