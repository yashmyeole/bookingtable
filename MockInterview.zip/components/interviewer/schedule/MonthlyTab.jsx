import React, { useState } from "react";
import MonthlyCalender from "./MonthlyCalender";
import ScheduledInterviewsByDay from "./ScheduledInterviewsByDay";
import { addMonths } from "date-fns";

const MonthlyTab = () => {
  const [showDayWiseInterview, setshowDayWiseInterview] = useState(false);
  const today = new Date();
  const [currentMonth, setCurrentMonth] = useState(today);
  const maxMonth = addMonths(today, 2);
  return (
    <div className="flex flex-col space-y-4">
      <MonthlyCalender
        currentMonth={currentMonth}
        setCurrentMonth={setCurrentMonth}
        today={today}
        maxMonth={maxMonth}
      />

      {showDayWiseInterview && <ScheduledInterviewsByDay />}
    </div>
  );
};

export default MonthlyTab;
