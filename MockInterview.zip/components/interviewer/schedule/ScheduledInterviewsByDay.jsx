import InterviewInfo from "@/components/candidate/schedule/InterviewCard/InterviewInfo";
import { Button } from "@/components/ui/button";
import StatusChip from "@/components/ui/CustomStatusChip";
import { cn } from "@/lib/utils";
import { Separator } from "@radix-ui/react-select";
import React from "react";
import InterviewInfoCard from "./InterviewInfoCard";

const ScheduledInterviewsByDay = () => {
  return (
    <div className="flex flex-col w-full space-y-2 border border-[#C4C4C4] rounded-sm">
      {/* Date and interview count */}
      <div className="flex items-center space-x-3 border-b rounded-t-sm border-[#C4C4C4] p-4 bg-[#F5F7FA]">
        {/* Date */}
        <div className="flex flex-col border-r border-[#C4C4C4] pr-5">
          <h1 className="text-3xl text-customblue font-bold">18</h1>
          <h2 className="text-base text-customblue font-medium">Tue</h2>
        </div>
        {/* Interview count */}

        <p className="text-base font-medium">3 Interviews Scheduled</p>
      </div>
      <div className="flex flex-col px-4  space-y-4">
        {Array(3)
          .fill(null)
          .map((_, index) => (
            <InterviewInfoCard
              key={index}
              isLast={index === 2} // last index = 1 for Array(2)
            />
          ))}
      </div>
    </div>
  );
};

// const InterviewInfoCard = ({ isLast }) => {
//   return (
//     <div
//       className={cn(
//         "flex justify-between pb-4",
//         !isLast && "border-b border-[#C4C4C4]"
//       )}
//     >
//       <InterviewInfo />
//       <div className="flex items-center space-x-6">
//         <StatusChip text="Scheduled" />
//         <div className="flex items-center space-x-4">
//           <Button size="sm">Meet Link</Button>
//           <Button variant="outline" size="sm">
//             Reschedule
//           </Button>
//           <Button variant="outline" size="sm">
//             View Profile
//           </Button>
//         </div>
//       </div>
//     </div>
//   );
// };
export default ScheduledInterviewsByDay;
