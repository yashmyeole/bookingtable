"use client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import React, { useState } from "react";
import DailyTab from "./DailyTab";
import WeeklyTab from "./WeeklyTab";
import MonthlyTab from "./MonthlyTab";
import PopupWrapper from "@/components/Wrappers/PopupWrapper";
import {
  openInterviewResceduleModalAtom,
  openViewProfileModalAtom,
} from "@/store/modalOpenAtoms";
import InterviewrRescheduleModal from "./InterviewrRescheduleModal";
import { useAtom } from "jotai";
import ViewProfileModal from "./ViewProfileModal";

const InterviewerScheduleContainer = () => {
  const [timePeriod, settimePeriod] = useState("Daily");
  const [openInterviewResceduleModal, setopenInterviewResceduleModal] = useAtom(
    openInterviewResceduleModalAtom
  );
  const [openViewProfileModal, setopenViewProfileModal] = useAtom(
    openViewProfileModalAtom
  );
  return (
    <>
      <Tabs
        // value={userType}
        defaultValue={timePeriod}
        onValueChange={(value) => {
          // console.log("otmode", otpMode);
          // if (!otpMode) setuserType(value); // prevent switch in OTP mode
          settimePeriod(value);
        }}
        className="w-full"
      >
        <TabsList className="w-sm h-[45px]">
          <TabsTrigger value="Daily">Daily</TabsTrigger>
          <TabsTrigger value="Weekly">Weekly</TabsTrigger>
          <TabsTrigger value="Monthly">Monthly</TabsTrigger>
        </TabsList>
        <TabsContent value="Daily">
          <DailyTab />
        </TabsContent>
        <TabsContent value="Weekly">
          <WeeklyTab />
        </TabsContent>
        <TabsContent value="Monthly">
          <MonthlyTab />
        </TabsContent>
      </Tabs>
      <PopupWrapper
        isOpen={openInterviewResceduleModal}
        isClose={() =>
          setopenInterviewResceduleModal(!openInterviewResceduleModal)
        }
      >
        <InterviewrRescheduleModal />
      </PopupWrapper>
      <PopupWrapper
        isOpen={openViewProfileModal}
        isClose={() => setopenViewProfileModal(!openViewProfileModal)}
      >
        <ViewProfileModal />
      </PopupWrapper>
    </>
  );
};

export default InterviewerScheduleContainer;
