"use client";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format, addDays, isSameDay, isBefore, startOfDay } from "date-fns";
import { ChevronDownIcon } from "lucide-react";
import { GrFormNext, GrFormPrevious } from "react-icons/gr";
import React, { useState } from "react";
import { MdCalendarToday } from "react-icons/md";

const WeeklyDatePicker = ({ startDate, setStartDate, today }) => {
  const [open, setOpen] = useState(false);

  const endDate = addDays(startDate, 6);
  const isAtCurrentWeek = isSameDay(startDate, today);

  const goToPreviousWeek = () => {
    const newStart = addDays(startDate, -7);
    if (!isBefore(newStart, today)) {
      setStartDate(newStart);
    }
  };

  const goToNextWeek = () => {
    setStartDate(addDays(startDate, 7));
  };

  const handleDateSelect = (date) => {
    if (date) {
      const normalized = startOfDay(date);
      setStartDate(normalized); // this will automatically recalculate the range
      setOpen(false);
    }
  };

  return (
    <div className="flex max-w-md items-center space-x-2">
      <Button
        variant="ghost"
        className="w-7 h-7"
        onClick={goToPreviousWeek}
        disabled={isAtCurrentWeek}
      >
        <GrFormPrevious />
      </Button>

      <div className="flex-1">
        <div className="flex-1 flex justify-between border px-2 py-1 border-[#C4C4C4] rounded-sm ">
          <p className="text-sm font-normal">{`${format(
            startDate,
            "MMM d"
          )} – ${format(endDate, "d, yyyy")}`}</p>
          <MdCalendarToday />
        </div>
        {/* <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button
              variant="ghost"
              id="date"
              className="w-full justify-between font-normal"
            >
              {startDate
                ? `${format(startDate, "MMM d")} - ${format(
                    addDays(startDate, 6),
                    "d, yyyy"
                  )}`
                : "Select a date"}
              <ChevronDownIcon />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-full overflow-hidden p-0" align="start">
            <Calendar
              mode="range"
              selected={{
                from: startDate,
                to: endDate,
              }}
              defaultMonth={startDate}
              showOutsideDays={false}
              onSelect={(range) => {
                if (range?.from) handleDateSelect(range.from);
              }}
            />
          </PopoverContent>
        </Popover> */}
      </div>

      <Button variant="ghost" className="w-7 h-7" onClick={goToNextWeek}>
        <GrFormNext />
      </Button>
    </div>
  );
};

export default WeeklyDatePicker;
