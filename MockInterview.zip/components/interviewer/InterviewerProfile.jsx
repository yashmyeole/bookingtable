"use client"
import React from 'react'
import { useState, useRef } from 'react'
import PopupWrapper from '../Wrappers/PopupWrapper'
import ProfileInput from './ProfileSteps/ProfileInput'
import ExperienceInput from './ProfileSteps/ExperienceInput'
import BankInput from './ProfileSteps/BankInput'
import Process from './ProfileSteps/Process'
import Info from '/public/icons/info_icon.png'
import Image from 'next/image'
import { useCreateUserProfile } from '@/hooks/userHooks'
import { useAtom } from 'jotai'
import { createProfileForm } from './ProfileSteps/formAtoms'

const InterviewerProfile = () => {
    const { mutate, isLoading, isError, data } = useCreateUserProfile();
    const steps = ['Profile', 'Experience', 'Payouts'];
    const [image, setImage] = useState(null);
    const [resume, setResume] = useState(null)
    const [currentStep, setCurrentStep] = useState(0);
    const [userData, setUserData] = useAtom(createProfileForm);
    const [submitProfile, setSubmitProfile] = useState(false);
    const [bankStatus, setBankStatus] = useState(true)
    
    const handleCreateProfile = (apiData) => {
        
  const combinedData = {
    ...apiData,           // object from atom/useForm
    profilePic: image,    // File object from state
    resume: image       // File object from state
  };

  const formData = convertProfileToFormData(combinedData);
    mutate(formData); // trigger mutation
    
    };


    const [previewUrl, setPreviewUrl] = useState(null)


    const goNext = () => setCurrentStep((prev) => Math.min(prev + 1, steps.length - 1));
    const goBack = () => setCurrentStep((prev) => Math.max(prev - 1, 0));

    const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(file); // ✅ set File in parent
      setPreviewUrl(URL.createObjectURL(file));
    }
  };
    
    const handleStepSuccess = (stepData) => {
        setUserData((prev) => ({ ...prev, ...stepData })); // merge step data
        if(currentStep === 2) {
            console.log("API CALL!!")
            handleCreateProfile(userData);
            console.log(userData)
        }
        else {
            goNext(); // go to next step only after saving
        }
    };

    return (
        <div>
            <Process steps={steps} currentStep={currentStep} />

            {currentStep === 2 &&
                <div className='w-[736px] my-8 bg-sky-300/20 flex rounded-sm gap-2 p-2 text-center'>
                    <Image src={Info} width={24} height={10} alt='info-icon' />
                    <span className='text-balance text-sm'>Add your bank account, UPI ID, or phone number to receive earnings directly. This step is optional now but required before payouts. Your details are securely stored and required only for payout purposes.</span>
                </div>}

            <div className="">
                {currentStep === 0 && 
                    <ProfileInput 
                        onStepSuccess={handleStepSuccess} 
                        currentStep={currentStep} 
                        previewUrl={previewUrl}
                        handleFileChange={handleFileChange}
                        steps={steps} 
                        goBack={goBack} 
                        goNext={goNext}
                        image={image}
                        setImage={setImage}
                    />
                }

                {currentStep === 1 && 
                    <ExperienceInput 
                        onStepSuccess={handleStepSuccess} 
                        currentStep={currentStep} 
                        steps={steps} 
                        goBack={goBack} 
                        goNext={goNext}
                    />
                }

                {currentStep === 2 &&
                    <BankInput
                        bankTitleCenter='text-center'
                        submitProfile={submitProfile}
                        setSubmitProfile={setSubmitProfile}
                        onStepSuccess={handleStepSuccess} 
                        setBankStatus={setBankStatus}
                        currentStep={currentStep} 
                        steps={steps} 
                        goBack={goBack} 
                        goNext={goNext}
                    />
                }
            </div>

            {/* <div className="flex justify-center gap-4 mt-6">
                <button
                    onClick={goBack}

                    className={`bg-[#007FAD80] ${currentStep === 0 ? "hidden" : ""} rounded-md px-6 py-2 text-sm text-white`}
                >
                    Previous
                </button>
                <button
                    onClick={goNext}
                    className={`bg-[#007FAD80] rounded-md px-6 py-2 text-sm text-white`}
                >
                    {currentStep === steps.length - 1 ? "Submit" : "Next"}
                </button>
            </div> */}

        </div>
    )



}

const convertProfileToFormData = (profileData) => {
  const formData = new FormData();

  Object.entries(profileData).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      // ✅ Convert array to comma-separated string
      formData.append(key, value.join(","));
    } else if (value instanceof File) {
      formData.append(key, value); // for files
    } else {
      formData.append(key, value ?? '');
    }
  });

  return formData;
};


export default InterviewerProfile;
