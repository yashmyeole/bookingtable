import React from "react";
import { BsCalendar, BsClock } from "react-icons/bs";
import InterviewInfoCard from "./schedule/InterviewInfoCard";
import FeedBackTable from "./feedback/FeedBackTable";
import Link from "next/link";

const Dashboard = () => {
  return (
    <div className="flex flex-col space-y-8">
      <div className="grid grid-cols-4 gap-x-6">
        <DashboardStatsComponent title="Upcoming Interviews" />
        <DashboardStatsComponent title="Completed Interviews" />
        <DashboardStatsComponent title="Awaiting Feedback" />
        <DashboardStatsComponent title="Total Spent" />
      </div>
      <div className="flex flex-col space-y-4">
        <div className="flex justify-between">
          <p className="text-lg">Interviews</p>
          <Link
            href="/interviewer/schedules"
            className="text-customblue cursor-pointer border-[1px] border-customblue px-2 py-1 rounded-sm text-sm"
          >
            View all
          </Link>
        </div>
        <div className="border-[1.2px] border-gray-200 rounded-lg p-4">
          <div className="flex flex-col px-4  space-y-4">
            {Array(2)
              .fill(null)
              .map((_, index) => (
                <InterviewInfoCard
                  key={index}
                  isLast={index === 1} // last index = 1 for Array(2)
                />
              ))}
          </div>
          <div></div>
        </div>
      </div>
      <div className="flex flex-col space-y-4">
        <div className="flex justify-between">
          <p className="text-lg">Recent Feedback</p>
          <Link
            href="/interviewer/feedback"
            className="text-customblue cursor-pointer border-[1px] border-customblue px-2 py-1 rounded-sm text-sm"
          >
            View all
          </Link>
        </div>

        <div className="flex w-full border border-[#C4C4C4] rounded-lg overflow-hidden">
          <FeedBackTable />
        </div>
      </div>
    </div>
  );
};

const DashboardStatsComponent = ({ logo, number = 4, title = "title" }) => {
  return (
    <div className="flex items-center gap-x-3 border-[1.2px] border-gray-200 rounded-lg p-[16px]">
      <div className="flex justify-center items-center bg-[#D7F4FF] rounded-sm h-[55px] w-[55px]">
        {logo}
      </div>
      <div>
        <p className="text-customblue text-[24px] font-semibold">{number}</p>
        <p className="text-[#070707] text-[14px] ">{title}</p>
      </div>
    </div>
  );
};

const FeedbackDataComponent = ({}) => {
  const FeedbackChip = ({ text }) => {
    return <div className="bg-[#D9F4FE] rounded-lg px-2 py-1">{text}</div>;
  };
  return (
    <div className="flex justify-between">
      <div>
        <p className="">Karuna Varma</p>
        <div className="flex gap-x-8 text-[14px] text-[#979797] mt-2">
          <div className="flex items-center gap-x-1">
            <BsCalendar />
            <span>Apr 16, 2025</span>
          </div>
          <div className="flex items-center gap-x-1">
            <BsClock />
            <span>010:00 AM - 30:00 AM</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-x-4 text-xs mt-2">
          <FeedbackChip text={"Vue Js"} />
          <FeedbackChip text={"React Js"} />
          <FeedbackChip text={"Node Js"} />
        </div>
      </div>
      <div className="flex flex-col justify-between space-y-2 text-end">
        <p>4/5</p>
        <button className="text-customblue border-[1.2px] border-customblue px-2 py-1 rounded-lg">
          View Feedback
        </button>
      </div>
    </div>
  );
};

export default Dashboard;
