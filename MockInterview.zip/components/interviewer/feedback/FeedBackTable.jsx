import StatusChip from "@/components/ui/CustomStatusChip";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { da } from "date-fns/locale";
import React from "react";

const FeedBackTable = ({ interviews }) => {
  return (
    <Table className="w-full">
      <TableHeader>
        <TableRow className="bg-[#F1F5F9]">
          <TableHead className="text-base font-semibold px-6 py-4">
            Candidates
          </TableHead>
          <TableHead className="text-base font-semibold px-6 py-4">
            Interview Date
          </TableHead>
          <TableHead className="text-base font-semibold px-6 py-4">
            Interview Time
          </TableHead>
          <TableHead className="text-base font-semibold px-6 py-4 ">
            Feedback Status
          </TableHead>
          <TableHead className="text-base font-semibold px-6 py-4">
            Action
          </TableHead>
        </TableRow>
      </TableHeader>
      <TableBody className="bg-white">
        {interviews?.data?.map((item, index) => (
          <CustomRow key={index + 1} data={item} />
        ))}
      </TableBody>
    </Table>
  );
};

const CustomRow = ({ data }) => {
  return (
    <TableRow>
      <TableCell className="font-medium px-6 py-4">
        {data.studentName}
      </TableCell>
      <TableCell className="px-6 py-4">{data.interviewDate}</TableCell>
      <TableCell className="px-6 py-4">{data.startTime}</TableCell>
      <TableCell className="px-6 py-4">
        <StatusChip text={data.feedBackStatus} />
      </TableCell>
      <TableCell className="px-6 py-4">
        {<ActionButtons status={data.feedBackStatus} />}
      </TableCell>
    </TableRow>
  );
};
const ActionButtons = ({ status, handleClick }) => {
  return (
    <div>
      {status === "Pending" && (
        <span onClick={handleClick} className="text-customblue cursor-pointer">
          Evaluate
        </span>
      )}
      {status === "Submitted" && (
        <span onClick={handleClick} className="text-customblue cursor-pointer">
          View
        </span>
      )}
      {status === "Draft" && (
        <span onClick={handleClick} className="text-customblue cursor-pointer">
          Edit
        </span>
      )}
    </div>
  );
};
const sampleData = [
  {
    candidateName: "John Doe",
    interviewDate: "2025-06-20",
    interviewTime: "10:00 AM",
    feedBackStatus: "Pending",
  },
  {
    candidateName: "Alice Smith",
    interviewDate: "2025-06-21",
    interviewTime: "02:30 PM",
    feedBackStatus: "Submitted",
  },
  {
    candidateName: "Michael Brown",
    interviewDate: "2025-06-22",
    interviewTime: "11:15 AM",
    feedBackStatus: "Draft",
  },
];

export default FeedBackTable;
