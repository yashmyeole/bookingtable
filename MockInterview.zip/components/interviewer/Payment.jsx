import React from "react";
import { BsPlus, BsWallet } from "react-icons/bs";
import { Button } from "../ui/button";

const Payment = () => {
  return (
    <div className="w-full space-y-8">
      <div className="bg-[#F9F9F9] rounded-lg p-6 w-full">
        <div>
          <p className="text-lg">Your Wallet</p>
          <p className="text-sm text-textgrey">
            Available balance for booking interviews
          </p>
        </div>
        <div className="flex justify-between mt-4">
          <div className="flex gap-x-6 items-center">
            <div className="flex justify-center items-center not-only:bg-customblue-light w-[60px] h-[60px] rounded-full">
              <BsWallet className="text-customblue" size={30} />
            </div>
            <div>
              <p className="text-lg text-customblue font-semibold">Rs 1400</p>
              <p className="text-sm">Total balance</p>
            </div>
          </div>
          <Button>
            <BsPlus />
            <p>Recharge Wallet</p>
          </Button>
        </div>
      </div>
      <div className="bg-[#F9F9F9] rounded-lg p-6 w-full">
        <div>
          <p className="text-lg">Transactions history</p>
        </div>
        <div className="flex justify-between mt-4 bg-white p-4 rounded-lg">
          Added
        </div>
      </div>
    </div>
  );
};

export default Payment;
