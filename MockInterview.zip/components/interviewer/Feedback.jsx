"use client";
import React, { useState } from "react";
import { BsCalendar, BsClock } from "react-icons/bs";
import { CustomDropDown } from "../auth/signup/CustomDropDown";
import { useForm } from "react-hook-form";
import { Button } from "../ui/button";
import StatusChip from "../ui/CustomStatusChip";
import { Calendar28 } from "../ui/datepicker";
import { Separator } from "../ui/separator";
import { useRouter } from "next/navigation";
import FeedBackTable from "./feedback/FeedBackTable";
import { useGetFeedbacks } from "@/hooks/feedbackHooks";

const Feedback = () => {
  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
    watch,
  } = useForm();

  const [feedbackState, setFeedbackState] = useState({ date: "", status: "" });
  const {
    data: feedbackData,
    refetch,
    isError,
  } = useGetFeedbacks(feedbackState);

  const sampleInterviewerData = {
    status: "Success!",
    statusMessage: "Data fetched successfully!",
    statusCode: 200,
    date: "2024-12-16",
    feedbackStatus: "pending",
    data: [
      {
        scheduleId: 12,
        interviewerName: "Harry Potter",
        studentName: "Hermione Granger",
        skills: ["java", "python"],
        startTime: "09:00:00",
        endTime: "10:00:00",
      },
      {
        scheduleId: 14,
        interviewerName: "Harry Potter",
        studentName: "Hermione Granger",
        skills: ["springboot", "java"],
        startTime: "12:00:00",
        endTime: "13:00:00",
      },
    ],
  };

  const statusOptions = [
    { label: "Completed", value: "completed" },
    { label: "Pending", value: "pending" },
  ];
  return (
    <div className="flex flex-col w-full space-y-4">
      <p className="w-full text-lg font-semibold">Your Interview Feedback</p>
      <div className="flex w-full items-center gap-x-6">
        <span>Filter by</span>
        <Calendar28 />
        <CustomDropDown
          // label="Goal"
          classNameTrigger="h-[40px]"
          name="status"
          placeholder="Status"
          register={register}
          control={control}
          errors={errors}
          options={statusOptions}
          rules={{ required: "Goal is required" }}
        />
        <Button>Apply</Button>
      </div>
      <div className="flex w-full border border-[#C4C4C4] rounded-lg overflow-hidden">
        <FeedBackTable
          interviews={isError ? sampleInterviewerData : feedbackData?.data}
        />
      </div>
    </div>
  );
};

export default Feedback;
