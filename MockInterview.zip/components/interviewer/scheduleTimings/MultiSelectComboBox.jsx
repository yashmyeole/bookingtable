import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils"; // or wherever your cn helper is
import Chip from "@/components/candidate/schedule/Chip";
import { useAtom } from "jotai";
import { userAtom } from "@/store/authAtoms";
import { useEffect, useState } from "react";

const SKILL_OPTIONS = [
  "JavaScript",
  "React",
  "Node.js",
  "Python",
  "Java",
  "SQL",
  "C++",
];

const MultiSkillSelect = ({ selectedSkills, setSelectedSkills }) => {
  const toggleSkill = (skill) => {
    if (selectedSkills.includes(skill)) {
      setSelectedSkills(selectedSkills.filter((s) => s !== skill));
    } else {
      setSelectedSkills([...selectedSkills, skill]);
    }
  };
  const [skillsOption, setskillsOption] = useState([]);
  const [userInfo, setUserInfo] = useAtom(userAtom);
  useEffect(() => {
    if (userInfo) {
      setskillsOption(userInfo.profile?.skills?.split("||"));
    }
  }, [userInfo]);
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className="w-[250px] border-[#e5e5e5] justify-between items-center min-h-[40px] h-[40px] px-2"
        >
          <div className="flex gap-1 overflow-x-auto flex-nowrap no-scrollbar">
            {selectedSkills.length === 0 ? (
              <span className="text-gray-500">Select Skills</span>
            ) : (
              selectedSkills.map((skill) => (
                <Chip key={skill} size="small" text={skill} />
              ))
            )}
          </div>
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[250px] p-0">
        <Command>
          <CommandInput placeholder="Search skills..." />
          <CommandList>
            {skillsOption.map((skill) => (
              <CommandItem
                key={skill}
                onSelect={() => toggleSkill(skill)}
                className="cursor-pointer"
              >
                <Check
                  className={cn(
                    "mr-2 h-4 w-4",
                    selectedSkills.includes(skill) ? "opacity-100" : "opacity-0"
                  )}
                />
                {skill}
              </CommandItem>
            ))}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
};

export default MultiSkillSelect;
