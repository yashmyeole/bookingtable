"useEffect";
import DatePickerCustom from "@/components/main/DatePickerCustom";
import TimeInput from "@/components/main/TimeInput";
import React, { useState } from "react";
import PillInputSchedule from "./PillInputSchedule";
import { Label } from "@radix-ui/react-label";
import { Input } from "@/components/ui/input";
import MultiSkillSelect from "./MultiSelectComboBox";
import { Button } from "@/components/ui/button";
import { Controller, useForm } from "react-hook-form";
import { useAtom } from "jotai";
import { editTimeSlotModalPrefillDataAtom } from "@/store/modalOpenAtoms";
import { useEditSlot } from "@/hooks/interviewerScheduleTimings";

// const previousData = {
//   startTime: "12:00:00",
//   endTime: "13:00:00",
//   skills: ["Test1", "test2"],
//   price: "200",
// };

const EditTimeSlotModal = () => {
  // const previousData = {
  //   date: "2025-06-29",
  //   startTime: "12:00",
  //   endTime: "13:00",
  //   skills: ["React"],
  //   price: "200",
  // };
  const [prefillData, setPrefillData] = useAtom(
    editTimeSlotModalPrefillDataAtom
  );
  const { mutate: updateSlot } = useEditSlot();
  const {
    control,
    handleSubmit,
    watch,
    formState: { errors },
    reset,
  } = useForm({
    defaultValues: {
      date: new Date(prefillData.date),
      startTime: prefillData.slotData.startTime,
      endTime: prefillData.slotData.endTime,
      skills: prefillData.slotData.skills.split("||"),
      price: prefillData.slotData.fee,
    },
  });
  const date = watch("date");
  // const [date, setDate] = useState(previousData.date);
  // const [skills, setskills] = useState(previousData.skills);
  const onSubmit = (data) => {
    console.log("data", data);
    console.log("prefillData", prefillData);
    const body = {
      slotId: prefillData.slotData.slotId,
      startTime: data.startTime,
      endTime: data.endTime,
      price: data.price,
      skills: data.skills.join("||"),
      date: data.date.toLocaleDateString("en-CA"),
    };
    updateSlot(body, {
      onSuccess: (data) => {
        if (data?.status === "Success") {
          queryClient.invalidateQueries({
            queryKey: ["interviewSchedules"], // Partial match
            exact: false, // Allow matching any offset
          });
        }
      },
    });
  };
  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className="flex min-w-lg  flex-col space-y-6"
    >
      <h1 className="text-lg text-center">Edit time slot</h1>
      <div className="flex justify-between space-x-4">
        {/* Date picker */}
        <div className="flex flex-col space-y-1 w-1/3">
          <Controller
            control={control}
            name="date"
            rules={{ required: "Date is required" }}
            render={({ field }) => (
              <DatePickerCustom date={field.value} setDate={field.onChange} />
            )}
          />
          {errors.date && (
            <span className="text-red-500 text-sm px-1">
              {errors.date.message}
            </span>
          )}
        </div>
        <div className="flex  justify-center space-x-3">
          {/* startTime */}
          <div className="flex flex-col space-y-1">
            <Controller
              control={control}
              name="startTime"
              rules={{
                required: "Start time is required",
                validate: (startTime) => {
                  if (!startTime) return true;

                  const selectedDate = date;
                  if (!selectedDate) return true;
                  const today = new Date();
                  const isToday =
                    selectedDate.toDateString() === today.toDateString();

                  const [h, m] = startTime.split(":").map(Number);
                  const slotStartDate = new Date(selectedDate);
                  slotStartDate.setHours(h, m, 0, 0);

                  if (isToday && slotStartDate < today) {
                    return "Start time must be later than now";
                  }

                  return true;
                },
              }}
              render={({ field }) => (
                <TimeInput
                  label="Start time"
                  time={field.value}
                  setTime={field.onChange}
                />
              )}
            />
            {errors?.startTime && (
              <span className="text-red-500 text-sm px-1">
                {errors.startTime.message}
              </span>
            )}
          </div>
          {/* endtime */}
          <div className="flex flex-col space-y-1">
            <Controller
              control={control}
              name="endTime"
              rules={{
                required: "End time is required",
                validate: (endTime) => {
                  const startTime = control._formValues.startTime;
                  if (!startTime || !endTime) return true;

                  const selectedDate = date;
                  if (!selectedDate) return true;

                  const today = new Date();
                  const isToday =
                    selectedDate.toDateString() === today.toDateString();

                  const [sh, sm] = startTime.split(":").map(Number);
                  const [eh, em] = endTime.split(":").map(Number);

                  const slotStart = new Date(selectedDate);
                  const slotEnd = new Date(selectedDate);

                  slotStart.setHours(sh, sm, 0, 0);
                  slotEnd.setHours(eh, em, 0, 0);

                  if (slotEnd <= slotStart) {
                    return "End time must be after start time";
                  }

                  if (isToday && slotEnd <= today) {
                    return "End time must be later than now";
                  }

                  return true;
                },
              }}
              render={({ field }) => (
                <TimeInput
                  label="End time"
                  time={field.value}
                  setTime={field.onChange}
                />
              )}
            />
            {errors?.endTime && (
              <span className="text-red-500 text-sm px-1">
                {errors.endTime.message}
              </span>
            )}
          </div>
        </div>
      </div>
      <div className="w-full flex justify-center  space-x-4 ">
        {/* Skills */}
        <div className="flex flex-col space-y-1 max-w-md">
          {" "}
          <Label className="text-base px-1">Skills to be Interviewed on</Label>
          <Controller
            control={control}
            name="skills"
            rules={{
              validate: (skills) =>
                skills.length > 0 || "At least one skill required",
            }}
            render={({ field }) => (
              <MultiSkillSelect
                selectedSkills={field.value}
                setSelectedSkills={field.onChange}
              />
            )}
          />
          {errors.skills && (
            <span className="text-red-500 text-sm px-1">
              {errors.skills.message}
            </span>
          )}
        </div>
        {/* Price */}
        <div className="flex flex-col space-y-1">
          <Label className="px-1">Interview Fee (₹500–₹3000)</Label>
          <Controller
            control={control}
            name="price"
            rules={{
              required: "Price is required",
              validate: (value) =>
                (+value >= 500 && +value <= 3000) ||
                "Price must be between ₹500 and ₹3000",
            }}
            render={({ field }) => (
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  ₹
                </span>
                <Input
                  type="number"
                  className="pl-7 h-[40px]"
                  placeholder="Enter amount"
                  {...field}
                />
              </div>
            )}
          />
          {errors?.price && (
            <span className="text-red-500 text-sm px-1">
              {errors.price.message}
            </span>
          )}
        </div>
      </div>
      {/* Buttons */}
      <div className="flex items-center justify-center">
        <Button type="submit">Save Changes</Button>
      </div>
    </form>
  );
};

export default EditTimeSlotModal;
