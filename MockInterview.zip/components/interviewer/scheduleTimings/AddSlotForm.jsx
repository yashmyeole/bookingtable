"use client";
import React, { useEffect, useState } from "react";
import { useForm, useFieldArray, Controller } from "react-hook-form";
import DatePickerCustom from "@/components/main/DatePickerCustom";
import SlotInputFields from "./SlotInputFields";
import { Button } from "@/components/ui/button";
import { useCreateInterviewSchedule } from "@/hooks/interviewerScheduleTimings";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";

const AddSlotForm = () => {
  const {
    control,
    handleSubmit,
    watch,
    formState: { errors },
    reset,
  } = useForm({
    defaultValues: {
      date: null,
      slots: [{ startTime: "10:00", endTime: "11:00", skills: [], price: "" }],
    },
  });
  const date = watch("date");
  const queryClient = useQueryClient();
  const { mutate: createInterviewSlot } = useCreateInterviewSchedule();
  const { fields, append, remove } = useFieldArray({
    control,
    name: "slots",
  });
  const hasTimeOverlap = (slots) => {
    const parsed = slots.map((slot) => ({
      start: parseTime(slot.startTime),
      end: parseTime(slot.endTime),
    }));

    for (let i = 0; i < parsed.length; i++) {
      for (let j = i + 1; j < parsed.length; j++) {
        const a = parsed[i];
        const b = parsed[j];

        if (a.start < b.end && b.start < a.end) {
          // Overlapping time ranges
          return true;
        }
      }
    }

    return false;
  };

  const parseTime = (timeStr) => {
    const [h, m] = timeStr.split(":").map(Number);
    return h * 60 + m;
  };
  const onSubmit = (data) => {
    const { slots, date } = data;
    if (hasTimeOverlap(slots)) {
      toast.error("Overlapping time range");
      return;
    }
    const transformedSlots = slots.map((slot) => ({
      startTime: slot.startTime,
      endTime: slot.endTime,
      fee: parseFloat(slot.price), // converting to number
      currencyType: "INR", //Hardcoded
      platformType: "Zoom",
      skills: slot.skills.join("||"),
    }));
    const transformedDate = date.toLocaleDateString("en-CA");
    const body = {
      availableDate: transformedDate,
      slots: transformedSlots,
    };
    createInterviewSlot(body, {
      onSuccess: (data) => {
        if (data?.status === "Success") {
          reset();
          // Invalidate interviewSchedules query
          // const offset = currentPage - 1;
          // const startDate = format(new Date(), "yyyy-MM-dd");
          queryClient.invalidateQueries({
            queryKey: ["interviewSchedules"], // Partial match
            exact: false, // Allow matching any offset
          });
        }
      },
    });
  };

  return (
    <form
      className="w-full flex flex-col space-y-3"
      onSubmit={handleSubmit(onSubmit)}
    >
      <div className="flex flex-col space-y-1 w-1/3">
        <Controller
          control={control}
          name="date"
          rules={{ required: "Date is required" }}
          render={({ field }) => (
            <DatePickerCustom date={field.value} setDate={field.onChange} />
          )}
        />
        {errors.date && (
          <span className="text-red-500 text-sm px-1">
            {errors.date.message}
          </span>
        )}
      </div>

      {fields.map((field, index) => (
        <SlotInputFields
          key={field.id}
          control={control}
          index={index}
          remove={remove}
          append={append}
          isLast={index === fields.length - 1}
          isOnlyOne={fields.length === 1}
          errors={errors?.slots?.[index] || {}}
          date={date}
        />
      ))}

      <div className="flex items-center justify-center">
        <Button type="submit" size="lg" className="w-[120px] p-4">
          Save
        </Button>
      </div>
    </form>
  );
};

export default AddSlotForm;
