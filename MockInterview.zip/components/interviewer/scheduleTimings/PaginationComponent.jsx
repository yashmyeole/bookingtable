"use client"; // Enables client-side rendering for this component

import React from "react";
import { Button } from "@/components/ui/button"; // Importing the custom Button component
import { BiFirstPage, BiLastPage } from "react-icons/bi"; // First and Last page icons
import { GrFormPrevious, GrFormNext } from "react-icons/gr"; // Previous and Next page icons

/**
 * PaginationComponent
 *
 * Props:
 * - currentPage: number (current active page)
 * - totalPages: number (total number of pages)
 * - onPageChange: function (callback to update page in parent)
 */
const PaginationComponent = ({ currentPage, totalPages, onPageChange }) => {
  return (
    <div className="flex items-center space-x-4">
      {/* Go to First Page Button - Disabled if already on first page */}
      <Button
        variant={"ghost"}
        className="w-8 h-8"
        onClick={() => onPageChange(1)}
        disabled={currentPage === 1}
      >
        <BiFirstPage />
      </Button>

      {/* Go to Previous Page Button - Disabled if already on first page */}
      <Button
        variant={"ghost"}
        className="w-8 h-8"
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
      >
        <GrFormPrevious />
      </Button>

      {/* Display current page and total pages in format: 1/05 */}
      <div className="text-sm font-medium flex-1">
        {currentPage}/{String(totalPages).padStart(2, "0")}
      </div>

      {/* Go to Next Page Button - Disabled if already on last page */}
      <Button
        variant={"ghost"}
        className="w-8 h-8"
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
      >
        <GrFormNext />
      </Button>

      {/* Go to Last Page Button - Disabled if already on last page */}
      <Button
        variant={"ghost"}
        className="w-8 h-8"
        onClick={() => onPageChange(totalPages)}
        disabled={currentPage === totalPages}
      >
        <BiLastPage />
      </Button>
    </div>
  );
};

export default PaginationComponent;
