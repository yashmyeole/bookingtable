"use client";
import { Label } from "@/components/ui/label";
import { useState } from "react";

export default function PillInputSchedule({ skills, setSkills }) {
  const [input, setInput] = useState("");

  const addSkill = (e) => {
    if (e.key === "Enter" && input.trim() !== "") {
      e.preventDefault();
      if (!skills.includes(input.trim())) {
        setSkills([...skills, input.trim()]);
      }
      setInput("");
    }
  };

  const removeSkill = (skillToRemove) => {
    setSkills(skills.filter((skill) => skill !== skillToRemove));
  };

  return (
    <div className="w-full flex flex-col space-y-1 max-w-md">
      <Label className="text-base px-1">Skills to be for Interviewed on</Label>
      <div className="flex flex-wrap  items-center min-h-[40px] p-2 border rounded-lg ">
        {skills.map((skill) => (
          <span
            key={skill}
            className="flex items-center bg-blue-100 text-black px-3 py-1 rounded-full text-sm"
          >
            {skill}
            <button
              onClick={() => removeSkill(skill)}
              className="ml-2 text-black hover:text-red-500 cursor-pointer"
            >
              &times;
            </button>
          </span>
        ))}
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={addSkill}
          placeholder="Add a new skill"
          className="flex-grow outline-none text-sm   min-w-[160px] placeholder:text-gray-400"
        />
      </div>
    </div>
  );
}
