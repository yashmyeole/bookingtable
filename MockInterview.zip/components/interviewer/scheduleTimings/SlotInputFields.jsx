import React from "react";
import TimeInput from "@/components/main/TimeInput";
import MultiSkillSelect from "./MultiSelectComboBox";
import { Label } from "@radix-ui/react-label";
import { Input } from "@/components/ui/input";
import { CiCircleMinus, CiCirclePlus } from "react-icons/ci";
import { Controller } from "react-hook-form";

const SlotInputFields = ({
  index,
  control,
  remove,
  append,
  isLast,
  isOnlyOne,
  errors,
  date,
}) => {
  return (
    <div className="flex">
      <div className="flex items-start space-x-8 flex-1">
        {/* Start Time */}
        <div className="flex flex-col space-y-1">
          <Controller
            control={control}
            name={`slots.${index}.startTime`}
            rules={{
              required: "Start time is required",
              validate: (startTime) => {
                if (!startTime) return true;

                const selectedDate = date;
                if (!selectedDate) return true;

                const today = new Date();
                const isToday =
                  selectedDate.toDateString() === today.toDateString();

                const [h, m] = startTime.split(":").map(Number);
                const slotStartDate = new Date(selectedDate);
                slotStartDate.setHours(h, m, 0, 0);

                if (isToday && slotStartDate < today) {
                  return "Start time must be later than now";
                }

                return true;
              },
            }}
            render={({ field }) => (
              <TimeInput
                label="Start time"
                time={field.value}
                setTime={field.onChange}
              />
            )}
          />
          {errors?.startTime && (
            <span className="text-red-500 text-sm px-1">
              {errors.startTime.message}
            </span>
          )}
        </div>

        {/* End Time */}
        <div className="flex flex-col space-y-1">
          <Controller
            control={control}
            name={`slots.${index}.endTime`}
            rules={{
              required: "End time is required",
              validate: (endTime) => {
                const startTime = control._formValues.slots?.[index]?.startTime;
                if (!startTime || !endTime) return true;

                const selectedDate = date;
                if (!selectedDate) return true;

                const today = new Date();
                const isToday =
                  selectedDate.toDateString() === today.toDateString();

                const [sh, sm] = startTime.split(":").map(Number);
                const [eh, em] = endTime.split(":").map(Number);

                const slotStart = new Date(selectedDate);
                const slotEnd = new Date(selectedDate);

                slotStart.setHours(sh, sm, 0, 0);
                slotEnd.setHours(eh, em, 0, 0);

                if (slotEnd <= slotStart) {
                  return "End time must be after start time";
                }

                if (isToday && slotEnd <= today) {
                  return "End time must be later than now";
                }

                return true;
              },
            }}
            render={({ field }) => (
              <TimeInput
                label="End time"
                time={field.value}
                setTime={field.onChange}
              />
            )}
          />
          {errors?.endTime && (
            <span className="text-red-500 text-sm px-1">
              {errors.endTime.message}
            </span>
          )}
        </div>

        {/* Skills */}
        <div className="w-full flex flex-col space-y-1 max-w-md">
          <Label className="text-base px-1">Skills to be Interviewed on</Label>
          <Controller
            control={control}
            name={`slots.${index}.skills`}
            rules={{
              validate: (skills) =>
                skills.length > 0 || "At least one skill required",
            }}
            render={({ field }) => (
              <MultiSkillSelect
                selectedSkills={field.value}
                setSelectedSkills={field.onChange}
              />
            )}
          />
          {errors.skills && (
            <span className="text-red-500 text-sm px-1">
              {errors.skills.message}
            </span>
          )}
        </div>

        {/* Price */}
        <div className="flex flex-col space-y-1">
          <Label className="px-1">Interview Fee (₹500–₹3000)</Label>
          <Controller
            control={control}
            name={`slots.${index}.price`}
            rules={{
              required: "Price is required",
              validate: (value) =>
                (+value >= 500 && +value <= 3000) ||
                "Price must be between ₹500 and ₹3000",
            }}
            render={({ field }) => (
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  ₹
                </span>
                <Input
                  type="number"
                  className="pl-7 h-[40px]"
                  placeholder="Enter amount"
                  {...field}
                />
              </div>
            )}
          />
          {errors?.price && (
            <span className="text-red-500 text-sm px-1">
              {errors.price.message}
            </span>
          )}
        </div>
      </div>

      {/* Add/Remove Buttons */}
      <div className="flex flex-row ml-4 pt-8">
        {index === 0 && (
          <div className="flex items-center justify-center h-[32px] w-[32px]">
            <CiCirclePlus
              className="text-customblue h-full w-full cursor-pointer"
              onClick={() =>
                append({
                  startTime: "10:00",
                  endTime: "11:00",
                  skills: [],
                  price: "",
                })
              }
            />
          </div>
        )}
        {index > 0 && (
          <div className="flex items-center justify-center h-[32px] w-[32px]">
            <CiCircleMinus
              className="text-red-500 h-full w-full cursor-pointer"
              onClick={() => remove(index)}
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default SlotInputFields;
