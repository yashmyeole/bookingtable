import React from "react";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

import { da } from "date-fns/locale";
import Chip from "@/components/candidate/schedule/Chip";
import StatusChip from "../../ui/CustomStatusChip";
import {
  editTimeSlotModalPrefillDataAtom,
  openEditTimeSlotModalAtom,
} from "@/store/modalOpenAtoms";
import { useAtom } from "jotai";
import { format } from "date-fns";
import { useDeleteInterviewSchedule } from "@/hooks/interviewerScheduleTimings";
import { useQueryClient } from "@tanstack/react-query";
import { isToday } from "date-fns";
import { formatTimeRange } from "@/lib/utils";
const TimeSlotTables = ({ timeSlotData }) => {
  return (
    <div className="flex flex-col space-y-10">
      {timeSlotData.map((data) => {
        return <TimeSlotTableComponent key={data.date} data={data} />;
      })}
    </div>
  );
};

const TimeSlotTableComponent = ({ data }) => {
  return (
    <div className="flex flex-col border border-[#C4C4C4] rounded-md">
      <div className="text-lg font-semibold border-b p-4 border-[#C4C4C4] rounded-t-md  bg-[#F5F7FA] ">
        {format(new Date(data.date), "EEEE, dd MMMM yyyy")}
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="text-base font-semibold">
              Scheduled Time
            </TableHead>
            <TableHead className="text-base font-semibold">Skillsets</TableHead>
            <TableHead className="text-base font-semibold">Status</TableHead>
            <TableHead className="text-base font-semibold">
              Interview amt
            </TableHead>
            <TableHead className="text-base font-semibold">Action</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data?.slots.map((item, index) => (
            <CustomRow key={index + 1} slotData={item} date={data.date} />
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

const CustomRow = ({ slotData, date }) => {
  return (
    <TableRow>
      <TableCell className="font-medium">
        {formatTimeRange(slotData.startTime, slotData.endTime)}
      </TableCell>
      <TableCell className="flex space-x-2  flex-wrap max-w-xs">
        {renderSkills(slotData.skills?.split("||"))}
      </TableCell>
      <TableCell>
        <StatusChip text={slotData.status} />
      </TableCell>
      <TableCell>{`₹ ${slotData.fee}`}</TableCell>
      <TableCell>{<ActionButtons slotData={slotData} date={date} />}</TableCell>
    </TableRow>
  );
};

const ActionButtons = ({ slotData, date }) => {
  const [openEditTimeSlotModal, setopenEditTimeSlotModal] = useAtom(
    openEditTimeSlotModalAtom
  );
  const [prefillData, setPrefillData] = useAtom(
    editTimeSlotModalPrefillDataAtom
  );
  const { mutate: deleteSlot } = useDeleteInterviewSchedule();
  const queryClient = useQueryClient();
  const status = slotData.status;

  const isDateToday = isToday(new Date(date));

  const handleEdit = () => {
    setPrefillData({ date: date, slotData: { ...slotData } });
    setopenEditTimeSlotModal(true);
  };

  const handleReschedule = () => {
    // handle reschedule logic
  };

  const handleDelete = async () => {
    deleteSlot(
      { slotId: slotData.slotId },
      {
        onSuccess: (data) => {
          if (data?.status === "Success") {
            queryClient.invalidateQueries({
              queryKey: ["interviewSchedules"],
              exact: false,
            });
          }
        },
      }
    );
  };

  // If status is 'cancelled' or 'completed' or the date is today, return nothing
  if (
    status?.toLowerCase() === "cancelled" ||
    status?.toLowerCase() === "completed" ||
    isDateToday
  ) {
    return <div className="flex justify-center">--</div>;
  }

  return (
    <div className="flex space-x-3">
      {status === "scheduled" ? (
        <span
          onClick={handleReschedule}
          className="text-customblue cursor-pointer"
        >
          Reschedule
        </span>
      ) : (
        <>
          <span
            onClick={handleEdit}
            className="text-customblue cursor-pointer mr-2"
          >
            Edit
          </span>
          <span
            onClick={handleDelete}
            className="text-customblue cursor-pointer"
          >
            Delete
          </span>
        </>
      )}
    </div>
  );
};

const renderSkills = (skillsArray) => {
  return skillsArray.map((skill, index) => <Chip key={index} text={skill} />);
};
const sampleData = [
  {
    scheduleTime: "10:00 AM - 11:00 AM",
    skillSets: "React, Node.js",
    status: "Scheduled",
    interviewAmt: "₹500",
  },
  {
    scheduleTime: "02:30 PM - 03:30 PM",
    skillSets: "Python, Django",
    status: "Completed",
    interviewAmt: "₹750",
  },
  {
    scheduleTime: "11:00 AM - 12:00 PM",
    skillSets: "Java, Spring Boot",
    status: "Pending",
    interviewAmt: "₹",
  },
  {
    scheduleTime: "04:15 PM - 05:15 PM",
    skillSets: "DevOps, AWS",
    status: "Cancelled",
    interviewAmt: "₹0",
  },
];

export default TimeSlotTables;
