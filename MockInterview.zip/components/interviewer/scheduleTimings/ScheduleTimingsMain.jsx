"use client";
import React, { useEffect, useState } from "react";
import AddSlotForm from "./AddSlotForm";
import TimeSlotTables from "./TimeSlotTables";
import PaginationComponent from "./PaginationComponent";
import PopupWrapper from "@/components/Wrappers/PopupWrapper";
import { useAtom } from "jotai";
import { openEditTimeSlotModalAtom } from "@/store/modalOpenAtoms";
import EditTimeSlotModal from "./EditTimeSlotModal";
import { useInterviewSchedules } from "@/hooks/interviewerScheduleTimings";
import NoData from "@/components/main/NoData";
const ScheduleTimingsMain = () => {
  const [currentPage, setCurrentPage] = useState(1);
  // Or fetch dynamically based on data length
  const [openEditTimeSlotModal, setopenEditTimeSlotModal] = useAtom(
    openEditTimeSlotModalAtom
  );

  const { data, isLoading } = useInterviewSchedules(currentPage);
  const hasData = data?.response && data.response.length > 0;
  return (
    <div className="flex w-full flex-col space-y-3">
      <p className="text-base font-medium">
        Choose your Interview Slots and Skills when you're available to conduct
        interviews.
      </p>
      {/* Add Slot Form */}
      <AddSlotForm />
      {/* Time Slot Table or No Data */}
      <div className="flex flex-col space-y-2 overflow-y-auto">
        {isLoading ? (
          <div>Loading...</div>
        ) : hasData ? (
          <>
            <p className="text-lg font-semibold">Your Scheduled Time Slots</p>
            <TimeSlotTables timeSlotData={data.response} />
          </>
        ) : (
          <NoData
            mainCss=""
            paddingX=""
            paddingY="py-17"
            titleOfPage=""
            altPara1="No time slots, dates, or skillsets have been specified yet. Kindly provide your availability and desired skills."
          />
        )}
      </div>

      {/* Pagination */}
      <div className="flex justify-end">
        {!isLoading && hasData && (
          <PaginationComponent
            currentPage={currentPage}
            totalPages={data.pages}
            onPageChange={(page) => setCurrentPage(page)}
          />
        )}
      </div>
      {/* Till hear */}
      <PopupWrapper
        isOpen={openEditTimeSlotModal}
        isClose={() => setopenEditTimeSlotModal(!openEditTimeSlotModal)}
      >
        <EditTimeSlotModal />
      </PopupWrapper>
    </div>
  );
};

export default ScheduleTimingsMain;
