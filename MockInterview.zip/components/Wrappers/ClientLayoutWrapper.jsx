// components/wrappers/ClientLayoutWrapper.jsx
"use client";
import Navbar from "@/components/main/Navbar";
import BottomBar from "@/components/main/BottomBar";
import { Provider as JotaiProvider } from "jotai";
import QueryProvider from "@/providers/QueryProvider";
import { useSyncProfileToAtom } from "@/hooks/authHooks";
import { ProfileSyncer } from "../main/ProfileSyncer";
import HydrateUserAtom from "../main/HydrateUserAtom";

export default function ClientLayoutWrapper({ children, initialUserData }) {
  return (
    <QueryProvider>
      <JotaiProvider>
        {/* <ProfileSyncer /> */}
        <HydrateUserAtom initialUserData={initialUserData} />
        <div className="flex flex-col max-h-screen max-w-screen overflow-x-hidden overflow-y-hidden">
          <div className="flex sticky w-screen h-fit border-b-[1px] border-gray-200">
            <Navbar />
          </div>
          <div className="flex flex-1 w-screen min-h-screen">
            <div className="flex flex-1 ">{children}</div>
          </div>
          <div className="flex fixed bottom-0  w-full h-[60px] border-t border-gray-200 bg-white">
            <BottomBar />
          </div>
        </div>
      </JotaiProvider>
    </QueryProvider>
  );
}
