import React from "react";
import { RxCross2 } from "react-icons/rx";

const PopupWrapper = ({ title, isOpen, isClose, children }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex justify-center items-center bg-opacity-50 backdrop-invert-20">
      <div className="bg-white relative px-8 py-4 max-w-[70%] rounded-3xl">
        {title ? (
          <div className="p-4 text-center text-md font-semibold">{title}</div>
        ) : (
          <div className="p-4"></div>
        )}
        <span
          className="absolute top-4 right-5 cursor-pointer"
          onClick={isClose}
        >
          <RxCross2 className="text-2xl" />
        </span>
        <div className="">{children}</div>
      </div>
    </div>
  );
};
export default PopupWrapper;
