"use client";
import { DropDownComponent } from '@/components/main/DropdownComponent'
import Filters from '@/components/main/Filters'
import InterviewerInfo from '@/components/main/InterviewerInfo'
import React, { useEffect, useState } from 'react'
import {sortByOptions} from '@/utils/Utility'
import Loader from '@/components/ui/loader'
import { useForm } from 'react-hook-form'
import { useGetMentors } from '@/hooks/userHooks'

const Explore = () => {
  const [filters, setFilters] = useState({
    domain: [],
    skills: [],
    tools: [],
    companies: ["Ril", "Jio"],
    experience: 0,
    pricing: 0
  });
const combinedData = {
        type:"mobile",
        value: "7777788888",
        deviceId: 1215,
        otp: 282828
    }
  const handleUpdate = (updatedFilters) => {
    setFilters(updatedFilters);
  };
  const filtersBody = {
      "filters": {   
                "companies": filters.companies,  
 
                "minExperience": 0,
 
                "maxExperience": filters.experience,
 
                "minPrice": 0,  
 
                "maxPrice": filters.pricing 
 
                },  
 
      "sort": {  
 
            "field": "price",  
 
            "order": "asc"
 
            },  
 
      "offset": 0
    }
  console.log("Fiters",filters)
  const { data: profileData, isLoading, isError } = useGetMentors(filtersBody);
    
        
    
   
  return (
    <div className='flex gap-20 h-screen'>
      <div className='overflow-y-auto w-1/4 max-h-screen mb-60'>
        <Filters onFiltersChange={handleUpdate}/>
      </div>
        <div className='space-y-8 w-3/4 overflow-y-auto max-h-screen pr-10 mb-40'>
            <div className='flex gap-4 items-center justify-center float-right'>
                <span>Sort by:</span>
                {/* <DropDownComponent
                  options={sortByOptions}
                /> */}
            </div>
         <div className=''>
            {profileData?.data?.mentors ? (
              <InterviewerInfo 
                mentors={profileData?.data?.mentors}
            />
            ) : (
              <Loader/>
            )}
         </div>
        </div>
      </div>
  )
}

export default Explore
