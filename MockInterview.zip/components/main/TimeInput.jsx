"use client";
import React, { useState } from "react";
import { Label } from "../ui/label";
import { Input } from "../ui/input";

const TimeInput = ({ label, time, setTime }) => {
  const handleChange = (e) => {
    setTime(e.target.value);
  };
  return (
    <div className="flex flex-col space-y-1">
      <Label htmlFor="time-picker" className="px-1 text-base">
        {label}
      </Label>
      <Input
        type="time"
        id="time-picker"
        step="60"
        value={time}
        onChange={handleChange}
        className="bg-background h-[40px] appearance-none [&::-webkit-calendar-picker-indicator]:hidden [&::-webkit-calendar-picker-indicator]:appearance-none"
      />
    </div>
  );
};

export default TimeInput;
