"use client";
import Image from "next/image";
import React from "react";
import JioLogo from "../../assets/jio_logo.png";

const BottomBar = () => {
  return (
    <div className="flex w-full items-center justify-between h-[60px] px-[8vw] text-sm">
      <div className="flex items-center gap-x-4 text-gray-600">
        <div className="cursor-pointer">
          <Image alt="Logo" src={JioLogo} width={30} height={30} />
        </div>
        <div className="cursor-pointer text-sm">
          Copyright © 2021 Reliance Jio Infocomm Ltd. All rights reserved.
        </div>
      </div>
      <div className="flex gap-x-2">
        <div className="cursor-pointer">Regulatory</div>
        <div className="cursor-pointer border-l border-gray-300 pl-2">
          Policies
        </div>
        <div className="cursor-pointer border-l border-gray-300 pl-2">
          Terms & Conditions
        </div>
      </div>
    </div>
  );
};

export default BottomBar;
