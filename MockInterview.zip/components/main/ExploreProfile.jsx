"use client"
import Image from 'next/image';
import React, { useState } from 'react';
import profile from '@/assets/kartik.png';
import star from '@/assets/star_icon.png';
import { userSkills, timeSlot } from '@/utils/Utility'
import { Calendar } from "@/components/ui/calendar";
import AvailableSlot from '../candidate/schedule/Reschedule/AvailableSlot';
import PopupWrapper from '../Wrappers/PopupWrapper';

const ExploreProfile = ({mentor, mentorId}) => {
  const filteredMentor = mentor?.find((m) => m.id === Number(mentorId));

  return <ExploreProfileHelper 
      mentorData={filteredMentor}
  />;
};

function ExploreProfileHelper({mentorData}) {
  console.log("data", mentorData)
  const [confirmBooking, setConfirmBooking] = useState(false);
  function handleClose() {
    setConfirmBooking(prev => !prev);
  }
  const [slotFlag, setSlotFlag] = useState(false);
  return (
    <div>
      {/* Top Section: Profile Picture and Basic Info */}
      <div className='flex gap-10 items-end w-full'>
        {/* Profile Image */}
        <Image
          className='relative top-4 rounded-full border-2 border-[#007FAD]'
          src={profile}
          alt='ProfileImage'
          width={230}
        />

        {/* User Information */}
        <div className='space-y-2 w-full'>
          {/* Name and Rating */}
          <div className='flex justify-between'>
            <div className='font-bold text-lg tracking-widest'>{mentorData?.firstname} {mentorData?.lastname}</div>
            <div className='flex items-center'>
              <Image className='pb-1' src={star} alt='Rating' width={19} />
              <span className='text-sm ml-1 font-bold'>5.4</span>
            </div>
          </div>

          {/* Job Title */}
          <span>Tech Lead at {mentorData?.organizationName}</span>

          {/* Experience and Domain */}
          <div className='flex gap-3 my-2 flex-wrap'>
            <span className='rounded-3xl bg-[#D9F4FE] text-sm px-4 py-2'>
              Experience: {mentorData?.experienceYears} years
            </span>
            <span className='rounded-3xl bg-[#D9F4FE] text-sm px-4 py-2'>
              Domain: {mentorData?.domain}
            </span>
          </div>
        </div>
      </div>

      {/* Divider */}
      <div className='border-b border-gray-300 my-10' />

      {/* About Section */}
      <div>
        <span className='text-base font-semibold'>About</span>
        <p className='text-base text-neutral-700 mt-2'>
          {mentorData?.overview}
        </p>
      </div>

      {/* Divider */}
      <div className='border-b border-gray-300 my-10' />

      {/* Skills Section */}
      <div>
        <span className='text-base font-semibold'>Skills</span>
        <div className='flex gap-3 my-7 flex-wrap'>
          {userSkills.map((skill, index) => (
            <span
              key={index}
              className='rounded-3xl bg-[#D9F4FE] text-sm px-4 py-2 text-[#007FAD]'
            >
              {skill}
            </span>
          ))}
        </div>
      </div>

      {/* Divider */}
      <div className='border-b border-gray-300 my-10' />

      {/* LinkedIn Section */}
      <div>
        <span className='text-base font-semibold'>LinkedIn</span>
        <p className='text-base text-neutral-700 mt-2'>
          Senior Software Eng, took more than 300+ interviews. Expert in system
        </p>
      </div>

      {/* Divider */}
      <div className='border-b border-gray-300 my-10' />
      <BookingSlots
        setSlotFlag={setSlotFlag}
        slotFlag={slotFlag}
      />
      {slotFlag === true && <>
        <SelectedSlot
          setConfirmBooking={setConfirmBooking}
          confirmBooking={confirmBooking} />
        {confirmBooking && <PopupWrapper isOpen={confirmBooking} isClose={handleClose}>
          <div className='min-w-[400px] px-8 py-2 flex flex-col  space-y-4'>
            <h4 className='text-center'>Booking summary</h4>
            <div className='flex flex-col gap-4 px-8'>
              <div className='flex gap-4'>
                <span>Interviewer : </span>
                <span>Anurag Tyagi</span>
              </div>
              <div className='flex gap-4'>
                <span>Date & time :</span>
                <span>1 Apr 2025 ,Monday | 11:30 AM - 12:30 PM</span>
              </div>
              <div className='flex gap-4'>
                <span>Skills for Interview :</span>
                <div className='flex gap-3 flex-wrap'>
          {userSkills.map((skill, index) => (
            <span
              key={index}
              className='rounded-3xl bg-[#D9F4FE] text-sm px-2 py-1 text-black'
            >
              {skill}
            </span>
          ))}
        </div>
              </div>
              <div className='flex gap-4'>
                <span>Duration :</span>
                <span>1 hr</span>
              </div>
              <div className='flex gap-4'>
                <span>Price :</span>
                <span>Rs 1500</span>
              </div>
            </div>
            <div className='flex items-center justify-center'>
              <button className='bg-[#007FAD] text-base text-white py-2 px-8 rounded-md'>Proceed to payment</button>
            </div>
          </div>
        </PopupWrapper>}
      </>
      }
    </div>
  );
}

function BookingSlots({ setSlotFlag, slotFlag }) {
  const [date, setDate] = useState(new Date(2025, 6, 19))
  function handleClick() {
    setSlotFlag(prev => !prev)
  }
  return (
    <div className='bg-gray-100 px-6 py-6 rounded-xl w-full'>
      <div className='flex flex-col'>
        <div className='space-y-[60px]'>
          <h2 className='text-left leading-none text-2xl tracking-wide'>Available Dates And time Slots</h2>
        </div>
        <div className='flex flex-col md:flex-row mt-8 gap-6 w-full'>
          <div className='flex flex-col gap-4 w-[30%] '>
            <span >Select Date</span>
            <Calendar
              mode="single"
              defaultMonth={date}
              selected={date}
              onSelect={setDate}
              className="w-full max-w-full rounded-lg h-[400px]"
              showOutsideDays={false}
            />
          </div>
          <div className='flex flex-col gap-4 w-[70%]'>
            <span >Select time slot with skills</span>
            <div className='max-h-[400px] px-3 py-1 rounded-lg bg-white overflow-y-auto'>
              <AvailableSlot />
            </div>
          </div>

        </div>
      </div>
      <div className='flex items-center justify-center my-8'>
        <button onClick={handleClick} className='bg-[#007FAD] text-base text-white py-3 px-6 rounded-md'>Book slot</button>
      </div>
    </div>
  )
}

function SelectedSlot({ setConfirmBooking }) {

  function handleBooking() {
    setConfirmBooking(true)
  }
  return (
    <div className='my-3'>
      <div className='py-3'>Selected time slot</div>
      <div className='p-4 border border-[#007FAD] rounded-md bg-[#EBFAFF]'>
        <div className='flex flex-col md:flex-row justify-between gap-4 md:gap-0'>
          <div className='flex flex-col space-y-2'>
            <span>{timeSlot.date} | {timeSlot.time}</span>
            <span>{timeSlot.duration} | {timeSlot.price}</span>
            <span>Skills covered</span>
            <div className='flex flex-col gap-4 md:flex-row'>
              {timeSlot.skills.map((list, index) => (
                <span key={index} className='rounded-3xl max-w-[140px] bg-[#D9F4FE] text-center text-sm px-4 py-2 text-[#007FAD]'>{list}</span>
              ))}
            </div>
          </div>
          <div>
            <button onClick={handleBooking} className='bg-[#007FAD] text-base text-white py-3 px-6 rounded-md'>Confirm booking</button>
          </div>
        </div>
      </div>
    </div>
  )
}
export default ExploreProfile;
