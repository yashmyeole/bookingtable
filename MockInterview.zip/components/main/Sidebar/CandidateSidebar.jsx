"use client";
import { useRouter, usePathname } from "next/navigation";
import React, { useEffect, useState } from "react";
import { FaTasks } from "react-icons/fa";
import { FaUserGear } from "react-icons/fa6";
import { MdDashboard, MdFeedback, MdPayment } from "react-icons/md";

const SidebarComponent = ({
  tabLogo,
  tabName,
  tab,
  setTab,
  tabOpenList,
  open,
  id,
  link,
  setOpen,
  tabId,
}) => {
  const router = useRouter();
  const name = usePathname();

  return (
    <>
      <div
        className={` py-3 flex relative flex-col items-start justify-center ${
          id === tab && "bg-[#D9F5FF]  rounded-xl"
        }`}
      >
        {
          <div
            onClick={() => {
              setTab(id);
              router.push(link);
            }}
            className={`flex relative gap-x-4 w-[100%] px-2 justify-start items-center cursor-pointer transition-background duration-500 
           
            `}
          >
            <div onClick={() => open && setOpen(false)}>{tabLogo || ""}</div>
            {
              <p
                className={`overflow-clip text-[1vw] whitespace-nowrap  ${
                  id === tab ? "text-[#007FAD]" : "text-[#0c0c0c]"
                }`}
              >
                {tabName || tabId}
              </p>
            }
          </div>
        }
      </div>
    </>
  );
};
const CandidateSidebar = () => {
  const name = usePathname();
  const [open, setOpen] = React.useState(false);
  const [tab, setTab] = React.useState(() => {
    if (name.includes("/candidate/dashboard")) {
      return 0;
    } else if (name === "/candidate/schedules") {
      return 1;
    } else if (name.includes("/candidate/feedback")) {
      return 2;
    } else if (name === "/candidate/payment") {
      return 3;
    } else if (name === "/candidate/profile") {
      return 4;
    }
  });

  useEffect(() => {
    if (name.includes("/candidate/dashboard")) {
      setTab(0);
    } else if (name === "/candidate/schedules") {
      setTab(1);
    } else if (name.includes("/candidate/feedback")) {
      setTab(2);
    } else if (name === "/candidate/payment") {
      setTab(3);
    } else if (name === "/candidate/profile") {
      setTab(4);
    }
  }, [, name]);

  const router = useRouter();

  // const {
  //   data: projects,
  //   isLoading: isLoadingProjects,
  //   isFetched: isFetchedProjects,
  //   refetch,
  // } = useGetProjects({
  //   userId: userId,
  // });

  return (
    <div
      className={`${
        open ? "w-[70px] pr-20 bg-[#D9F5FF] " : " w-[17vw]"
      } flex flex-col text-[#007FAD] pt-8 px-4 transition-all duration-1000 relative select-none border-r-1 border-gray-200 bg-[#FFFFFF] h-full overflow-y-hidden gap-y-3`}
    >
      <SidebarComponent
        id={0}
        tabName="Dashboard"
        link="/candidate/dashboard"
        setTab={setTab}
        tabId={-1}
        tab={tab}
        tabLogo={
          <div className="ml-2">
            <MdDashboard color="#007FAD" size={"1.5vw"} />
          </div>
        }
        open={open}
        setOpen={setOpen}
        tabOpenList={undefined}
      />
      <SidebarComponent
        id={1}
        tabName="Schedules"
        link="/candidate/schedules"
        setTab={setTab}
        tab={tab}
        tabLogo={
          <div className="ml-2">
            <FaTasks color="#007FAD" size={"1.5vw"} />
          </div>
        }
        open={open}
        setOpen={setOpen}
        tabOpenList={undefined}
      />

      <SidebarComponent
        id={2}
        tabName="Feedback"
        link="/candidate/feedback"
        setTab={setTab}
        tab={tab}
        tabLogo={
          <div className="ml-2">
            <MdFeedback color="#007FAD" size={"1.5vw"} />
          </div>
        }
        open={open}
        setOpen={setOpen}
        tabOpenList={undefined}
      />
      <SidebarComponent
        id={3}
        tabName="Payment"
        link="/candidate/payment"
        setTab={setTab}
        tab={tab}
        tabLogo={
          <div className="ml-2">
            <MdPayment color="#007FAD" size={"1.5vw"} />
          </div>
        }
        open={open}
        setOpen={setOpen}
        tabOpenList={undefined}
      />
      <SidebarComponent
        id={4}
        tabName="Profile"
        link="/candidate/profile"
        setTab={setTab}
        tab={tab}
        tabLogo={
          <div className="ml-2">
            <FaUserGear color="#007FAD" size={"1.5vw"} />
          </div>
        }
        open={open}
        setOpen={setOpen}
        tabOpenList={undefined}
      />
    </div>
  );
};

export default CandidateSidebar;
