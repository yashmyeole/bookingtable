"use client";
import Image from "next/image";
import RedCrossIcon from "@/assets/ic_error_colored.png"; // Adjust path as needed

export function InputComponent({
  label,
  name,
  width,
  register,
  rules = {},
  errors,
  placeholder,
  verifiable = false,
  isVerified = false,
  onVerify,
  type = "text",
  ...rest
}) {
  const hasError = !!errors?.[name];

  return (
    <div className={`flex flex-col ${width}`}>
  {label && (
    <label htmlFor={name} className='text-md pb-2'>{label}</label>
  )}

  <input
    id={name}
    name={name}
    type={type}
    placeholder={placeholder}
    className='border text-base text-[#666666] border-[#E0E0E0] rounded-md px-4 py-3 placeholder:text-[#979797] placeholder:text-sm w-full'
    aria-invalid={hasError}
    autoComplete="off"
    {...register?.(name, rules)}
    {...rest}
  />

  {hasError && (
    <div className="flex items-center gap-2 mt-1">
      <span className="text-sm text-red-500">{errors?.[name]?.message}</span>
    </div>
  )}
</div>

  );
}
