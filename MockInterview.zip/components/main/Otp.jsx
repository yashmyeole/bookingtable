"use client";
import React, { useEffect, useState } from "react";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "../ui/input-otp";
import { REGEXP_ONLY_DIGITS } from "input-otp";
import { Button } from "../ui/button";
import {
  getTokenDetails,
  useGenerateOtpMutation,
  useValidateOtpMutation,
} from "@/hooks/authHooks";
import { useAtom, useSetAtom } from "jotai";
import { openOtpPopUpModalAtom } from "@/store/modalOpenAtoms";
import { da } from "date-fns/locale";
import axiosInstance from "@/api/axiosInstance";
import { toast } from "react-toastify";
import { userAtom, userTypeAtom } from "@/store/authAtoms";
import { useRouter } from "next/navigation";
import { useQueryClient } from "@tanstack/react-query";

// Configurable values
const OTP_EXPIRY_SECONDS = 180; // 3 minutes
const RESEND_ENABLE_AFTER = 30; // 30 seconds

/* 
useCaseName:mobile or email
useFor:login or register
mobileNoOREmail: Mobile or email on which otp is sent
setIsOtpVerify:When  useFor register these setters function are used to set verificatin status
setIsEmailVerify:When  useFor register these setters function are used to set verificatin status
userType:Candidate or Interviewr for login 
*/
const Otp = ({
  useCaseName,
  mobileNoOrEmail = "9812192111",
  setIsOtpVerify,
  setIsEmailVerify,
  useFor = "register",
}) => {
  const [timer, setTimer] = useState(OTP_EXPIRY_SECONDS);
  const [resendEnabled, setResendEnabled] = useState(false);
  const [otp, setOtp] = useState("");
  const [openOtpPopUp, setopenOtpPopUp] = useAtom(openOtpPopUpModalAtom);
  const { mutate: validateOtp } = useValidateOtpMutation();
  const { mutate: generateOtp } = useGenerateOtpMutation();
  const [userType, setUserType] = useAtom(userTypeAtom);
  const [userInfo, setuserInfo] = useAtom(userAtom);
  const queryClient = useQueryClient();
  const router = useRouter();
  // Countdown timer
  useEffect(() => {
    if (timer <= 0) return;

    const interval = setInterval(() => {
      setTimer((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [timer]);

  // Enable resend after specific time
  useEffect(() => {
    if (timer <= OTP_EXPIRY_SECONDS - RESEND_ENABLE_AFTER) {
      setResendEnabled(true);
    }
  }, [timer]);

  const handleResend = () => {
    if (!resendEnabled) return;
    setTimer(OTP_EXPIRY_SECONDS);
    setResendEnabled(false);
    generateOtp({
      type: useCaseName === "mobile" ? "Mobile" : "Email",
      value: mobileNoOrEmail,
      deviceId: 1215,
      resendFlag: "1",
      registration: 1, //Ask this
    });
    setOtp("");
  };

  // Helper to format mm:ss
  const formatTime = (seconds) => {
    const m = String(Math.floor(seconds / 60)).padStart(2, "0");
    const s = String(seconds % 60).padStart(2, "0");
    return `${m}:${s}`;
  };
  function maskContact(contact) {
    if (!contact) return "";

    // Check if it's a valid email
    if (contact.includes("@")) {
      const [username, domain] = contact.split("@");
      if (username.length <= 3) {
        return username[0] + "*".repeat(username.length - 1) + "@" + domain;
      }
      return (
        username.slice(0, 3) + "*".repeat(username.length - 3) + "@" + domain
      );
    }

    // Assume it's a mobile number
    if (/^\d{10,15}$/.test(contact)) {
      return (
        contact.slice(0, 5) + "*".repeat(contact.length - 7) + contact.slice(-2)
      );
    }

    return contact; // Fallback for invalid formats
  }
  const handleVerifyOtp = async () => {
    console.log("Otp entered is ", otp);
    validateOtp(
      {
        type: useCaseName,
        value: mobileNoOrEmail,
        deviceId: 1215,
        otp: otp,
        registration: 1,
      },
      {
        onSuccess: (data) => {
          if (data.status === "Success") {
            toast.success(data?.statusMsg || "OTP validated successfully");
            if (useCaseName === "mobile") {
              setIsOtpVerify(true);
              setopenOtpPopUp(false);
            } else {
              setIsEmailVerify(true);
              setopenOtpPopUp(false);
            }
          } else {
            toast.error(data?.statusMsg || "Failed to validate OTP");
          }
          // setopenOtpPopUp(false);
        },
      }
    );
  };
  const handleVerifyOtpLogin = async () => {
    validateOtp(
      {
        type: useCaseName,
        value: mobileNoOrEmail,
        deviceId: 1215,
        otp: otp,
        registration: 0,
      },
      {
        onSuccess: async (data) => {
          if (data.status === "Success") {
            const token = data?.token;
            console.log("Token", data);
            if (!token) {
              toast.error("Token not received after OTP validation");
              return;
            }

            // Step 1: Save token in cookie temporarly
            document.cookie = `token=${token}; path=/; max-age=${
              60 * 60 * 24
            }; secure; samesite=lax`;
            // localStorage.setItem("token", token); // or use context/zustand

            try {
              // Step 2: Get token details
              const userData = await getTokenDetails();
              // Step 3: Compare role

              let isValidLogin = false;

              if (
                userType.toLowerCase() === "candidate" &&
                userData.roleId === "1"
              ) {
                isValidLogin = true;
              } else if (
                userType.toLowerCase() === "interviewer" &&
                userData.roleId === "2"
              ) {
                isValidLogin = true;
              }

              if (isValidLogin) {
                toast.success(data?.statusMsg || "OTP validated successfully");
                // const userTokenData = await queryClient.fetchQuery({
                //   queryKey: ["token-details"],
                //   queryFn: getTokenDetails,
                // }); // uses axiosInstance
                // const profile = await queryClient.fetchQuery({
                //   queryKey: ["getProfile"],
                //   queryFn: () =>
                //     axiosInstance
                //       .get(`mockInterview/api/getProfile`)
                //       .then((res) => res.data.result),
                // });
                // // console.log("Profile after login :", profile);
                // // console.log("user token data :", userTokenData);
                // const combinedData = {
                //   token: userTokenData,
                //   profile: profile,
                // };
                // setuserInfo(combinedData);
                window.location.href = `/${userType}/dashboard`;
                // if (userType === "candidate") {
                //   router.push(`/${userType}/dashboard`);
                //   window.location.href(`/${userType}/dashboard`);
                // } else {
                //   router.push(`/${userType}/dashboard`);
                //   window.location.href(`/${userType}/dashboard`);
                // }

                // Proceed with navigation or setting user context here
              } else {
                toast.error(`Mobile No not registered`);
                document.cookie = `token=; Max-Age=0; path=/;`;
              }
            } catch (err) {
              console.log(err);
              toast.error("Failed to get token details");
            }
          } else {
            toast.error(data?.statusMsg || "OTP validation failed");
          }
          // setopenOtpPopUp(false);
        },
      }
    );
  };
  return (
    <div className="flex flex-col  gap-8 ">
      {/* Heading  Name will be dynamic form email and phone */}
      <div className="flex flex-col gap-3">
        <h1 className="text-2xl font-medium">
          Verify {useCaseName === "mobile" ? "Mobile No" : "Email"}
        </h1>
        <label className="text-base text-textgrey">
          The OTP has been sent to {maskContact(mobileNoOrEmail)}
        </label>
      </div>
      {/* Otp input slot and resend timer part */}
      <div className="flex flex-col gap-3">
        <InputOTP
          value={otp}
          onChange={setOtp}
          maxLength={6}
          pattern={REGEXP_ONLY_DIGITS}
        >
          <InputOTPGroup>
            <InputOTPSlot index={0} />
            <InputOTPSlot index={1} />
            <InputOTPSlot index={2} />
            <InputOTPSlot index={3} />
            <InputOTPSlot index={4} />
            <InputOTPSlot index={5} />
          </InputOTPGroup>
        </InputOTP>
        {/* Resend and timer logic */}
        {/* <div className="flex justify-end">Resend</div> */}
        <div className="flex justify-between items-center text-sm text-gray-500">
          <span>Expires in: {formatTime(timer)}</span>
          <Button
            variant="link"
            className="p-0"
            onClick={handleResend}
            disabled={!resendEnabled}
          >
            Resend OTP
          </Button>
        </div>
      </div>
      <Button
        onClick={useFor === "register" ? handleVerifyOtp : handleVerifyOtpLogin}
        disabled={otp.length !== 6}
        size={"lg"}
      >
        Verify OTP
      </Button>
    </div>
  );
};

export default Otp;
