// components/utils/ProfileSyncer.jsx
"use client";

import { useSyncProfileToAtom } from "@/hooks/authHooks";

export const ProfileSyncer = () => {
  useSyncProfileToAtom(); // ✅ Runs after QueryProvider is active
  return null;
};
