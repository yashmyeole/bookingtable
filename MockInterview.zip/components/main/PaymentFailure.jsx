import React from "react";
import { XCircle } from "lucide-react";

const PaymentFailure = () => {
  return (
    <div className="flex flex-col items-center justify-center text-center space-y-4">
      <XCircle className="text-red-600" size={60} />
      <h2 className="text-2xl font-semibold text-red-700">Payment Failed</h2>
      <p className="text-gray-700 max-w-md">
        Something went wrong with your transaction. Please try again or contact
        support if the issue persists.
      </p>
      <button className="mt-4 px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition">
        Try Again
      </button>
    </div>
  );
};

export default PaymentFailure;
