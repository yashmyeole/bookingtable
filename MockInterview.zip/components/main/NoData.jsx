import Image from 'next/image'
import Link from 'next/link'
import React from 'react'

const NoData = ({mainCss, paddingX, paddingY, titleOfPage, icon, iconWidth, altTtitle, altPara1, altPara2, noBackgroundButtonLink, backgroundButtonLink, noBackgroundButton,backgroundButton}) => {
  return (
    <div className='w-full '>
      {titleOfPage && <div className='text-2xl font-bold'>
        {titleOfPage}
      </div>}
      <div className={`w-full ${paddingX} ${paddingY} my-8 bg-white ${mainCss} flex flex-col items-center justify-center space-y-6`}>
        {icon && 
        <div>
            <Image src={icon} alt='Icon' width={iconWidth}/>
        </div>}
        <div className='flex flex-col items-center justify-center gap-3'>
            <h4 className='font-bold text-xl'>{altTtitle}</h4>
            <p className='text-center px-14 tracking-wide text-wrap text-[#979797]'>{altPara1}</p>
            <p className='text-center px-14 tracking-wide text-wrap text-[#979797]'>{altPara2}</p>
        </div>
        <div className='flex gap-6'>
            {noBackgroundButton && <Link href={noBackgroundButtonLink || ''} className='border border-[#007FAD] text-base text-[#007FAD] py-3 px-6 rounded-md'>{noBackgroundButton}
                </Link>}
            {backgroundButton && <Link href={backgroundButtonLink || ''} className='bg-[#007FAD] text-base text-white py-3 px-6 rounded-md'>{backgroundButton}
                </Link>}
        </div>
      </div>
    </div>
  )
}

export default NoData


