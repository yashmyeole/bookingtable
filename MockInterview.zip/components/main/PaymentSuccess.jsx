import React from "react";
import { CheckCircle2 } from "lucide-react";

const PaymentSuccess = () => {
  return (
    <div className="flex flex-col items-center justify-center text-center space-y-4">
      <CheckCircle2 className="text-green-600" size={60} />
      <h2 className="text-2xl font-semibold text-green-700">
        Payment Successful!
      </h2>
      <p className="text-gray-700 max-w-md">
        Thank you for your payment. A confirmation email has been sent to your
        registered address.
      </p>
      <button className="mt-4 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition">
        Go to Dashboard
      </button>
    </div>
  );
};

export default PaymentSuccess;
