"use client";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import Image from "next/image";
import RedCrossIcon from "@/assets/ic_error_colored.png"; // Update to your path
import { cn } from "@/lib/utils";
import { Controller } from "react-hook-form";

export function DropDownComponent({
  label,
  name,
  width,
  control,
  options = [],
  errors,
  css,
  placeholder = "Select an option",
  rules = {},
}) {
  const hasError = !!errors?.[name];

  return (
    <div className={`flex flex-col gap-1 ${width}`}>
      {label && (
        <Label htmlFor={name} className="text-base text-[#666666] font-normal">
          {label}
        </Label>
      )}

      <Controller
        name={name}
        control={control}
        rules={rules}
        defaultValue="" // prevent uncontrolled-to-controlled switch
        render={({ field }) => (
          <Select value={field.value} onValueChange={field.onChange}>
        <SelectTrigger
          id={name}
          size={"custom"}
          className={cn(
            " selection:bg-primary selection:text-primary-foreground border-input flex mt-1 h-[54px] w-full min-w-0 rounded-lg border bg-transparent text-base outline-none disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
            "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
            hasError && "border-red-500"
          )}
          aria-invalid={hasError}
        >
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>

        <SelectContent>
          {options.map((opt) => (
            <SelectItem key={opt.value} value={opt.value}>
              {opt.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
        )}
      />

      {hasError && (
        <div className="flex items-center gap-2 mt-1">

          <span className="text-sm text-red-500">{errors[name]?.message}</span>
        </div>
      )}
    </div>
  );
}
    
