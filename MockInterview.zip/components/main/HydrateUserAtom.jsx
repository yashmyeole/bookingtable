"use client";

import { userAtom } from "@/store/authAtoms";
import { useSetAtom } from "jotai";
import { useEffect } from "react";

export default function HydrateUserAtom({ initialUserData, children }) {
  const setUser = useSetAtom(userAtom);

  useEffect(() => {
    if (initialUserData) {
      setUser(initialUserData);
    }
  }, [initialUserData]);

  return children;
}
