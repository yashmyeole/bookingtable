"use client"
import React, { useState } from 'react'
import { filters } from '@/utils/Utility'
import Image from 'next/image'
import UpIcon from '@/assets/up_icon.png'
import DownIcon from '@/assets/down_icon.png'
import { SearchInput } from '../ui/search_input'
import Checkbox from '../ui/checkbox'
import { ranges } from '@/utils/Utility';

const Filters = ({ onFiltersChange }) => {
  const [filters, setFilters] = useState({
    domain: [],
    skills: [],
    tools: [],
    companies: [],
    experience: 0,
    pricing: 0,
  });

  const updateFilter = (key, value) => {
    setFilters((prev) => {
      const updated = { ...prev, [key]: value };
      onFiltersChange?.(updated); // notify parent if needed
      return updated;
    });
  };

  return (
    <div className="flex flex-col space-y-3">
      <h3 className="font-extrabold text-lg px-3">Filter</h3>

      <FilterSection
        sectionHeading="Domain"
        filterKey="domain"
        options={["Frontend", "Backend", "DevOps"]}
        selectedOptions={filters.domain}
        onChange={(val) => updateFilter("domain", val)}
        searchPlaceholder="Search for technology"
      />

      <Divider />
      <FilterSection
        sectionHeading="Skills"
        filterKey="skills"
        options={["React", "Node.js", "Java"]}
        selectedOptions={filters.skills}
        onChange={(val) => updateFilter("skills", val)}
        searchPlaceholder="Search for skills"
      />

      <Divider />
      <FilterSection
        sectionHeading="Tools"
        filterKey="tools"
        options={["Figma", "Jira", "Slack"]}
        selectedOptions={filters.tools}
        onChange={(val) => updateFilter("tools", val)}
        searchPlaceholder="Search for tools"
      />

      <Divider />
      <FilterSection
        sectionHeading="Companies"
        filterKey="companies"
        options={["Google", "Amazon", "Meta"]}
        selectedOptions={filters.companies}
        onChange={(val) => updateFilter("companies", val)}
        searchPlaceholder="Search for companies"
      />

      <Divider />
      <Slider
        header="Experience"
        range={ranges.experience}
        steps="1"
        value={filters.experience}
        onChange={(val) => updateFilter("experience", val)}
      />

      <Divider />
      <Slider
        header="Pricing"
        range={ranges.pricing}
        steps="100"
        value={filters.pricing}
        onChange={(val) => updateFilter("pricing", val)}
      />
    </div>
  );
};

const Divider = () => <div className="border-b border-gray-300 my-5" />;

const FilterSection = ({ sectionHeading, filterKey, selectedOptions, onChange, options = [], searchPlaceholder }) => {
  const [dropDown, setDropDown] = useState(true);

  const toggleOption = (option) => {
    const updated = selectedOptions.includes(option)
      ? selectedOptions.filter((o) => o !== option)
      : [...selectedOptions, option];
    onChange(updated);
  };

  return (
    <div className="space-y-2 max-w-s">
      <div className="flex justify-between px-3">
        <span className="text-[18px]">{sectionHeading}</span>
        <Image
          onClick={() => setDropDown((prev) => !prev)}
          src={dropDown ? UpIcon : DownIcon}
          width={30}
          alt="Toggle"
        />
      </div>

      {dropDown && (
        <>
          <SearchInput placeholder={searchPlaceholder} />
          <div className="px-5 space-y-3">
            
              <Checkbox
                //key={opt}
                //title={opt}
                options={options}
                //checked={selectedOptions.includes(opt)}
                onChange={() => toggleOption(opt)}
              />
            
          </div>
          <button className="font-black text-sm px-5 text-[#007FAD]">Show more</button>
        </>
      )}
    </div>
  );
};

function Slider({ header, range, steps, value, onChange }) {
  const [dropDown, setDropDown] = useState(true);
  const min = parseInt(range[0].replace(/[^\d]/g, ""), 10);
  const max = parseInt(range[range.length - 1].replace(/[^\d]/g, ""), 10);

  return (
    <div className="w-full max-w-s space-y-3">
      <div className="flex justify-between items-center px-3">
        <span className="text-[18px]">{header}</span>
        <Image
          onClick={() => setDropDown((prev) => !prev)}
          src={dropDown ? UpIcon : DownIcon}
          width={30}
          alt="Toggle"
        />
      </div>

      {dropDown && (
        <>
          <div className="flex justify-between text-xs text-black pl-3 pr-5">
            {range.map((r, i) => (
              <span key={i}>{r}</span>
            ))}
          </div>
          <div className="pl-3 pr-5">
            <input
              type="range"
              min={min}
              max={max}
              step={steps}
              value={value}
              onChange={(e) => onChange(Number(e.target.value))}
              className="w-full appearance-none h-2 rounded-full bg-gray-200 outline-none accent-[#007FAD]"
              style={{
                background: `linear-gradient(to right, #007FAD ${(100 * (value - min)) / (max - min)}%, #e5e7eb 0%)`,
              }}
            />
          </div>
        </>
      )}
    </div>
  );
}

export default Filters;
