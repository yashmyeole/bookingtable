"use client"
import Image from 'next/image'
import React, { useState } from 'react'
import profile from "@/assets/kartik.png";
import star from "@/assets/star_icon.png";
import { useRouter} from 'next/navigation';
import { interviewers } from '@/utils/Utility';

const InterviewerCardHelper = ({ interviewers }) => {
  const [expanded, setExpanded] = useState(false);
  const wordLimit = 20;
  const words = interviewers?.overview?.split(" ");
  const isTruncated = words?.length > wordLimit;
  const displayedText = expanded ? interviewers?.overview : words?.slice(0, wordLimit).join(" ") + (isTruncated ? "..." : "");
  const userSkills = ['React JS', 'Node JS', 'Vue JS', 'React Native', 'Java'];
  const route = useRouter();

  return (
    <div className='flex my-8 space-x-10 bg-white border border-[#E0E0E0] rounded-xl shadow px-5 py-5 min-w-full'>

      <div className='flex flex-col flex-shrink-0 space-y-3'>
        <Image className='rounded-full' src={profile} alt='ProfileImage' width={132} />
        <span className='flex flex-col'>
          <p>Domain</p>
          <p className="text-sm">{interviewers.domain}</p>
        </span>
      </div>
      <div className='space-y-2'>
        <div className='flex justify-between '>
          <h2 className='font-bold text-lg'>{interviewers.firstname} {interviewers.lastname}</h2>
          <span className='flex items-center justify-center'>
            <Image className='pb-1' src={star} alt='Rating' width={19} />
            {/* <span className='text-sm'>{interviewers.rating}</span> */}
            <span className='text-sm'>5.0</span>
          </span>
        </div>
        <div className=''>
          <span className='text-[#007FAD]'>
            Experience:  {interviewers.experienceYears} years | Currently Tech Lead at {interviewers.organizationName}
          </span>
        </div>
        <div className='pt-3 mr-2'>
          {/* <p className='text-wrap text-[#484646] text-sm'>{interviewers.overview}</p> */}
          <p className="text-wrap text-[#484646] text-sm">
            {displayedText}
            {isTruncated && (
              <button
                onClick={() => setExpanded(!expanded)}
                className="text-[#007FAD] font-medium ml-1 hover:underline"
              >
                {expanded ? "Show less" : "Read more"}
              </button>
            )}
          </p>
        </div>

        {interviewers.skills && <SkillsSection
          skills={interviewers.skills}
        />}

        <button className='bg-[#007FAD] cursor-pointer text-sm rounded-md text-white py-2 px-4' onClick={() => route.push(`/explore/${interviewers.id}`)}>View profile</button>
      </div>
    </div>
  )
}

function SkillsSection({ skills }) {
    const words = skills.includes("||")
  ? skills.split("||")
  : skills.includes(",")
    ? skills.split(",")
    : [skills];
    
    return (
      <div className='flex gap-3 my-7'>
        {words?.map((skill, index) => (
        <span key={index} className='rounded-3xl bg-[#D9F4FE] text-sm px-4 py-2'>{skill}</span>
       ))}

      </div>
    )
}

const InterviewerCard = ({ mentors }) => {
  return (
    <div className='py-4 w-full'>
      {mentors?.map((list, index) => (
        <InterviewerCardHelper key={index}
          interviewers={list}
        />
      ))}
    </div>
  )
}
export default InterviewerCard
