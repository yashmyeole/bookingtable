"use client";
import Image from "next/image";
import React, { useEffect, useState } from "react";
import JioLogo from "../../assets/jio_logo.png";
import { usePathname, useRouter } from "next/navigation";
import { useLogoutMutation, useTokenDetailsQuery } from "@/hooks/authHooks";
import { isLoggedInAtom, userAtom } from "@/store/authAtoms";
import { useAtom } from "jotai";
import Link from "next/link";
import UserAvatar from "./UserAvatar";

const Navbar = () => {
  const router = useRouter();
  const [userData, setuserData] = useAtom(userAtom);
  const pathname = usePathname();
  const { mutate: triggerLogout } = useLogoutMutation();
  // const handleLogout = async () => {
  //   triggerLogout();
  // };
  const isRegisterPage = pathname === "/register";
  const isLoginPage = pathname === "/login";
  const [isHydrated, setIsHydrated] = useState(false);
  useEffect(() => {
    setIsHydrated(true);
  }, []);
  if (!isHydrated) return null; // or a loading spinner

  return (
    <div className="flex w-full items-center justify-between h-[60px] px-[8vw]">
      <div className="flex items-center gap-x-12 text-gray-600">
        <div className="cursor-pointer">
          <Image alt="Logo" src={JioLogo} width={30} height={30} />
        </div>
        <div className="cursor-pointer" onClick={() => router.push("/")}>
          Home
        </div>
        {!userData && (
          <>
            {" "}
            <div
              className="cursor-pointer"
              onClick={() => router.push("/explore")}
            >
              Explore Interviewers
            </div>
            <div className="cursor-pointer">AI Mock Interview</div>
          </>
        )}
        {userData?.profile.role === "student" && (
          <>
            {" "}
            <div
              className="cursor-pointer"
              onClick={() => router.push("/explore")}
            >
              Explore Interviewers
            </div>
            <div className="cursor-pointer">AI Mock Interview</div>
          </>
        )}
      </div>
      <div className="flex gap-x-12">
        {!userData ? (
          <>
            <Link href="/register">
              <div
                className={`cursor-pointer ${
                  isRegisterPage ? "text-customblue font-semibold" : ""
                }`}
              >
                Register
              </div>
            </Link>
            <Link href="/login">
              <div
                className={`cursor-pointer ${
                  isLoginPage ? "text-customblue font-semibold" : ""
                }`}
              >
                Login
              </div>
            </Link>
          </>
        ) : (
          // <div onClick={handleLogout} className="cursor-pointer text-red-500">
          //   Logout
          // </div>
          <>
            <div className="flex items-center justify-center space-x-3">
              {" "}
              <div className="cursor-pointer ">Notifications</div>
              <UserAvatar />
            </div>
          </>
        )}
        {/* {Logout buttron here based on getTokenDetails if there is console log the error only render logout button if you get token cvalue means user is logged in } */}
      </div>
    </div>
  );
};

export default Navbar;
