"use client";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useAtom } from "jotai";
import { userAtom } from "@/store/authAtoms";
import { useLogoutMutation } from "@/hooks/authHooks";
import { useRouter } from "next/navigation";
import { RiDashboardHorizontalLine } from "react-icons/ri";
import { FiUser } from "react-icons/fi";
import { FaPowerOff } from "react-icons/fa6";
const UserAvatar = () => {
  const [userData] = useAtom(userAtom);
  const router = useRouter();
  const { mutate: triggerLogout } = useLogoutMutation();

  const handleLogout = () => {
    triggerLogout();
  };

  const getInitials = () => {
    if (!userData) return "";
    const { firstName, lastName } = userData.profile;
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Avatar className="cursor-pointer">
          {/* <AvatarImage src={userData?.profileImageUrl || ""} alt="User" /> */}
          <AvatarFallback className="bg-[#E8E8FC] text-[#00004C]">
            {getInitials()}
          </AvatarFallback>
        </Avatar>
      </PopoverTrigger>
      <PopoverContent className="w-[184px] flex flex-col p-0 rounded-2xl space-y-2">
        {/* User name and avatar */}
        <div className="flex items-center px-2 pb-2 pt-3 border-b border-[#C4C4C4] space-x-3">
          <Avatar className="h-[18px] w-[18px] text-[8px]">
            <AvatarFallback className="bg-[#E8E8FC]  text-[#00004C]">
              {getInitials()}
            </AvatarFallback>
          </Avatar>
          <p className="text-base">{`${userData.profile.firstName} ${userData.profile.lastName} `}</p>
        </div>
        <div className="flex flex-col space-y-3 pb-2 border-b border-[#C4C4C4]">
          <div
            className="flex items-center pt-2 px-2 space-x-3 cursor-pointer hover:text-blue-600"
            onClick={() =>
              router.push(
                userData?.profile.role === "student"
                  ? `/candidate/dashboard`
                  : `/interviewer/dashboard`
              )
            }
          >
            <RiDashboardHorizontalLine className="text-customblue" />
            <span className="text-base">Dashboard</span>
          </div>
          <div
            className="flex items-center pt-2 px-2 space-x-3 cursor-pointer hover:text-blue-600"
            onClick={() =>
              router.push(
                userData?.profile.role === "student"
                  ? `/candidate/profile`
                  : `/interviewer/profile`
              )
            }
          >
            <FiUser className="text-customblue" />
            <span>Profile</span>
          </div>
        </div>
        <div
          className="flex items-center  py-2 px-2 space-x-3 cursor-pointer hover:text-red-600"
          onClick={handleLogout}
        >
          <FaPowerOff className="text-customblue" />
          <span>Logout</span>
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default UserAvatar;
