"use client";
import React, { useEffect, useState } from "react";
import { Label } from "../ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { Button } from "../ui/button";
import { Calendar } from "../ui/calendar";
import { ChevronDownIcon } from "lucide-react";
import { addDays, addMonths, format } from "date-fns";
const DatePickerCustom = ({ date, setDate }) => {
  const [open, setOpen] = useState(false);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  // useEffect(() => {
  //   setDate(new Date());
  // }, []);
  return (
    <div className="flex flex-col gap-3 ">
      <Label htmlFor="date" className="px-1 font-medium text-base">
        Select Date
      </Label>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="ghost"
            id="date"
            className="w-48 justify-between font-normal"
          >
            {date ? format(date, "dd/MM/yyyy") : "DD/MM/YYYY"}
            <ChevronDownIcon />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto overflow-hidden p-0" align="start">
          <Calendar
            mode="single"
            selected={date}
            defaultMonth={date || today}
            showOutsideDays={false}
            disabled={(date) => {
              const start = addDays(today, 1); // Tomorrow
              const end = addMonths(today, 1); // One month from today
              return date < start || date > end;
            }}
            onSelect={(date) => {
              setDate(date);
              setOpen(false);
            }}
          />
        </PopoverContent>
      </Popover>
    </div>
  );
};

export default DatePickerCustom;
