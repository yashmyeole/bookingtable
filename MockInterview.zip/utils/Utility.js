import { experienceAtom } from "@/components/interviewer/ProfileSteps/formAtoms";

// utils/Utility.js
export const filters = ['Domain', 'Skills', 'Tools', 'Companies', 'Experience', 'Pricing'];

export const interviewers = [{
  name: 'Kartik Sharma',
  experience: '10',
  role: 'Tech Lead at Global Tech',
  rating: 5.4,
  domain: ['Frontend', 'FullStack'],
  bio: 'UX Designer for the past 15+ years. Teaching UI UX Design for the past 7+ years to more than 100K+ students worldwide.',
  skills: ['React JS', 'Node JS', 'Vue JS', 'React Native'],
},{
name: 'Apurva Sharma',
  experience: '5',
  role: 'Tech Lead at Global Tech',
  rating: '5.0',
  domain: ['Fullstack', 'Frontend'],
  bio:'UX Designer for the past 15+ years. Teaching UI UX Design for the past 7+ years to more than 100K+ students worldwide.',
  skills: ['React JS', 'Node JS', 'Vue JS', 'React Native', 'Java']},
];

export const sortByOptions = [
  { label: "Recommended", value: "recommended" },
  { label: "Availablity", value: "backend" },
  { label: "Pricing (Low to High)", value: "pricing_low" },
  { label: "Pricing (High to Low)", value: "pricing_high" }];

  export const userSkills = ['React JS', 'Node JS', 'Vue JS', 'React Native', 'Java'];

export const timeSlot = {
  date:'1 Apr 2025 ,Monday',
  time:'11:30 AM - 12:00 PM',
  duration:'30 min',
  price:'Rs 1000',
  skills:['React JS', 'Node JS', 'Vue JS', 'React Native', 'Java']
}

export const ranges = {
  experience:['0', '8', '15'],
  pricing:['1500', '2500', '3000']}