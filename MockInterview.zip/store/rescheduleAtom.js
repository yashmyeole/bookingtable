import { atom } from "jotai";

export const rescheduleReasonAtom = atom("");

export const rescheduleSlotDataAtom = atom({});
