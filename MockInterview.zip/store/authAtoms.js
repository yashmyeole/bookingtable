import { atom } from "jotai";

export const registerFormDataAtom = atom({
  candidate: {},
  interviewer: {},
});
export const userAtom = atom(null); // Will hold { name, roleId, email, etc. }
export const isLoggedInAtom = atom((get) => !!get(userAtom)); // derived
export const mobileNoAtom = atom("");
export const userTypeAtom = atom("candidate"); // default value
