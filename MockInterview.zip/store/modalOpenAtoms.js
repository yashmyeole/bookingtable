import { atom } from "jotai";

export const openCandidateRescheduleModalAtom = atom(false); // default value
export const openConfirmRescheduleModalAtom = atom(false); // default value
export const openSuccesfulResceduleModalAtom = atom(false); // default value
export const openCancelModalAtom = atom(false); // default value
export const openInterviewResceduleModalAtom = atom(false); // default value
export const openViewProfileModalAtom = atom(false); // default value
export const openEditTimeSlotModalAtom = atom(false); // default value
export const openOtpPopUpModalAtom = atom(false); // default value
export const succefullRegestrationModalAtom = atom(false);

//Model prefill data

export const editTimeSlotModalPrefillDataAtom = atom({});
