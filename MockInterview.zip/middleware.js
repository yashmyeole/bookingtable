import { API_BASE_URL } from "@/lib/constants";
import { NextResponse } from "next/server";

const PUBLIC_ROUTES = ["/", "/login", "/register"];

export async function middleware(request) {
  const { pathname } = request.nextUrl;
  const token = request.cookies.get("token")?.value;

  // 1. Allow public routes if user is not authenticated
  if (PUBLIC_ROUTES.includes(pathname)) {
    if (!token) {
      return NextResponse.next();
    }

    // If authenticated and trying to access login/register, redirect based on role
    const res = await fetch(
      `${API_BASE_URL}/mockInterview/api/getTokenDetails`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );

    if (!res.ok) {
      return NextResponse.next(); // invalid token, treat as unauthenticated
    }

    const userData = await res.json();
    const roleId = userData?.roleId;

    if (pathname === "/login" || pathname === "/register") {
      const redirectPath =
        roleId === "1" ? "/candidate/dashboard" : "/interviewer/dashboard";
      return NextResponse.redirect(new URL(redirectPath, request.url));
    }

    return NextResponse.next();
  }

  // 2. If no token, redirect to login
  if (!token) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  // 3. Validate token
  const res = await fetch(`${API_BASE_URL}/mockInterview/api/getTokenDetails`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  const userData = await res.json();
  const roleId = userData?.roleId;

  // 4. Role-based protection
  if (pathname.startsWith("/candidate") && roleId !== "1") {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  if (pathname.startsWith("/interviewer") && roleId !== "2") {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"], // Apply to all routes
};
