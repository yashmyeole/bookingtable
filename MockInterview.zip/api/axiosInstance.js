import { API_BASE_URL } from "@/lib/constants";
import axios from "axios";
import { toast } from "react-toastify"; // For pop-up notifications

// Replace with your API URL

// Function to get token (Modify according to your auth setup)
// const getToken = () => {
//   return localStorage.getItem("token"); // Fetch token from localStorage or cookies
//   // const token =
//   //   "eyJhbGciOiJIUzUxMiJ9.eyJtb2JpbGVOdW1iZXIiOiI5MTAwNjg5NzA5IiwiY3JlYXRpb25EYXRlIjoibnVsbCIsInVuaXF1ZUlkIjoiTUlXMDAwMDAwMDAxIiwiZW1haWwiOiJwb3R0ZXJoYXJyeUBnbWFpbC5jb20iLCJzdWIiOiJNSVcwMDAwMDAwMDEiLCJpYXQiOjE3NTA2NTc5NDAsImV4cCI6MTc1MDgzNzk0MH0.0gv-B1jTnCeW_ysIxPG4WPL40cO0AZnbK3op08Oo0me968VoghnW2IpxVDEUQjY_76McvCqlKp4YiDybvUzzJw";

//   // return token;
// };

// ✅ Updated function to fetch token from cookies
const getToken = () => {
  const cookieString = document.cookie
    .split("; ")
    .find((row) => row.startsWith("token="));
  return cookieString ? cookieString.split("=")[1] : null;
};

// Create an Axios instance
const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
  // headers: {
  //   "Content-Type": "application/json",
  // },
});

// Request Interceptor: Automatically attach token to every request
axiosInstance.interceptors.request.use(
  (config) => {
    const token = getToken();
    if (token) {
      config.headers["Authorization"] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response Interceptor: Handle errors globally
// axiosInstance.js
axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    const suppressToast = error?.config?.suppressToast; // ✅ add this check

    if (!error.response) {
      !suppressToast &&
        toast.error("Network error. Please check your internet connection.");
    } else {
      const { status, data } = error.response;

      if (!suppressToast) {
        switch (status) {
          case 400:
            toast.error(
              data?.statusMsg || data?.message || "An error occurred."
            );
            break;
          case 401:
            toast.error("Session expired. Please log in again.");
            typeof window !== "undefined" && localStorage.removeItem("token");
            break;
          case 403:
            toast.warning(
              data?.statusMsg ||
                "You do not have permission to access this resource"
            );
            break;
          case 404:
            toast.warning("Requested resource not found.");
            break;
          case 500:
            toast.error("Server error. Please try again later.");
            break;
          default:
            toast.error(data?.statusMsg || "An error occurred.");
        }
      }
    }

    return Promise.reject(error);
  }
);

export default axiosInstance;
