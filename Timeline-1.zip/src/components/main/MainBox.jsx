import React, { useEffect, useRef, useState } from "react";
import Line1 from "../lines/Line1";
import Line2 from "../lines/Line2";
import Line3 from "../lines/Line3";
import Line4 from "../lines/Line4";
import timelineJson from "../../utils/config/Config.json";
import { motion, useInView } from "framer-motion";
import ComponentContainer from "../containers/main_containers/ComponentContainer";
import LineContainer from "../containers/main_containers/LineContainer";

const MainBox = () => {
  const getAllEvents = (timeline) => {
    return timeline.flatMap((yearData) => {
      const year = Object.keys(yearData)[0];
      const monthsArray = Object.values(yearData)[0];
      return monthsArray.flatMap((monthData) => {
        return Object.entries(monthData).flatMap(([month, events]) => {
          return events.map((event) => ({
            ...event,
            year,
            month,
          }));
        });
      });
    });
  };

  const totalEvents = getAllEvents(timelineJson.timeline);

  console.log(totalEvents);

  return (
    <div className="flex flex-col md:flex-row  scroll-container items-center h-[100vh] mobile-mask pl-8 max-w-screen">
      {totalEvents.map((event, eventIndex) => {
        const ref = useRef(null);
        const isInView = useInView(ref, { once: true, threshold: 0.4 }); // Animation triggers when component is 10% in view

        return (
          <React.Fragment key={eventIndex}>
            <motion.div
              ref={ref}
              id={eventIndex}
              className="flex md:h-[80vh] md:w-[400px]  relative items-center justify-center rounded-t-[80px]"
              initial={{ opacity: 0 }}
              animate={{ opacity: isInView ? 1 : 0 }} // Animate only if in view
              transition={{
                delay: 0.7, // Optional: stagger effect
                duration: 1.5,
                ease: "easeInOut",
              }}
            >
              <div className="flex justify-start px-8 h-[300px] w-screen md:h-full">
                <ComponentContainer
                  event={event}
                  eventIndex={eventIndex}
                  isInView={isInView}
                />
              </div>
            </motion.div>

            {/* Line */}
            <motion.div
              ref={ref}
              className="flex h-[80vh] w-[400px] relative items-center justify-center rounded-t-[80px]"
              initial={{ opacity: 0 }}
              animate={{ opacity: isInView ? 1 : 0 }} // Animate only if in view
              transition={{
                delay: 2.5, // Optional: stagger effect
                duration: 1,
                ease: "easeInOut",
              }}
            >
              <div className="flex h-full absolute -top-2">
                <LineContainer event={event} eventIndex={eventIndex} />
              </div>
            </motion.div>
          </React.Fragment>
        );
      })}
    </div>
  );
};

export default MainBox;
