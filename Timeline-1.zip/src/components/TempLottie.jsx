// App.jsx
import { Canvas } from "@react-three/fiber";
import Player from "react-lottie-player";
import { useEffect, useRef, useState } from "react";
import animationData from "../assets/timelinelottie.json"; // Replace with your Lottie JSON file path

const LottieScrollAnimation = () => {
  const lottieRef = useRef(null);
  const [currentFrame, setCurrentFrame] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      console.log("scrolling");
      // Calculate scroll position as a fraction of the total scrollable height
      const scrollFraction =
        window.scrollY / (document.body.scrollHeight - window.innerHeight);

      // Determine the total number of frames in the Lottie animation
      const totalFrames = lottieRef.current?.getDuration(true) || 1;

      console.log("Total frames: ", totalFrames);
      // Calculate the current frame based on the scroll fraction
      const frame = Math.floor(scrollFraction * (totalFrames - 1));
      console.log("Frame: ", frame);

      // Update the current frame state to control Lottie animation
      setCurrentFrame(frame);
    };

    // Add scroll event listener
    window.addEventListener("scroll", handleScroll);

    // Cleanup event listener on component unmount
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <div style={{ position: "fixed" }}>
      <Player
        ref={lottieRef}
        animationData={animationData}
        play={false}
        goTo={currentFrame}
        //   goTo={currentFrame}
        style={{ width: 1000, height: 500 }}
        loop={false}
        rendererSettings={{
          preserveAspectRatio: "xMidYMid slice",
        }}
      />
    </div>
  );
};

export default LottieScrollAnimation;
