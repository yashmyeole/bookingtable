import React from "react";
import { motion } from "framer-motion";
const ComponentContainer = ({ event = 0, eventIndex, isInView }) => {
  return (
    //   <motion.div
    //   className="flex w-[400px] h-full relative items-center justify-center bg-gray-100 rounded-t-[80px]"
    //   initial={{ opacity: 0 }}
    //   animate={{ opacity: 1 }}
    //   transition={{
    //     delay: 1,
    //     duration: 1,
    //     ease: "easeInOut",
    //   }}
    // >
    //   <div className="flex">{event.title}</div>
    // </motion.div>
    <motion.div
      className="flex relative items-center "
      initial={{ opacity: 0 }}
      animate={{
        opacity: 1,
      }}
      transition={{
        delay: 0,
        duration: 1.5,
        ease: "easeInOut",
      }}
    >
      {isInView && (
        <motion.div
          animate={{
            opacity: 1,
            y: [0, -10, 0], // Floating effect on the y-axis
            x: [0, 10, 0],
          }}
          transition={{
            delay: 0,
            duration: 3,
            ease: "easeInOut",
            repeat: Infinity, // Repeat the floating animation infinitely
            repeatType: "mirror", // Mirror the animation back and forth
          }}
          className="flex relative items-center "
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{
              delay: 1,
              duration: 1,
              ease: "easeInOut",
            }}
            className="flex  bg-blue-400 h-[50vw] w-[50vw] rounded-full"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{
              delay: 2.2,
              duration: 1,
              ease: "easeInOut",
            }}
            className="flex absolute left-[20vw] z-20 bg-black justify-center items-center w-[60vw] min-h-[80px] mt-6 rounded-md text-white"
          >
            555
          </motion.div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default ComponentContainer;
