import React from "react";
import { motion } from "framer-motion";
import Line1 from "../../lines/Line1";
import Line2 from "../../lines/Line2";
import Line3 from "../../lines/Line3";
import Line4 from "../../lines/Line4";
const LineContainer = ({ event, eventIndex }) => {
  return (
    <div className="flex h-full items-center w-screen justify-center">
      {eventIndex % 2 == 0 && <Line1 delay={0} duration={1} location="left" />}
      {eventIndex % 2 == 1 && <Line1 delay={0} duration={1} location="right" />}
    </div>
    // <div className="flex h-full items-center w-[400px]">
    //   {event.lineType === 1 && scrollState >= 0 && <Line1 />}
    //   {event.lineType === 2 && scrollState >= 0.1 && <Line2 />}
    //   {event.lineType === 3 && scrollState >= 0.3 && <Line3 />}
    //   {event.lineType === 4 && scrollState >= 0.5 && <Line4 />}
    // </div>
  );
};

export default LineContainer;
