import React, { useEffect } from "react";
// import LineDownSvg from "../../assets/arrow01.svg";
import LineDownSvg from "../../assets/Group.svg";
import LineDownSvg2 from "../../assets/Group2.svg";
import { motion } from "framer-motion";

const Line1 = ({ delay = 0, duration = 5, location }) => {
  // useEffect(() => {
  //   // console.log(scrollContainerValue);
  // }, [scrollContainerValue]);

  return (
    <motion.div
      style={{ overflow: "hidden" }}
      className={`w-[90%] ${
        location === "left" ? "justify-end" : "justify-start"
      } flex`}
      initial={{ clipPath: "inset(0 100% 0 0)", opacity: 0 }} // Initially hidden from the right
      animate={{
        clipPath: "inset(0 0% 0 0)", // Revealing from left to right
        y: [0, -3, 3, -3, 0], // Wavy movement up and down
        // Wavy movement up and down
        opacity: 1,
      }}
      transition={{
        // Start after 3 seconds
        delay: delay,
        duration: duration, // Reveal duration
        ease: "easeInOut",
        y: {
          // Wavy animation
          repeat: Infinity,
          repeatType: "mirror", // Moves back and forth
          duration: 5, // Duration of one wavy cycle
        },
      }}
    >
      {location === "left" && <img src={LineDownSvg} />}
      {location === "right" && <img src={LineDownSvg2} />}
    </motion.div>
  );
};

export default Line1;
