import React from "react";
import LineDownSvg from "../../assets/arrow03.svg";
import { motion } from "framer-motion";

const Line3 = () => {
  return (
    <motion.div
      style={{ overflow: "hidden", width: "fit-content" }}
      className=""
      initial={{ clipPath: "inset(0 100% 0 0)" }} // Initially hidden from the right
      animate={{
        clipPath: "inset(0 0% 0 0)", // Revealing from left to right
        y: [0, -5, 5, -5, 0], // Wavy movement up and down
      }}
      transition={{
        // Start after 3 seconds
        duration: 5, // Reveal duration
        ease: "easeInOut",
        y: {
          // Wavy animation
          repeat: Infinity,
          repeatType: "mirror", // Moves back and forth
          duration: 2, // Duration of one wavy cycle
        },
      }}
    >
      <img src={LineDownSvg} />
    </motion.div>
  );
};

export default Line3;
