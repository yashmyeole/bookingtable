import React, { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Line1 from "../lines/Line1";

const Comp1 = ({ setCurr }) => {
  const startX = useRef(null);
  const endX = useRef(null);
  const [moveLeftAnimation, setMoveLeftAnimation] = useState(false);
  const [moveRightAnimation, setMoveRightAnimation] = useState(false);

  // Handling touch start
  const handleTouchStart = (e) => {
    startX.current = e.targetTouches[0].clientX;
  };

  // Handling touch move
  const handleTouchMove = (e) => {
    endX.current = e.targetTouches[0].clientX;
  };

  // Handling mouse down
  const handleMouseDown = (e) => {
    startX.current = e.clientX;
  };

  // Handling mouse move
  const handleMouseMove = (e) => {
    if (startX.current !== null) {
      endX.current = e.clientX;
    }
  };

  // Handling touch and mouse end
  const handleEnd = () => {
    if (startX.current === null || endX.current === null) return;

    const deltaX = startX.current - endX.current;

    // Swipe left
    if (deltaX > 50) {
      setMoveLeftAnimation(true);
      setTimeout(() => {
        setCurr((prev) => prev + 1);
        console.log("Swiped left, increasing state");
        setMoveLeftAnimation(false); // Reset animation state after update
      }, 1500);
    }

    // Swipe right
    if (deltaX < -50 && setCurr > 0) {
      setMoveRightAnimation(true);
      setTimeout(() => {
        setCurr((prev) => prev - 1);
        console.log("Swiped right, decreasing state");
        setMoveRightAnimation(false); // Reset animation state after update
      }, 1500);
    }

    // Reset refs after swipe is handled
    startX.current = null;
    endX.current = null;
  };

  return (
    <div
      className="overflow-hidden select-none" // Prevents accidental text selection on swipe
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleEnd}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleEnd}
      onMouseLeave={handleEnd} // To handle the case when the mouse leaves the component
    >
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0.5, x: 100 }}
          animate={
            moveLeftAnimation
              ? { x: "-100%" }
              : moveRightAnimation
              ? { x: "100%" }
              : { opacity: 1, x: 0 }
          }
          exit={{ opacity: 0.5, x: -100 }}
          transition={{ duration: 3, exit: { duration: 3 } }}
          className="flex items-center justify-center h-[80vh] max-w-[100vw] z-20"
        >
          <div className="flex h-full items-center w-[400px]">
            <Line1 delay={0} duration={1} />
          </div>
          <motion.div
            className="flex w-[400px] h-full relative items-center justify-center bg-gray-100 rounded-t-[80px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{
              delay: 1,
              duration: 1,
              ease: "easeInOut",
            }}
          >
            <div className="flex">jkjjkjb</div>
          </motion.div>
          <div className="flex h-full items-center w-[400px]">
            <Line1 delay={2} duration={1} />
          </div>
          <motion.div
            className="flex w-[400px] h-full relative items-center justify-center bg-gray-100 rounded-t-[80px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{
              delay: 3,
              duration: 1,
              ease: "easeInOut",
            }}
          >
            <div className="flex">jkjjkjb</div>
          </motion.div>
          <div className="flex h-full items-center w-[400px]">
            <Line1 delay={4} duration={1} />
          </div>
          <motion.div
            className="flex w-[400px] h-full relative items-center justify-center bg-gray-100 rounded-t-[80px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{
              delay: 5,
              duration: 1,
              ease: "easeInOut",
            }}
          >
            <div className="flex">jkjjkjb</div>
          </motion.div>
          <div className="flex h-full items-center w-[400px]">
            <Line1 delay={6} duration={2} />
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default Comp1;
