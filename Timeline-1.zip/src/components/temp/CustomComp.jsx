import React from "react";
import { motion } from "framer-motion";
import Line1 from "../lines/Line1";
import Line2 from "../lines/Line2";

const CustomComp = () => {
  return (
    <div className="flex items-center justify-center h-full min-w-[100vw]">
      <motion.div
        initial={{ opacity: 0.5 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0.5, x: -100 }}
        transition={{ duration: 3, exit: { duration: 3 } }}
        className="flex items-center justify-center h-[80vh] max-w-[100vw]"
      >
        <div className="flex h-full items-center w-[400px]">
          <Line1 delay={0} duration={1} />
        </div>
        <motion.div
          className="flex w-[400px] h-full relative items-center justify-center bg-gray-100 rounded-t-[80px]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{
            delay: 1,
            duration: 1,
            ease: "easeInOut",
          }}
        >
          <div className="flex">jkjjkjb</div>
        </motion.div>
        <div className="flex h-full items-center w-[400px]">
          <Line2 delay={2} duration={1} />
        </div>
        <motion.div
          className="flex w-[400px] h-full relative items-center justify-center bg-gray-100 rounded-t-[80px]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{
            delay: 3,
            duration: 1,
            ease: "easeInOut",
          }}
        >
          <div className="flex">jkjjkjb</div>
        </motion.div>
        <div className="flex h-full items-center w-[400px]">
          <Line1 delay={4} duration={1} />
        </div>
        <motion.div
          className="flex w-[400px] h-full relative items-center justify-center bg-gray-100 rounded-t-[80px]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{
            delay: 5,
            duration: 1,
            ease: "easeInOut",
          }}
        >
          <div className="flex">jkjjkjb</div>
        </motion.div>
        <div className="flex h-full items-center w-[400px]">
          <Line1 delay={6} duration={2} />
        </div>
      </motion.div>
    </div>
  );
};

export default CustomComp;
