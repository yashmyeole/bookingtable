import React, { useState, useEffect, useRef } from "react";
import LottieScrollAnimation from "./components/TempLottie";
import { Canvas } from "@react-three/fiber";
import { Html } from "@react-three/drei";
import MainBox from "./components/main/MainBox";
import Comp1 from "./components/temp/Comp1";
import Comp2 from "./components/temp/Comp2";
import { AnimatePresence, motion, useInView } from "framer-motion";
import CustomComp from "./components/temp/CustomComp";
import Line1 from "./components/lines/Line1";
import Seekbar from "./components/main/Seekbar";

function App() {
  const [jumpValue, setJumpValue] = useState(0);

  const handlejump = (value) => { 
    console.log("Running: ", value);
    scrollToComponent(value);
  };

  const scrollToComponent = (componentId) => {
    const element = document.getElementById(componentId);
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "center",
      });
    }
  };
  return (
    <div className="h-[100vh] max-w-[100vw]">
      <Seekbar handlejump={ handlejump } />
      <MainBox />

      {/* <button
        onClick={() => scrollToComponent(25)}
        className="absolute bottom-4 right-4 px-2 py-1 bg-blue-500 text-white rounded-lg"
      >
        Go to Component
      </button> */}
    </div>
  );
}

export default App;
